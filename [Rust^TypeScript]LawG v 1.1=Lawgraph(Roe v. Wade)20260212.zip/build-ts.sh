#!/bin/bash

# TypeScript Build Script for Roe v. Wade Visualization

echo "🔨 Building TypeScript Fallback..."

# Check if TypeScript is installed
if ! command -v tsc &> /dev/null; then
    echo "❌ TypeScript not found. Installing..."
    npm install
fi

# Clean dist directory
echo "🧹 Cleaning dist directory..."
rm -rf dist
mkdir -p dist/css

# Compile TypeScript
echo "📦 Compiling TypeScript..."
npx tsc

# Check if compilation was successful
if [ $? -eq 0 ]; then
    echo "✅ TypeScript compilation successful!"
    
    # Copy CSS files
    echo "📁 Copying CSS files..."
    cp -r css/* dist/css/ 2>/dev/null || true
    
    echo ""
    echo "✅ Build complete!"
    echo "📂 Output directory: dist/"
    echo "📄 Main files:"
    echo "   - dist/fallback.js"
    echo "   - dist/types.js"
    echo "   - dist/css/style.css"
    echo ""
    echo "🚀 To run: python3 -m http.server 8080"
else
    echo "❌ TypeScript compilation failed!"
    exit 1
fi
