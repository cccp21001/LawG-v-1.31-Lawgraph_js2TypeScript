/**
 * JavaScript Glue Code for Rust/WASM Visualization
 * Handles WASM initialization, animation loop, and DOM interactions
 */

import init, { LegalBattleVisualization } from './pkg/roe_v_wade_visualization.js';

// Global visualization instance
let visualization = null;
let animationFrameId = null;

/**
 * Initialize the visualization
 */
async function initVisualization() {
    try {
        // Initialize WASM module
        await init();
        
        // Create visualization instance
        visualization = new LegalBattleVisualization();
        
        console.log('✅ Rust/WASM Visualization initialized successfully!');
        
        // Setup event listeners
        setupControls();
        setupResizeHandler();
        
    } catch (error) {
        console.error('❌ Failed to initialize visualization:', error);
    }
}

/**
 * Setup control button event listeners
 */
function setupControls() {
    const playBtn = document.getElementById('playBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const resetBtn = document.getElementById('resetBtn');
    
    if (!playBtn || !pauseBtn || !resetBtn) {
        console.error('Control buttons not found');
        return;
    }
    
    playBtn.addEventListener('click', () => {
        if (visualization) {
            visualization.play();
            playBtn.disabled = true;
            pauseBtn.disabled = false;
            startAnimationLoop();
        }
    });
    
    pauseBtn.addEventListener('click', () => {
        if (visualization) {
            visualization.pause();
            playBtn.disabled = false;
            pauseBtn.disabled = true;
            stopAnimationLoop();
        }
    });
    
    resetBtn.addEventListener('click', () => {
        if (visualization) {
            visualization.reset();
            playBtn.disabled = false;
            pauseBtn.disabled = true;
            resetBtn.disabled = false;
            stopAnimationLoop();
        }
    });
}

/**
 * Setup window resize handler
 */
function setupResizeHandler() {
    window.addEventListener('resize', () => {
        if (visualization) {
            visualization.resize_canvas();
        }
    });
}

/**
 * Animation loop using requestAnimationFrame
 */
function animate(timestamp) {
    if (visualization && visualization.is_playing()) {
        visualization.update(timestamp);
        animationFrameId = requestAnimationFrame(animate);
    }
}

/**
 * Start animation loop
 */
function startAnimationLoop() {
    if (!animationFrameId) {
        animationFrameId = requestAnimationFrame(animate);
    }
}

/**
 * Stop animation loop
 */
function stopAnimationLoop() {
    if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
    }
}

/**
 * Modal control function
 */
window.closeModal = function() {
    const modal = document.getElementById('detailModal');
    if (modal) {
        modal.style.display = 'none';
    }
};

/**
 * Close modal when clicking outside
 */
window.onclick = function(event) {
    const modal = document.getElementById('detailModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
};

/**
 * Initialize when DOM is ready
 */
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initVisualization);
} else {
    initVisualization();
}

// Export for debugging
window.visualization = visualization;
