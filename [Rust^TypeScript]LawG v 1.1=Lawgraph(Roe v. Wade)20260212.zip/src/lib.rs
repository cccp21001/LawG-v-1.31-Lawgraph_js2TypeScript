//! Legal Battle Visualization - Roe v. Wade (Rust/WebAssembly Version)
//!
//! A high-performance, memory-safe visualization built with Rust and compiled to WebAssembly
//! 
//! @version 1.0.0
//! @license MIT

use wasm_bindgen::prelude::*;
use wasm_bindgen::JsCast;
use web_sys::{
    CanvasRenderingContext2d, HtmlCanvasElement, MouseEvent, Window, Performance,
};
use std::cell::RefCell;
use std::rc::Rc;
use std::f64::consts::PI;

mod types;
use types::*;

// When the `wee_alloc` feature is enabled, use `wee_alloc` as the global allocator
#[cfg(feature = "wee_alloc")]
#[global_allocator]
static ALLOC: wee_alloc::WeeAlloc = wee_alloc::WeeAlloc::INIT;

/// Main visualization struct with Rust's ownership and borrowing
#[wasm_bindgen]
pub struct LegalBattleVisualization {
    canvas: HtmlCanvasElement,
    ctx: CanvasRenderingContext2d,
    dimensions: CanvasDimensions,
    animation: AnimationConfig,
    case_details: CaseDetails,
    phases: Vec<BattlePhase>,
    x_graph: GraphState,
    y_graph: GraphState,
    balloon_markers: Vec<BalloonMarker>,
    animation_frame_id: Option<i32>,
}

#[wasm_bindgen]
impl LegalBattleVisualization {
    /// Create a new visualization instance
    #[wasm_bindgen(constructor)]
    pub fn new() -> Result<LegalBattleVisualization, JsValue> {
        // Set panic hook for better error messages
        #[cfg(feature = "console_error_panic_hook")]
        console_error_panic_hook::set_once();

        // Get canvas element
        let window = web_sys::window().ok_or("No window found")?;
        let document = window.document().ok_or("No document found")?;
        let canvas = document
            .get_element_by_id("battleCanvas")
            .ok_or("Canvas not found")?
            .dyn_into::<HtmlCanvasElement>()?;

        // Get 2D context
        let ctx = canvas
            .get_context("2d")?
            .ok_or("Could not get 2D context")?
            .dyn_into::<CanvasRenderingContext2d>()?;

        // Initialize dimensions
        let dimensions = CanvasDimensions {
            width: 0.0,
            height: 0.0,
            center_x: 0.0,
            center_y: 0.0,
        };

        // Animation configuration
        let animation = AnimationConfig {
            duration: Constants::DURATION,
            current_time: 0.0,
            is_playing: false,
            last_timestamp: 0.0,
        };

        // Roe v. Wade case details
        let case_details = CaseDetails {
            majority: OpinionDetails {
                justices: 7,
                color: Constants::COLOR_MAJORITY.to_string(),
                arguments: vec![
                    "14th Amendment Due Process includes privacy rights".to_string(),
                    "Woman's right to choose abortion is constitutional".to_string(),
                    "Trimester framework balances woman's rights and state interest".to_string(),
                    "1st trimester: No regulation allowed".to_string(),
                    "2nd trimester: Regulation for mother's health only".to_string(),
                    "3rd trimester: State may prohibit (with exceptions)".to_string(),
                ],
            },
            dissent: OpinionDetails {
                justices: 2,
                color: Constants::COLOR_DISSENT.to_string(),
                arguments: vec![
                    "No constitutional basis for abortion rights".to_string(),
                    "Raw judicial power - exceeding Court's authority".to_string(),
                    "State legislatures should decide through democratic process".to_string(),
                    "Privacy right doesn't extend to abortion transactions".to_string(),
                    "Court overreached by creating new constitutional right".to_string(),
                ],
            },
        };

        // Battle phases
        let phases = vec![
            BattlePhase {
                time: 0.0,
                x_strength: 5.0,
                y_strength: 3.0,
                x_angle: 35.0,
                y_angle: -25.0,
                description: "Initial Arguments: Texas abortion law challenged".to_string(),
            },
            BattlePhase {
                time: 8000.0,
                x_strength: 7.0,
                y_strength: 4.0,
                x_angle: 45.0,
                y_angle: -30.0,
                description: "Privacy Rights Debate: 14th Amendment interpretation".to_string(),
            },
            BattlePhase {
                time: 16000.0,
                x_strength: 9.0,
                y_strength: 4.5,
                x_angle: 50.0,
                y_angle: -28.0,
                description: "Trimester Framework: Balancing state vs individual rights".to_string(),
            },
            BattlePhase {
                time: 24000.0,
                x_strength: 8.0,
                y_strength: 6.0,
                x_angle: 48.0,
                y_angle: -35.0,
                description: "Dissent Objects: Judicial overreach claimed".to_string(),
            },
            BattlePhase {
                time: 32000.0,
                x_strength: 10.0,
                y_strength: 5.0,
                x_angle: 55.0,
                y_angle: -30.0,
                description: "Final Decision: Majority opinion prevails (7-2)".to_string(),
            },
        ];

        // Initialize graph states
        let x_graph = GraphState {
            strength: phases[0].x_strength,
            angle: phases[0].x_angle,
            justices: case_details.majority.justices,
            color: case_details.majority.color.clone(),
            line_width: Constants::GRAPH_LINE_WIDTH,
        };

        let y_graph = GraphState {
            strength: phases[0].y_strength,
            angle: phases[0].y_angle,
            justices: case_details.dissent.justices,
            color: case_details.dissent.color.clone(),
            line_width: Constants::GRAPH_LINE_WIDTH,
        };

        let mut viz = LegalBattleVisualization {
            canvas,
            ctx,
            dimensions,
            animation,
            case_details,
            phases,
            x_graph,
            y_graph,
            balloon_markers: Vec::new(),
            animation_frame_id: None,
        };

        viz.resize_canvas()?;
        viz.draw()?;

        Ok(viz)
    }

    /// Resize canvas to match container dimensions
    pub fn resize_canvas(&mut self) -> Result<(), JsValue> {
        let rect = self.canvas.get_bounding_client_rect();
        let dpr = web_sys::window()
            .ok_or("No window")?
            .device_pixel_ratio();

        self.canvas.set_width((rect.width() * dpr) as u32);
        self.canvas.set_height((rect.height() * dpr) as u32);
        
        self.ctx.scale(dpr, dpr)?;

        self.dimensions = CanvasDimensions {
            width: rect.width(),
            height: rect.height(),
            center_x: rect.width() / 2.0,
            center_y: rect.height() / 2.0,
        };

        if !self.animation.is_playing {
            self.draw()?;
        }

        Ok(())
    }

    /// Start animation playback
    pub fn play(&mut self) {
        self.animation.is_playing = true;
        
        if let Some(window) = web_sys::window() {
            if let Some(performance) = window.performance() {
                self.animation.last_timestamp = performance.now();
            }
        }
    }

    /// Pause animation playback
    pub fn pause(&mut self) {
        self.animation.is_playing = false;
        if let Some(id) = self.animation_frame_id {
            if let Some(window) = web_sys::window() {
                let _ = window.cancel_animation_frame(id);
            }
        }
        self.animation_frame_id = None;
    }

    /// Reset animation to beginning
    pub fn reset(&mut self) -> Result<(), JsValue> {
        self.pause();
        self.animation.current_time = 0.0;
        self.x_graph.strength = self.phases[0].x_strength;
        self.x_graph.angle = self.phases[0].x_angle;
        self.y_graph.strength = self.phases[0].y_strength;
        self.y_graph.angle = self.phases[0].y_angle;
        self.balloon_markers.clear();
        self.draw()?;
        Ok(())
    }

    /// Update animation state
    pub fn update(&mut self, timestamp: f64) -> Result<(), JsValue> {
        if !self.animation.is_playing {
            return Ok(());
        }

        let delta_time = timestamp - self.animation.last_timestamp;
        self.animation.last_timestamp = timestamp;
        self.animation.current_time += delta_time;

        if self.animation.current_time >= self.animation.duration {
            self.animation.current_time = self.animation.duration;
            self.pause();
        }

        self.update_graph_states();
        self.update_balloon_markers();
        self.draw()?;

        Ok(())
    }

    /// Update graph states based on current time
    fn update_graph_states(&mut self) {
        let mut current_phase = &self.phases[0];
        let mut next_phase = &self.phases[1];

        for i in 0..self.phases.len() - 1 {
            if self.animation.current_time >= self.phases[i].time
                && self.animation.current_time < self.phases[i + 1].time
            {
                current_phase = &self.phases[i];
                next_phase = &self.phases[i + 1];
                break;
            }
        }

        if self.animation.current_time >= self.phases[self.phases.len() - 1].time {
            let last = &self.phases[self.phases.len() - 1];
            current_phase = last;
            next_phase = last;
        }

        let phase_progress = (self.animation.current_time - current_phase.time)
            / (next_phase.time - current_phase.time);
        let t = phase_progress.max(0.0).min(1.0);
        let ease = easing::ease_in_out_quad(t);

        self.x_graph.strength = easing::lerp(current_phase.x_strength, next_phase.x_strength, ease);
        self.x_graph.angle = easing::lerp(current_phase.x_angle, next_phase.x_angle, ease);

        self.y_graph.strength = easing::lerp(current_phase.y_strength, next_phase.y_strength, ease);
        self.y_graph.angle = easing::lerp(current_phase.y_angle, next_phase.y_angle, ease);
    }

    /// Update balloon markers based on progress
    fn update_balloon_markers(&mut self) {
        self.balloon_markers.clear();

        let progress = self.animation.current_time / self.animation.duration;

        if progress > 0.1 {
            self.balloon_markers.push(BalloonMarker {
                x: self.dimensions.center_x + 150.0,
                y: self.dimensions.center_y - 100.0,
                marker_type: MarkerType::Majority,
                title: "Majority Opinion".to_string(),
                content: format!("{} Justices", self.case_details.majority.justices),
                details: self.case_details.majority.arguments[0..3].to_vec(),
            });
        }

        if progress > 0.15 {
            self.balloon_markers.push(BalloonMarker {
                x: self.dimensions.center_x - 150.0,
                y: self.dimensions.center_y + 100.0,
                marker_type: MarkerType::Dissent,
                title: "Dissenting Opinion".to_string(),
                content: format!("{} Justices", self.case_details.dissent.justices),
                details: self.case_details.dissent.arguments[0..3].to_vec(),
            });
        }

        if progress > 0.4 {
            self.balloon_markers.push(BalloonMarker {
                x: self.dimensions.center_x + 250.0,
                y: self.dimensions.center_y - 50.0,
                marker_type: MarkerType::Majority,
                title: "Trimester Framework".to_string(),
                content: "Key Legal Standard".to_string(),
                details: self.case_details.majority.arguments[3..6].to_vec(),
            });
        }

        if progress > 0.6 {
            self.balloon_markers.push(BalloonMarker {
                x: self.dimensions.center_x - 200.0,
                y: self.dimensions.center_y + 150.0,
                marker_type: MarkerType::Dissent,
                title: "Judicial Overreach".to_string(),
                content: "Core Objection".to_string(),
                details: self.case_details.dissent.arguments[3..5].to_vec(),
            });
        }
    }

    /// Main draw function
    fn draw(&self) -> Result<(), JsValue> {
        self.clear_canvas()?;
        self.draw_grid()?;
        self.draw_battle_point()?;
        self.draw_graph(&self.x_graph, "X")?;
        self.draw_graph(&self.y_graph, "Y")?;
        self.draw_balloon_markers()?;
        self.draw_legend()?;
        self.draw_progress_bar()?;
        self.draw_phase_description()?;
        Ok(())
    }

    /// Clear canvas
    fn clear_canvas(&self) -> Result<(), JsValue> {
        self.ctx.clear_rect(0.0, 0.0, self.dimensions.width, self.dimensions.height);
        Ok(())
    }

    /// Draw background grid
    fn draw_grid(&self) -> Result<(), JsValue> {
        self.ctx.set_stroke_style(&JsValue::from_str(Constants::COLOR_GRID_LINE));
        self.ctx.set_line_width(0.5);

        // Vertical lines
        let mut x = 0.0;
        while x < self.dimensions.width {
            self.ctx.begin_path();
            self.ctx.move_to(x, 0.0);
            self.ctx.line_to(x, self.dimensions.height);
            self.ctx.stroke();
            x += Constants::GRID_SPACING;
        }

        // Horizontal lines
        let mut y = 0.0;
        while y < self.dimensions.height {
            self.ctx.begin_path();
            self.ctx.move_to(0.0, y);
            self.ctx.line_to(self.dimensions.width, y);
            self.ctx.stroke();
            y += Constants::GRID_SPACING;
        }

        // Center axes
        self.ctx.set_stroke_style(&JsValue::from_str(Constants::COLOR_GRID_AXIS));
        self.ctx.set_line_width(1.0);

        self.ctx.begin_path();
        self.ctx.move_to(self.dimensions.center_x, 0.0);
        self.ctx.line_to(self.dimensions.center_x, self.dimensions.height);
        self.ctx.stroke();

        self.ctx.begin_path();
        self.ctx.move_to(0.0, self.dimensions.center_y);
        self.ctx.line_to(self.dimensions.width, self.dimensions.center_y);
        self.ctx.stroke();

        Ok(())
    }

    /// Draw central battle point with pulse effect
    fn draw_battle_point(&self) -> Result<(), JsValue> {
        self.ctx.set_fill_style(&JsValue::from_str(Constants::COLOR_BATTLE_POINT));
        self.ctx.begin_path();
        self.ctx.arc(
            self.dimensions.center_x,
            self.dimensions.center_y,
            Constants::BATTLE_POINT_RADIUS,
            0.0,
            2.0 * PI,
        )?;
        self.ctx.fill();

        // Pulse effect
        let time = js_sys::Date::now();
        let pulse_size = Constants::BATTLE_POINT_RADIUS
            + (time / Constants::BATTLE_POINT_PULSE_SPEED).sin() 
            * Constants::BATTLE_POINT_PULSE_AMPLITUDE;

        self.ctx.set_stroke_style(&JsValue::from_str("rgba(255, 107, 107, 0.5)"));
        self.ctx.set_line_width(2.0);
        self.ctx.begin_path();
        self.ctx.arc(
            self.dimensions.center_x,
            self.dimensions.center_y,
            pulse_size,
            0.0,
            2.0 * PI,
        )?;
        self.ctx.stroke();

        // Label
        self.ctx.set_fill_style(&JsValue::from_str("#333"));
        self.ctx.set_font("bold 14px Arial");
        self.ctx.set_text_align("center");
        self.ctx.fill_text(
            "Battle Point",
            self.dimensions.center_x,
            self.dimensions.center_y - 20.0,
        )?;

        Ok(())
    }

    /// Draw a graph vector
    fn draw_graph(&self, graph: &GraphState, label: &str) -> Result<(), JsValue> {
        let endpoint = self.calculate_vector_endpoint(graph);

        // Draw main vector
        self.ctx.set_stroke_style(&JsValue::from_str(&graph.color));
        self.ctx.set_line_width(graph.line_width);
        self.ctx.begin_path();
        self.ctx.move_to(self.dimensions.center_x, self.dimensions.center_y);
        self.ctx.line_to(endpoint.x, endpoint.y);
        self.ctx.stroke();

        // Draw arrowhead
        self.draw_arrowhead(&endpoint, &graph.color)?;

        // Draw label
        let angle_rad = graph.angle.to_radians();
        let label_offset = 30.0;

        self.ctx.set_fill_style(&JsValue::from_str(&graph.color));
        self.ctx.set_font("bold 16px Arial");
        self.ctx.set_text_align("center");
        self.ctx.fill_text(
            &format!("{} ({} Justices)", label, graph.justices),
            endpoint.x + angle_rad.cos() * label_offset,
            endpoint.y + angle_rad.sin() * label_offset,
        )?;

        self.ctx.set_font("12px Arial");
        self.ctx.fill_text(
            &format!("Strength: {:.1}", graph.strength),
            endpoint.x + angle_rad.cos() * label_offset,
            endpoint.y + angle_rad.sin() * label_offset + 16.0,
        )?;

        Ok(())
    }

    /// Calculate vector endpoint
    fn calculate_vector_endpoint(&self, graph: &GraphState) -> VectorEndpoint {
        let angle_rad = graph.angle.to_radians();
        let length = graph.strength * Constants::GRAPH_SCALE_FACTOR;
        let scaled_length = length * (graph.justices as f64 / 5.0);

        VectorEndpoint {
            x: self.dimensions.center_x + angle_rad.cos() * scaled_length,
            y: self.dimensions.center_y + angle_rad.sin() * scaled_length,
            angle: angle_rad,
            length: scaled_length,
        }
    }

    /// Draw arrowhead
    fn draw_arrowhead(&self, endpoint: &VectorEndpoint, color: &str) -> Result<(), JsValue> {
        self.ctx.set_fill_style(&JsValue::from_str(color));
        self.ctx.begin_path();
        self.ctx.move_to(endpoint.x, endpoint.y);
        self.ctx.line_to(
            endpoint.x - Constants::GRAPH_ARROW_SIZE * (endpoint.angle - Constants::GRAPH_ARROW_ANGLE).cos(),
            endpoint.y - Constants::GRAPH_ARROW_SIZE * (endpoint.angle - Constants::GRAPH_ARROW_ANGLE).sin(),
        );
        self.ctx.line_to(
            endpoint.x - Constants::GRAPH_ARROW_SIZE * (endpoint.angle + Constants::GRAPH_ARROW_ANGLE).cos(),
            endpoint.y - Constants::GRAPH_ARROW_SIZE * (endpoint.angle + Constants::GRAPH_ARROW_ANGLE).sin(),
        );
        self.ctx.close_path();
        self.ctx.fill();
        Ok(())
    }

    /// Draw balloon markers
    fn draw_balloon_markers(&self) -> Result<(), JsValue> {
        for marker in &self.balloon_markers {
            let color = match marker.marker_type {
                MarkerType::Majority => "rgba(154, 205, 50, 0.9)",
                MarkerType::Dissent => "rgba(0, 0, 0, 0.85)",
            };

            // Draw balloon body
            self.ctx.set_fill_style(&JsValue::from_str(color));
            self.round_rect(
                marker.x - Constants::BALLOON_WIDTH / 2.0,
                marker.y - Constants::BALLOON_HEIGHT,
                Constants::BALLOON_WIDTH,
                Constants::BALLOON_HEIGHT,
                Constants::BALLOON_RADIUS,
            )?;
            self.ctx.fill();

            // Draw balloon tail
            self.ctx.begin_path();
            self.ctx.move_to(marker.x, marker.y);
            self.ctx.line_to(marker.x - Constants::BALLOON_TAIL_WIDTH, marker.y - Constants::BALLOON_TAIL_HEIGHT);
            self.ctx.line_to(marker.x + Constants::BALLOON_TAIL_WIDTH, marker.y - Constants::BALLOON_TAIL_HEIGHT);
            self.ctx.close_path();
            self.ctx.fill();

            // Draw text
            let text_color = match marker.marker_type {
                MarkerType::Majority => "#000",
                MarkerType::Dissent => "#fff",
            };

            self.ctx.set_fill_style(&JsValue::from_str(text_color));
            self.ctx.set_font("bold 13px Arial");
            self.ctx.set_text_align("center");
            self.ctx.fill_text(&marker.title, marker.x, marker.y - 40.0)?;

            self.ctx.set_font("11px Arial");
            self.ctx.fill_text(&marker.content, marker.x, marker.y - 23.0)?;
        }

        Ok(())
    }

    /// Draw legend
    fn draw_legend(&self) -> Result<(), JsValue> {
        let legend_x = 20.0;
        let legend_y = 20.0;
        let legend_width = 280.0;
        let legend_height = 120.0;

        // Background
        self.ctx.set_fill_style(&JsValue::from_str("rgba(255, 255, 255, 0.95)"));
        self.ctx.fill_rect(legend_x, legend_y, legend_width, legend_height);
        self.ctx.set_stroke_style(&JsValue::from_str("#ccc"));
        self.ctx.set_line_width(1.0);
        self.ctx.stroke_rect(legend_x, legend_y, legend_width, legend_height);

        // Title
        self.ctx.set_fill_style(&JsValue::from_str("#333"));
        self.ctx.set_font("bold 16px Arial");
        self.ctx.set_text_align("left");
        self.ctx.fill_text("Roe v. Wade (1973)", legend_x + 10.0, legend_y + 25.0)?;

        // X Graph line
        self.ctx.set_stroke_style(&JsValue::from_str(&self.case_details.majority.color));
        self.ctx.set_line_width(3.0);
        self.ctx.begin_path();
        self.ctx.move_to(legend_x + 10.0, legend_y + 50.0);
        self.ctx.line_to(legend_x + 40.0, legend_y + 50.0);
        self.ctx.stroke();

        self.ctx.set_fill_style(&JsValue::from_str("#333"));
        self.ctx.set_font("13px Arial");
        self.ctx.fill_text(
            &format!("X - Majority Opinion ({} Justices)", self.case_details.majority.justices),
            legend_x + 50.0,
            legend_y + 54.0,
        )?;

        // Y Graph line
        self.ctx.set_stroke_style(&JsValue::from_str(&self.case_details.dissent.color));
        self.ctx.set_line_width(3.0);
        self.ctx.begin_path();
        self.ctx.move_to(legend_x + 10.0, legend_y + 75.0);
        self.ctx.line_to(legend_x + 40.0, legend_y + 75.0);
        self.ctx.stroke();

        self.ctx.set_fill_style(&JsValue::from_str("#333"));
        self.ctx.set_font("13px Arial");
        self.ctx.fill_text(
            &format!("Y - Dissenting Opinion ({} Justices)", self.case_details.dissent.justices),
            legend_x + 50.0,
            legend_y + 79.0,
        )?;

        // Note
        self.ctx.set_font("italic 11px Arial");
        self.ctx.set_fill_style(&JsValue::from_str("#666"));
        self.ctx.fill_text(
            "Graph length & angle proportional to justices & arguments",
            legend_x + 10.0,
            legend_y + 105.0,
        )?;

        Ok(())
    }

    /// Draw progress bar
    fn draw_progress_bar(&self) -> Result<(), JsValue> {
        let bar_width = 300.0;
        let bar_height = 8.0;
        let bar_x = self.dimensions.width - bar_width - 20.0;
        let bar_y = self.dimensions.height - 40.0;

        // Background
        self.ctx.set_fill_style(&JsValue::from_str("rgba(200, 200, 200, 0.5)"));
        self.ctx.fill_rect(bar_x, bar_y, bar_width, bar_height);

        // Progress
        let progress = self.animation.current_time / self.animation.duration;
        self.ctx.set_fill_style(&JsValue::from_str("#4CAF50"));
        self.ctx.fill_rect(bar_x, bar_y, bar_width * progress, bar_height);

        // Border
        self.ctx.set_stroke_style(&JsValue::from_str("#999"));
        self.ctx.set_line_width(1.0);
        self.ctx.stroke_rect(bar_x, bar_y, bar_width, bar_height);

        // Time label
        let current_seconds = (self.animation.current_time / 1000.0).floor() as i32;
        let total_seconds = (self.animation.duration / 1000.0).floor() as i32;

        self.ctx.set_fill_style(&JsValue::from_str("#333"));
        self.ctx.set_font("12px Arial");
        self.ctx.set_text_align("right");
        self.ctx.fill_text(
            &format!("{}s / {}s", current_seconds, total_seconds),
            bar_x + bar_width,
            bar_y - 5.0,
        )?;

        Ok(())
    }

    /// Draw phase description
    fn draw_phase_description(&self) -> Result<(), JsValue> {
        let current_phase = self.phases.iter()
            .rev()
            .find(|p| self.animation.current_time >= p.time)
            .unwrap_or(&self.phases[0]);

        let box_width = 400.0;
        let box_height = 60.0;
        let box_x = (self.dimensions.width - box_width) / 2.0;
        let box_y = self.dimensions.height - 100.0;

        self.ctx.set_fill_style(&JsValue::from_str("rgba(0, 0, 0, 0.8)"));
        self.round_rect(box_x, box_y, box_width, box_height, 8.0)?;
        self.ctx.fill();

        self.ctx.set_fill_style(&JsValue::from_str("#fff"));
        self.ctx.set_font("bold 16px Arial");
        self.ctx.set_text_align("center");
        self.ctx.fill_text(
            &current_phase.description,
            self.dimensions.width / 2.0,
            box_y + 30.0,
        )?;

        let phase_number = self.phases.iter().position(|p| p.time == current_phase.time).unwrap_or(0) + 1;
        self.ctx.set_font("13px Arial");
        self.ctx.fill_text(
            &format!("Phase {} of {}", phase_number, self.phases.len()),
            self.dimensions.width / 2.0,
            box_y + 48.0,
        )?;

        Ok(())
    }

    /// Draw rounded rectangle
    fn round_rect(&self, x: f64, y: f64, width: f64, height: f64, radius: f64) -> Result<(), JsValue> {
        self.ctx.begin_path();
        self.ctx.move_to(x + radius, y);
        self.ctx.line_to(x + width - radius, y);
        self.ctx.quadratic_curve_to(x + width, y, x + width, y + radius);
        self.ctx.line_to(x + width, y + height - radius);
        self.ctx.quadratic_curve_to(x + width, y + height, x + width - radius, y + height);
        self.ctx.line_to(x + radius, y + height);
        self.ctx.quadratic_curve_to(x, y + height, x, y + height - radius);
        self.ctx.line_to(x, y + radius);
        self.ctx.quadratic_curve_to(x, y, x + radius, y);
        self.ctx.close_path();
        Ok(())
    }

    /// Get animation playing status
    pub fn is_playing(&self) -> bool {
        self.animation.is_playing
    }
}

/// Initialize panic hook for better error messages
#[wasm_bindgen(start)]
pub fn main() -> Result<(), JsValue> {
    #[cfg(feature = "console_error_panic_hook")]
    console_error_panic_hook::set_once();
    
    Ok(())
}
