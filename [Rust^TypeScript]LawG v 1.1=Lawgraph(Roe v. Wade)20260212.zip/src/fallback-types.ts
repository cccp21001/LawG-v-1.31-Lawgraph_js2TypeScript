/**
 * Type Definitions for TypeScript Fallback Version
 * Complete type safety for browser-based visualization
 */

// Animation types
export interface AnimationConfig {
    duration: number;
    currentTime: number;
    isPlaying: boolean;
    lastTimestamp: number;
    animationFrameId: number | null;
}

// Canvas dimensions
export interface CanvasDimensions {
    width: number;
    height: number;
    centerX: number;
    centerY: number;
}

// Battle phase
export interface BattlePhase {
    time: number;
    xStrength: number;
    yStrength: number;
    xAngle: number;
    yAngle: number;
    description: string;
}

// Graph state
export interface GraphState {
    strength: number;
    angle: number;
    justices: number;
    color: string;
    lineWidth: number;
}

// Opinion details
export interface OpinionDetails {
    justices: number;
    color: string;
    arguments: string[];
}

// Case details
export interface CaseDetails {
    majority: OpinionDetails;
    dissent: OpinionDetails;
}

// Balloon marker
export type MarkerType = 'majority' | 'dissent';

export interface BoundingBox {
    x: number;
    y: number;
    width: number;
    height: number;
}

export interface BalloonMarker {
    x: number;
    y: number;
    type: MarkerType;
    title: string;
    content: string;
    details: string[];
    bounds?: BoundingBox;
}

// Constants type
export interface Constants {
    DURATION: number;
    COLORS: {
        MAJORITY: string;
        DISSENT: string;
        BATTLE_POINT: string;
        GRID_LINE: string;
        GRID_AXIS: string;
    };
    GRAPH: {
        LINE_WIDTH: number;
        ARROW_SIZE: number;
        ARROW_ANGLE: number;
        SCALE_FACTOR: number;
    };
    BATTLE_POINT: {
        RADIUS: number;
        PULSE_AMPLITUDE: number;
        PULSE_SPEED: number;
    };
    BALLOON: {
        WIDTH: number;
        HEIGHT: number;
        RADIUS: number;
        TAIL_WIDTH: number;
        TAIL_HEIGHT: number;
    };
    GRID: {
        SPACING: number;
    };
}
