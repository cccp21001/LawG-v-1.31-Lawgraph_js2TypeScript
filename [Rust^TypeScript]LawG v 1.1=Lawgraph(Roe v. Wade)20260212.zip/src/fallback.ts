/**
 * Legal Battle Visualization - Pure TypeScript Implementation
 * Fallback version that works without WebAssembly
 * Mirrors the Rust implementation logic
 */

import type {
    AnimationConfig,
    CanvasDimensions,
    BattlePhase,
    GraphState,
    OpinionDetails,
    CaseDetails,
    BalloonMarker,
    MarkerType,
    BoundingBox,
    Constants
} from './types.js';

// Constants
const CONSTANTS: Constants = {
    DURATION: 40000,
    COLORS: {
        MAJORITY: '#9ACD32',
        DISSENT: '#000000',
        BATTLE_POINT: '#ff6b6b',
        GRID_LINE: '#e0e0e0',
        GRID_AXIS: '#999999',
    },
    GRAPH: {
        LINE_WIDTH: 3,
        ARROW_SIZE: 15,
        ARROW_ANGLE: Math.PI / 6,
        SCALE_FACTOR: 30,
    },
    BATTLE_POINT: {
        RADIUS: 8,
        PULSE_AMPLITUDE: 3,
        PULSE_SPEED: 200,
    },
    BALLOON: {
        WIDTH: 180,
        HEIGHT: 60,
        RADIUS: 10,
        TAIL_WIDTH: 10,
        TAIL_HEIGHT: 15,
    },
    GRID: {
        SPACING: 50,
    },
};

// Easing functions
const easing = {
    easeInOutQuad(t: number): number {
        return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    },
    lerp(start: number, end: number, t: number): number {
        return start + (end - start) * t;
    }
};

/**
 * Security: HTML escape function to prevent XSS
 */
function escapeHtml(unsafe: string): string {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/**
 * Main Visualization Class
 */
class LegalBattleVisualization {
    private canvas: HTMLCanvasElement;
    private ctx: CanvasRenderingContext2D;
    private dimensions: CanvasDimensions;
    private animation: AnimationConfig;
    private caseDetails: CaseDetails;
    private phases: BattlePhase[];
    private xGraph: GraphState;
    private yGraph: GraphState;
    private balloonMarkers: BalloonMarker[];
    private tooltip: HTMLElement | null;

    constructor() {
        // Get DOM elements
        const canvas = document.getElementById('battleCanvas') as HTMLCanvasElement | null;
        if (!canvas) {
            throw new Error('Canvas element not found');
        }
        this.canvas = canvas;
        
        const ctx = this.canvas.getContext('2d');
        if (!ctx) {
            throw new Error('Could not get 2D context');
        }
        this.ctx = ctx;

        // Initialize dimensions
        this.dimensions = {
            width: 0,
            height: 0,
            centerX: 0,
            centerY: 0
        };

        // Animation state
        this.animation = {
            duration: CONSTANTS.DURATION,
            currentTime: 0,
            isPlaying: false,
            lastTimestamp: 0,
            animationFrameId: null
        };

        // Case details
        this.caseDetails = {
            majority: {
                justices: 7,
                color: CONSTANTS.COLORS.MAJORITY,
                arguments: [
                    "14th Amendment Due Process includes privacy rights",
                    "Woman's right to choose abortion is constitutional",
                    "Trimester framework balances woman's rights and state interest",
                    "1st trimester: No regulation allowed",
                    "2nd trimester: Regulation for mother's health only",
                    "3rd trimester: State may prohibit (with exceptions)"
                ]
            },
            dissent: {
                justices: 2,
                color: CONSTANTS.COLORS.DISSENT,
                arguments: [
                    "No constitutional basis for abortion rights",
                    "Raw judicial power - exceeding Court's authority",
                    "State legislatures should decide through democratic process",
                    "Privacy right doesn't extend to abortion transactions",
                    "Court overreached by creating new constitutional right"
                ]
            }
        };

        // Battle phases
        this.phases = [
            {
                time: 0,
                xStrength: 5,
                yStrength: 3,
                xAngle: 35,
                yAngle: -25,
                description: "Initial Arguments: Texas abortion law challenged"
            },
            {
                time: 8000,
                xStrength: 7,
                yStrength: 4,
                xAngle: 45,
                yAngle: -30,
                description: "Privacy Rights Debate: 14th Amendment interpretation"
            },
            {
                time: 16000,
                xStrength: 9,
                yStrength: 4.5,
                xAngle: 50,
                yAngle: -28,
                description: "Trimester Framework: Balancing state vs individual rights"
            },
            {
                time: 24000,
                xStrength: 8,
                yStrength: 6,
                xAngle: 48,
                yAngle: -35,
                description: "Dissent Objects: Judicial overreach claimed"
            },
            {
                time: 32000,
                xStrength: 10,
                yStrength: 5,
                xAngle: 55,
                yAngle: -30,
                description: "Final Decision: Majority opinion prevails (7-2)"
            }
        ];

        // Initialize graph states
        this.xGraph = {
            strength: this.phases[0].xStrength,
            angle: this.phases[0].xAngle,
            justices: this.caseDetails.majority.justices,
            color: this.caseDetails.majority.color,
            lineWidth: CONSTANTS.GRAPH.LINE_WIDTH
        };

        this.yGraph = {
            strength: this.phases[0].yStrength,
            angle: this.phases[0].yAngle,
            justices: this.caseDetails.dissent.justices,
            color: this.caseDetails.dissent.color,
            lineWidth: CONSTANTS.GRAPH.LINE_WIDTH
        };

        this.balloonMarkers = [];
        this.tooltip = null;

        this.init();
    }

    private init(): void {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        this.setupControls();
        this.canvas.addEventListener('mousemove', (e) => this.handleMouseMove(e));
        this.canvas.addEventListener('click', (e) => this.handleClick(e));
        this.draw();
        
        console.log('✅ JavaScript Fallback Visualization initialized!');
    }

    private resizeCanvas(): void {
        const rect = this.canvas.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;

        this.canvas.width = rect.width * dpr;
        this.canvas.height = rect.height * dpr;
        this.ctx.scale(dpr, dpr);

        this.dimensions = {
            width: rect.width,
            height: rect.height,
            centerX: rect.width / 2,
            centerY: rect.height / 2
        };

        if (!this.animation.isPlaying) {
            this.draw();
        }
    }

    private setupControls(): void {
        const playBtn = document.getElementById('playBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const resetBtn = document.getElementById('resetBtn');

        if (!playBtn || !pauseBtn || !resetBtn) {
            console.error('Control buttons not found');
            return;
        }

        playBtn.addEventListener('click', () => this.play());
        pauseBtn.addEventListener('click', () => this.pause());
        resetBtn.addEventListener('click', () => this.reset());
    }

    public play(): void {
        if (!this.animation.isPlaying) {
            this.animation.isPlaying = true;
            this.animation.lastTimestamp = performance.now();

            const playBtn = document.getElementById('playBtn');
            const pauseBtn = document.getElementById('pauseBtn');

            playBtn.disabled = true;
            pauseBtn.disabled = false;

            this.animate();
        }
    }

    public pause(): void {
        this.animation.isPlaying = false;

        const playBtn = document.getElementById('playBtn');
        const pauseBtn = document.getElementById('pauseBtn');

        playBtn.disabled = false;
        pauseBtn.disabled = true;

        if (this.animation.animationFrameId) {
            cancelAnimationFrame(this.animation.animationFrameId);
            this.animation.animationFrameId = null;
        }
    }

    public reset(): void {
        this.pause();
        this.animation.currentTime = 0;
        this.xGraph.strength = this.phases[0].xStrength;
        this.xGraph.angle = this.phases[0].xAngle;
        this.yGraph.strength = this.phases[0].yStrength;
        this.yGraph.angle = this.phases[0].yAngle;
        this.balloonMarkers = [];
        this.draw();

        const playBtn = document.getElementById('playBtn');
        const resetBtn = document.getElementById('resetBtn');

        playBtn.disabled = false;
        resetBtn.disabled = false;
    }

    private animate(timestamp: number = 0): void {
        if (!this.animation.isPlaying) return;

        const deltaTime = timestamp - this.animation.lastTimestamp;
        this.animation.lastTimestamp = timestamp;

        this.animation.currentTime += deltaTime;

        if (this.animation.currentTime >= this.animation.duration) {
            this.animation.currentTime = this.animation.duration;
            this.pause();

            const resetBtn = document.getElementById('resetBtn');
            resetBtn.disabled = false;
        }

        this.updateGraphStates();
        this.updateBalloonMarkers();
        this.draw();

        if (this.animation.isPlaying) {
            this.animation.animationFrameId = requestAnimationFrame((t) => this.animate(t));
        }
    }

    private updateGraphStates(): void {
        let currentPhase = this.phases[0];
        let nextPhase = this.phases[1];

        for (let i = 0; i < this.phases.length - 1; i++) {
            if (this.animation.currentTime >= this.phases[i].time &&
                this.animation.currentTime < this.phases[i + 1].time) {
                currentPhase = this.phases[i];
                nextPhase = this.phases[i + 1];
                break;
            }
        }

        if (this.animation.currentTime >= this.phases[this.phases.length - 1].time) {
            currentPhase = this.phases[this.phases.length - 1];
            nextPhase = this.phases[this.phases.length - 1];
        }

        const phaseProgress = (this.animation.currentTime - currentPhase.time) /
                             (nextPhase.time - currentPhase.time);
        const t = Math.max(0, Math.min(1, phaseProgress));

        const ease = easing.easeInOutQuad(t);

        this.xGraph.strength = easing.lerp(currentPhase.xStrength, nextPhase.xStrength, ease);
        this.xGraph.angle = easing.lerp(currentPhase.xAngle, nextPhase.xAngle, ease);

        this.yGraph.strength = easing.lerp(currentPhase.yStrength, nextPhase.yStrength, ease);
        this.yGraph.angle = easing.lerp(currentPhase.yAngle, nextPhase.yAngle, ease);
    }

    private updateBalloonMarkers(): void {
        this.balloonMarkers = [];

        const progress = this.animation.currentTime / this.animation.duration;

        if (progress > 0.1) {
            this.balloonMarkers.push({
                x: this.dimensions.centerX + 150,
                y: this.dimensions.centerY - 100,
                type: 'majority',
                title: 'Majority Opinion',
                content: `${this.caseDetails.majority.justices} Justices`,
                details: this.caseDetails.majority.arguments.slice(0, 3)
            });
        }

        if (progress > 0.15) {
            this.balloonMarkers.push({
                x: this.dimensions.centerX - 150,
                y: this.dimensions.centerY + 100,
                type: 'dissent',
                title: 'Dissenting Opinion',
                content: `${this.caseDetails.dissent.justices} Justices`,
                details: this.caseDetails.dissent.arguments.slice(0, 3)
            });
        }

        if (progress > 0.4) {
            this.balloonMarkers.push({
                x: this.dimensions.centerX + 250,
                y: this.dimensions.centerY - 50,
                type: 'majority',
                title: 'Trimester Framework',
                content: 'Key Legal Standard',
                details: this.caseDetails.majority.arguments.slice(3, 6)
            });
        }

        if (progress > 0.6) {
            this.balloonMarkers.push({
                x: this.dimensions.centerX - 200,
                y: this.dimensions.centerY + 150,
                type: 'dissent',
                title: 'Judicial Overreach',
                content: 'Core Objection',
                details: this.caseDetails.dissent.arguments.slice(3, 5)
            });
        }
    }

    private draw(): void {
        this.ctx.clearRect(0, 0, this.dimensions.width, this.dimensions.height);

        this.drawGrid();
        this.drawBattlePoint();
        this.drawGraph(this.xGraph, 'X');
        this.drawGraph(this.yGraph, 'Y');
        this.drawBalloonMarkers();
        this.drawLegend();
        this.drawProgressBar();
        this.drawPhaseDescription();
    }

    private drawGrid(): void {
        this.ctx.strokeStyle = CONSTANTS.COLORS.GRID_LINE;
        this.ctx.lineWidth = 0.5;

        // Vertical lines
        for (let x = 0; x < this.dimensions.width; x += CONSTANTS.GRID.SPACING) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, this.dimensions.height);
            this.ctx.stroke();
        }

        // Horizontal lines
        for (let y = 0; y < this.dimensions.height; y += CONSTANTS.GRID.SPACING) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(this.dimensions.width, y);
            this.ctx.stroke();
        }

        // Center axes
        this.ctx.strokeStyle = CONSTANTS.COLORS.GRID_AXIS;
        this.ctx.lineWidth = 1;

        this.ctx.beginPath();
        this.ctx.moveTo(this.dimensions.centerX, 0);
        this.ctx.lineTo(this.dimensions.centerX, this.dimensions.height);
        this.ctx.stroke();

        this.ctx.beginPath();
        this.ctx.moveTo(0, this.dimensions.centerY);
        this.ctx.lineTo(this.dimensions.width, this.dimensions.centerY);
        this.ctx.stroke();
    }

    private drawBattlePoint(): void {
        this.ctx.fillStyle = CONSTANTS.COLORS.BATTLE_POINT;
        this.ctx.beginPath();
        this.ctx.arc(
            this.dimensions.centerX,
            this.dimensions.centerY,
            CONSTANTS.BATTLE_POINT.RADIUS,
            0,
            Math.PI * 2
        );
        this.ctx.fill();

        const pulseSize = CONSTANTS.BATTLE_POINT.RADIUS +
                         Math.sin(Date.now() / CONSTANTS.BATTLE_POINT.PULSE_SPEED) *
                         CONSTANTS.BATTLE_POINT.PULSE_AMPLITUDE;

        this.ctx.strokeStyle = 'rgba(255, 107, 107, 0.5)';
        this.ctx.lineWidth = 2;
        this.ctx.beginPath();
        this.ctx.arc(
            this.dimensions.centerX,
            this.dimensions.centerY,
            pulseSize,
            0,
            Math.PI * 2
        );
        this.ctx.stroke();

        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(
            'Battle Point',
            this.dimensions.centerX,
            this.dimensions.centerY - 20
        );
    }

    private drawGraph(graph: GraphState, label: string): void {
        const angleRad = (graph.angle * Math.PI) / 180;
        const length = graph.strength * CONSTANTS.GRAPH.SCALE_FACTOR;
        const scaledLength = length * (graph.justices / 5);

        const endX = this.dimensions.centerX + Math.cos(angleRad) * scaledLength;
        const endY = this.dimensions.centerY + Math.sin(angleRad) * scaledLength;

        // Draw main vector
        this.ctx.strokeStyle = graph.color;
        this.ctx.lineWidth = graph.lineWidth;
        this.ctx.beginPath();
        this.ctx.moveTo(this.dimensions.centerX, this.dimensions.centerY);
        this.ctx.lineTo(endX, endY);
        this.ctx.stroke();

        // Draw arrowhead
        this.ctx.fillStyle = graph.color;
        this.ctx.beginPath();
        this.ctx.moveTo(endX, endY);
        this.ctx.lineTo(
            endX - CONSTANTS.GRAPH.ARROW_SIZE * Math.cos(angleRad - CONSTANTS.GRAPH.ARROW_ANGLE),
            endY - CONSTANTS.GRAPH.ARROW_SIZE * Math.sin(angleRad - CONSTANTS.GRAPH.ARROW_ANGLE)
        );
        this.ctx.lineTo(
            endX - CONSTANTS.GRAPH.ARROW_SIZE * Math.cos(angleRad + CONSTANTS.GRAPH.ARROW_ANGLE),
            endY - CONSTANTS.GRAPH.ARROW_SIZE * Math.sin(angleRad + CONSTANTS.GRAPH.ARROW_ANGLE)
        );
        this.ctx.closePath();
        this.ctx.fill();

        // Draw label
        const labelOffset = 30;
        this.ctx.fillStyle = graph.color;
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(
            `${label} (${graph.justices} Justices)`,
            endX + Math.cos(angleRad) * labelOffset,
            endY + Math.sin(angleRad) * labelOffset
        );

        this.ctx.font = '12px Arial';
        this.ctx.fillText(
            `Strength: ${graph.strength.toFixed(1)}`,
            endX + Math.cos(angleRad) * labelOffset,
            endY + Math.sin(angleRad) * labelOffset + 16
        );
    }

    private drawBalloonMarkers(): void {
        this.balloonMarkers.forEach(marker => {
            const color = marker.type === 'majority'
                ? 'rgba(154, 205, 50, 0.9)'
                : 'rgba(0, 0, 0, 0.85)';

            // Draw balloon body
            this.ctx.fillStyle = color;
            this.roundRect(
                marker.x - CONSTANTS.BALLOON.WIDTH / 2,
                marker.y - CONSTANTS.BALLOON.HEIGHT,
                CONSTANTS.BALLOON.WIDTH,
                CONSTANTS.BALLOON.HEIGHT,
                CONSTANTS.BALLOON.RADIUS
            );
            this.ctx.fill();

            // Draw balloon tail
            this.ctx.beginPath();
            this.ctx.moveTo(marker.x, marker.y);
            this.ctx.lineTo(marker.x - CONSTANTS.BALLOON.TAIL_WIDTH, marker.y - CONSTANTS.BALLOON.TAIL_HEIGHT);
            this.ctx.lineTo(marker.x + CONSTANTS.BALLOON.TAIL_WIDTH, marker.y - CONSTANTS.BALLOON.TAIL_HEIGHT);
            this.ctx.closePath();
            this.ctx.fill();

            // Draw text
            const textColor = marker.type === 'majority' ? '#000' : '#fff';

            this.ctx.fillStyle = textColor;
            this.ctx.font = 'bold 13px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(marker.title, marker.x, marker.y - 40);

            this.ctx.font = '11px Arial';
            this.ctx.fillText(marker.content, marker.x, marker.y - 23);

            // Store bounds for interaction
            marker.bounds = {
                x: marker.x - CONSTANTS.BALLOON.WIDTH / 2,
                y: marker.y - CONSTANTS.BALLOON.HEIGHT,
                width: CONSTANTS.BALLOON.WIDTH,
                height: CONSTANTS.BALLOON.HEIGHT
            };
        });
    }

    private drawLegend(): void {
        const legendX = 20;
        const legendY = 20;
        const legendWidth = 280;
        const legendHeight = 120;

        // Background
        this.ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
        this.ctx.fillRect(legendX, legendY, legendWidth, legendHeight);
        this.ctx.strokeStyle = '#ccc';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(legendX, legendY, legendWidth, legendHeight);

        // Title
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'left';
        this.ctx.fillText('Roe v. Wade (1973)', legendX + 10, legendY + 25);

        // X Graph line
        this.ctx.strokeStyle = this.caseDetails.majority.color;
        this.ctx.lineWidth = 3;
        this.ctx.beginPath();
        this.ctx.moveTo(legendX + 10, legendY + 50);
        this.ctx.lineTo(legendX + 40, legendY + 50);
        this.ctx.stroke();

        this.ctx.fillStyle = '#333';
        this.ctx.font = '13px Arial';
        this.ctx.fillText(
            `X - Majority Opinion (${this.caseDetails.majority.justices} Justices)`,
            legendX + 50,
            legendY + 54
        );

        // Y Graph line
        this.ctx.strokeStyle = this.caseDetails.dissent.color;
        this.ctx.lineWidth = 3;
        this.ctx.beginPath();
        this.ctx.moveTo(legendX + 10, legendY + 75);
        this.ctx.lineTo(legendX + 40, legendY + 75);
        this.ctx.stroke();

        this.ctx.fillStyle = '#333';
        this.ctx.font = '13px Arial';
        this.ctx.fillText(
            `Y - Dissenting Opinion (${this.caseDetails.dissent.justices} Justices)`,
            legendX + 50,
            legendY + 79
        );

        // Note
        this.ctx.font = 'italic 11px Arial';
        this.ctx.fillStyle = '#666';
        this.ctx.fillText(
            'Graph length & angle proportional to justices & arguments',
            legendX + 10,
            legendY + 105
        );
    }

    private drawProgressBar(): void {
        const barWidth = 300;
        const barHeight = 8;
        const barX = this.dimensions.width - barWidth - 20;
        const barY = this.dimensions.height - 40;

        // Background
        this.ctx.fillStyle = 'rgba(200, 200, 200, 0.5)';
        this.ctx.fillRect(barX, barY, barWidth, barHeight);

        // Progress
        const progress = this.animation.currentTime / this.animation.duration;
        this.ctx.fillStyle = '#4CAF50';
        this.ctx.fillRect(barX, barY, barWidth * progress, barHeight);

        // Border
        this.ctx.strokeStyle = '#999';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(barX, barY, barWidth, barHeight);

        // Time label
        const currentSeconds = Math.floor(this.animation.currentTime / 1000);
        const totalSeconds = Math.floor(this.animation.duration / 1000);

        this.ctx.fillStyle = '#333';
        this.ctx.font = '12px Arial';
        this.ctx.textAlign = 'right';
        this.ctx.fillText(
            `${currentSeconds}s / ${totalSeconds}s`,
            barX + barWidth,
            barY - 5
        );
    }

    private drawPhaseDescription(): void {
        let currentPhase = this.phases[0];
        for (let i = this.phases.length - 1; i >= 0; i--) {
            if (this.animation.currentTime >= this.phases[i].time) {
                currentPhase = this.phases[i];
                break;
            }
        }

        const boxWidth = 400;
        const boxHeight = 60;
        const boxX = (this.dimensions.width - boxWidth) / 2;
        const boxY = this.dimensions.height - 100;

        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        this.roundRect(boxX, boxY, boxWidth, boxHeight, 8);
        this.ctx.fill();

        this.ctx.fillStyle = '#fff';
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(
            currentPhase.description,
            this.dimensions.width / 2,
            boxY + 30
        );

        const phaseNumber = this.phases.indexOf(currentPhase) + 1;
        this.ctx.font = '13px Arial';
        this.ctx.fillText(
            `Phase ${phaseNumber} of ${this.phases.length}`,
            this.dimensions.width / 2,
            boxY + 48
        );
    }

    private roundRect(x: number, y: number, width: number, height: number, radius: number): void {
        this.ctx.beginPath();
        this.ctx.moveTo(x + radius, y);
        this.ctx.lineTo(x + width - radius, y);
        this.ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
        this.ctx.lineTo(x + width, y + height - radius);
        this.ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
        this.ctx.lineTo(x + radius, y + height);
        this.ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
        this.ctx.lineTo(x, y + radius);
        this.ctx.quadraticCurveTo(x, y, x + radius, y);
        this.ctx.closePath();
    }

    private handleMouseMove(e: MouseEvent): void {
        const rect = this.canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        let hoveredMarker = null;

        for (const marker of this.balloonMarkers) {
            if (marker.bounds &&
                mouseX >= marker.bounds.x &&
                mouseX <= marker.bounds.x + marker.bounds.width &&
                mouseY >= marker.bounds.y &&
                mouseY <= marker.bounds.y + marker.bounds.height) {
                hoveredMarker = marker;
                break;
            }
        }

        const tooltip = document.getElementById('tooltip');
        if (hoveredMarker) {
            tooltip.innerHTML = `
                <strong>${escapeHtml(hoveredMarker.title)}</strong><br>
                ${escapeHtml(hoveredMarker.content)}<br>
                <em style="font-size: 11px; color: #666;">Click for details</em>
            `;
            tooltip.style.display = 'block';
            tooltip.style.left = (mouseX + 10) + 'px';
            tooltip.style.top = (mouseY + 10) + 'px';
            this.canvas.style.cursor = 'pointer';
        } else {
            tooltip.style.display = 'none';
            this.canvas.style.cursor = 'default';
        }
    }

    private handleClick(e: MouseEvent): void {
        const rect = this.canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;

        for (const marker of this.balloonMarkers) {
            if (marker.bounds &&
                mouseX >= marker.bounds.x &&
                mouseX <= marker.bounds.x + marker.bounds.width &&
                mouseY >= marker.bounds.y &&
                mouseY <= marker.bounds.y + marker.bounds.height) {
                this.showDetailModal(marker);
                break;
            }
        }
    }

    private showDetailModal(marker: BalloonMarker): void {
        const modal = document.getElementById('detailModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalContent = document.getElementById('modalContent');

        if (!modal || !modalTitle || !modalContent) return;

        modalTitle.textContent = marker.title;

        // Security: Escape user-facing content
        let detailsHtml = `<p><strong>${escapeHtml(marker.content)}</strong></p><ul>`;
        marker.details.forEach(detail => {
            detailsHtml += `<li>${escapeHtml(detail)}</li>`;
        });
        detailsHtml += '</ul>';

        modalContent.innerHTML = detailsHtml;
        modal.style.display = 'flex';
    }
}

// Export class for module use
export default LegalBattleVisualization;

// Modal control - make types compatible with window object
declare global {
    interface Window {
        closeModal?: () => void;
        visualization?: LegalBattleVisualization | null;
    }
}

// Modal control
window.closeModal = function(): void {
    const modal = document.getElementById('detailModal');
    if (modal) {
        modal.style.display = 'none';
    }
};

// Close modal when clicking outside
window.onclick = function(event: MouseEvent): void {
    const modal = document.getElementById('detailModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
};

// Initialize visualization when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.visualization = new LegalBattleVisualization();
    });
} else {
    window.visualization = new LegalBattleVisualization();
}
