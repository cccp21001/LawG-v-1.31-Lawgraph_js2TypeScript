//! Type definitions for Roe v. Wade Legal Battle Visualization
//! Comprehensive type safety using Rust's type system

use serde::{Deserialize, Serialize};

/// Represents a single phase in the legal battle animation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BattlePhase {
    /// Time in milliseconds when this phase begins
    pub time: f64,
    /// Strength of X graph (Majority Opinion) - scale 0-11
    pub x_strength: f64,
    /// Strength of Y graph (Dissenting Opinion) - scale 0-11
    pub y_strength: f64,
    /// Angle in degrees for X graph vector
    pub x_angle: f64,
    /// Angle in degrees for Y graph vector
    pub y_angle: f64,
    /// Description of what happens in this phase
    pub description: String,
}

/// Graph state representing one side's legal argument
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphState {
    /// Current strength/intensity of the argument
    pub strength: f64,
    /// Current angle in degrees
    pub angle: f64,
    /// Number of justices supporting this opinion
    pub justices: u8,
    /// Color for rendering the graph (hex format)
    pub color: String,
    /// Line width for rendering
    pub line_width: f64,
}

/// Legal opinion details (Majority or Dissent)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OpinionDetails {
    /// Number of justices supporting this opinion
    pub justices: u8,
    /// Color for visual representation
    pub color: String,
    /// Array of legal arguments/reasoning
    pub arguments: Vec<String>,
}

/// Complete case details for Roe v. Wade
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CaseDetails {
    /// Majority opinion information
    pub majority: OpinionDetails,
    /// Dissenting opinion information
    pub dissent: OpinionDetails,
}

/// Animation configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnimationConfig {
    /// Total duration of animation in milliseconds
    pub duration: f64,
    /// Current playback time in milliseconds
    pub current_time: f64,
    /// Whether animation is currently playing
    pub is_playing: bool,
    /// Last timestamp for delta calculation
    pub last_timestamp: f64,
}

/// Canvas dimensions and center point
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct CanvasDimensions {
    /// Canvas width in pixels
    pub width: f64,
    /// Canvas height in pixels
    pub height: f64,
    /// Center X coordinate
    pub center_x: f64,
    /// Center Y coordinate
    pub center_y: f64,
}

/// Point in 2D space
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct Point2D {
    pub x: f64,
    pub y: f64,
}

/// Balloon marker type
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum MarkerType {
    Majority,
    Dissent,
}

/// Interactive balloon marker showing key arguments
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BalloonMarker {
    /// X coordinate position
    pub x: f64,
    /// Y coordinate position
    pub y: f64,
    /// Type of marker (majority or dissent)
    pub marker_type: MarkerType,
    /// Main title text
    pub title: String,
    /// Brief content summary
    pub content: String,
    /// Detailed argument list
    pub details: Vec<String>,
}

/// Rectangular bounds for hit detection
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct BoundingBox {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

impl BoundingBox {
    /// Check if a point is inside this bounding box
    pub fn contains_point(&self, point: Point2D) -> bool {
        point.x >= self.x
            && point.x <= self.x + self.width
            && point.y >= self.y
            && point.y <= self.y + self.height
    }
}

/// Vector endpoint calculation result
#[derive(Debug, Clone, Copy, Serialize, Deserialize)]
pub struct VectorEndpoint {
    pub x: f64,
    pub y: f64,
    pub angle: f64,
    pub length: f64,
}

/// Constants used throughout the application
pub struct Constants;

impl Constants {
    // Animation
    pub const DURATION: f64 = 40000.0;

    // Colors
    pub const COLOR_MAJORITY: &'static str = "#9ACD32";
    pub const COLOR_DISSENT: &'static str = "#000000";
    pub const COLOR_BATTLE_POINT: &'static str = "#ff6b6b";
    pub const COLOR_GRID_LINE: &'static str = "#e0e0e0";
    pub const COLOR_GRID_AXIS: &'static str = "#999999";

    // Graph rendering
    pub const GRAPH_LINE_WIDTH: f64 = 3.0;
    pub const GRAPH_ARROW_SIZE: f64 = 15.0;
    pub const GRAPH_ARROW_ANGLE: f64 = std::f64::consts::PI / 6.0;
    pub const GRAPH_SCALE_FACTOR: f64 = 30.0;

    // Battle point
    pub const BATTLE_POINT_RADIUS: f64 = 8.0;
    pub const BATTLE_POINT_PULSE_AMPLITUDE: f64 = 3.0;
    pub const BATTLE_POINT_PULSE_SPEED: f64 = 200.0;

    // Balloon markers
    pub const BALLOON_WIDTH: f64 = 180.0;
    pub const BALLOON_HEIGHT: f64 = 60.0;
    pub const BALLOON_RADIUS: f64 = 10.0;
    pub const BALLOON_TAIL_WIDTH: f64 = 10.0;
    pub const BALLOON_TAIL_HEIGHT: f64 = 15.0;

    // Grid
    pub const GRID_SPACING: f64 = 50.0;
}

/// Easing functions
pub mod easing {
    /// Ease-in-out quadratic easing
    pub fn ease_in_out_quad(t: f64) -> f64 {
        if t < 0.5 {
            2.0 * t * t
        } else {
            1.0 - (-2.0 * t + 2.0).powi(2) / 2.0
        }
    }

    /// Linear interpolation
    pub fn lerp(start: f64, end: f64, t: f64) -> f64 {
        start + (end - start) * t
    }
}
