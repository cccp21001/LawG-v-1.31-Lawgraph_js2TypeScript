# 🦀 Rust + WebAssembly Build Guide

## Quick Start (3 Steps)

```bash
# 1. Build Rust to WebAssembly
./build.sh

# 2. Start local server
python -m http.server 8080

# 3. Open browser
open http://localhost:8080
```

---

## Prerequisites

### 1. Install Rust

```bash
# Install Rust toolchain
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Verify installation
rust --version
cargo --version
```

### 2. Install wasm-pack

```bash
# Install wasm-pack (Rust to WASM compiler)
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh

# Verify installation
wasm-pack --version
```

### 3. Local Web Server (Choose One)

```bash
# Python 3
python -m http.server 8080

# Python 2
python -m SimpleHTTPServer 8080

# Node.js (install http-server)
npx http-server -p 8080

# Rust (install miniserve)
cargo install miniserve
miniserve . -p 8080
```

---

## Build Commands

### Development Build (Fast, with debug symbols)

```bash
wasm-pack build --target web --dev --out-dir pkg
```

- Faster compilation
- Includes debug symbols
- Larger binary size
- Better error messages

### Production Build (Optimized)

```bash
wasm-pack build --target web --release --out-dir pkg
```

- Slower compilation
- Optimized for size and speed
- No debug symbols
- Smallest binary

### Using the Build Script

```bash
# Make executable (first time only)
chmod +x build.sh

# Run build
./build.sh
```

---

## Project Structure After Build

```
roe-v-wade-visualization/
├── src/              # Rust source code
│   ├── lib.rs
│   └── types.rs
│
├── pkg/              # Generated WASM files
│   ├── roe_v_wade_visualization_bg.wasm
│   ├── roe_v_wade_visualization.js
│   ├── roe_v_wade_visualization.d.ts
│   └── package.json
│
├── js/               # JavaScript glue code
│   └── main.js
│
├── css/              # Stylesheets
│   └── style.css
│
├── Cargo.toml        # Rust dependencies
├── build.sh          # Build script
└── index.html        # Main HTML file
```

---

## Troubleshooting

### Issue: `wasm-pack: command not found`

```bash
# Reinstall wasm-pack
curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh

# Or install via cargo
cargo install wasm-pack
```

### Issue: `error: could not compile`

```bash
# Update Rust
rustup update

# Clean and rebuild
cargo clean
./build.sh
```

### Issue: WASM module not loading

```bash
# Make sure you're using a local server (NOT file://)
python -m http.server 8080

# Check browser console for errors
# Ensure browser supports WebAssembly
```

### Issue: Module not found errors

```bash
# Check that pkg/ directory exists
ls pkg/

# Rebuild if needed
./build.sh
```

---

## Development Workflow

### 1. Edit Rust Code

```bash
# Open in your favorite editor
code src/lib.rs
vim src/types.rs
```

### 2. Rebuild

```bash
# Quick rebuild (dev mode)
wasm-pack build --target web --dev

# Or use build script
./build.sh
```

### 3. Test in Browser

```bash
# Refresh browser (Ctrl+Shift+R for hard reload)
```

### 4. Auto-rebuild on Changes (Optional)

```bash
# Install cargo-watch
cargo install cargo-watch

# Auto-rebuild on file changes
cargo watch -s 'wasm-pack build --target web'
```

---

## Optimization Tips

### 1. Enable Size Optimizations

Already configured in `Cargo.toml`:

```toml
[profile.release]
opt-level = "z"     # Optimize for size
lto = true          # Link Time Optimization
codegen-units = 1   # Single codegen unit
strip = true        # Strip symbols
panic = "abort"     # Smaller panic handler
```

### 2. Use wasm-opt (Optional)

```bash
# Install Binaryen tools
# macOS
brew install binaryen

# Ubuntu/Debian
sudo apt-get install binaryen

# Optimize WASM file
wasm-opt -Oz pkg/roe_v_wade_visualization_bg.wasm -o pkg/optimized.wasm
```

### 3. Enable Compression

Most web servers automatically gzip .wasm files:

```
Original:  150 KB
Gzipped:   ~50 KB (67% reduction)
```

---

## Testing

### Run Rust Tests

```bash
# Run all tests
cargo test

# Run with output
cargo test -- --nocapture

# Run specific test
cargo test test_name
```

### Browser Testing

```bash
# Firefox
wasm-pack test --headless --firefox

# Chrome
wasm-pack test --headless --chrome

# All browsers
wasm-pack test --headless --firefox --chrome
```

---

## Deployment

### 1. Build for Production

```bash
./build.sh
```

### 2. Upload to Web Host

Upload these files:
- `index.html`
- `css/` folder
- `js/` folder
- `pkg/` folder

### 3. Configure Server

Ensure your server sends correct MIME types:

```
.wasm -> application/wasm
.js   -> application/javascript
.html -> text/html
```

### 4. Popular Hosting Options

**GitHub Pages:**
```bash
# Create gh-pages branch
git checkout -b gh-pages
git add pkg/ js/ css/ index.html
git commit -m "Deploy"
git push origin gh-pages
```

**Netlify:**
```bash
# Deploy directly
netlify deploy --prod
```

**Vercel:**
```bash
# Deploy with vercel
vercel --prod
```

---

## Performance Monitoring

### Browser DevTools

1. Open DevTools (F12)
2. Go to Performance tab
3. Record while animation plays
4. Check for:
   - Frame rate (should be 60 FPS)
   - Memory usage
   - WASM execution time

### Rust Profiling

```bash
# Profile build
cargo build --release --timings

# Profile runtime (Linux only)
perf record target/release/roe_v_wade_visualization
perf report
```

---

## Common Issues

### CORS Errors

❌ **Wrong:** Opening `file:///path/to/index.html`  
✅ **Correct:** Using local server `http://localhost:8080`

### Memory Issues

```rust
// Use wee_alloc for smaller footprint
#[cfg(feature = "wee_alloc")]
#[global_allocator]
static ALLOC: wee_alloc::WeeAlloc = wee_alloc::WeeAlloc::INIT;
```

### Large Binary Size

```bash
# Check size
ls -lh pkg/*.wasm

# Analyze what's taking space
twiggy top pkg/roe_v_wade_visualization_bg.wasm

# Optimize
wasm-opt -Oz input.wasm -o output.wasm
```

---

## Next Steps

1. ✅ Build project successfully
2. ✅ Test in browser
3. ✅ Modify Rust code
4. ✅ Optimize for production
5. ✅ Deploy to web host

---

## Need Help?

- **Rust Documentation**: https://doc.rust-lang.org/
- **wasm-pack Guide**: https://rustwasm.github.io/wasm-pack/
- **Rust Discord**: https://discord.gg/rust-lang
- **WebAssembly Docs**: https://webassembly.org/docs/

---

**Happy Coding! 🦀**
