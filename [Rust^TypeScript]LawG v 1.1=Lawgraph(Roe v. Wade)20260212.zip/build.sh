#!/bin/bash

echo "🦀 Building Roe v. Wade Visualization (Rust -> WebAssembly)"
echo "============================================================"

# Check if wasm-pack is installed
if ! command -v wasm-pack &> /dev/null
then
    echo "❌ wasm-pack is not installed!"
    echo "📦 Install it with: curl https://rustwasm.github.io/wasm-pack/installer/init.sh -sSf | sh"
    exit 1
fi

# Build the project
echo "🔨 Compiling Rust to WebAssembly..."
wasm-pack build --target web --out-dir pkg --release

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📦 Output directory: pkg/"
    echo ""
    echo "🚀 To run the project:"
    echo "   1. Use a local web server (e.g., python -m http.server 8080)"
    echo "   2. Open http://localhost:8080 in your browser"
    echo ""
else
    echo "❌ Build failed!"
    exit 1
fi
