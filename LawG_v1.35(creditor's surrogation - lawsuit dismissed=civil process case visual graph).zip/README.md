# ⚖️ LawG v1.35 — Lawgraph 채권자대위권(surrogation) v2

## 프로젝트 개요

LawG v1.35는 법률 판례와 학설을 교차 그래프(Canvas) 기반으로 시각화하는 정적 웹 애플리케이션입니다.

4가지 판례/학설을 지원하며, 각각 2단계(Stage 1 → Stage 2) 애니메이션으로 법적 쟁점의 대립과 결과를 시각적으로 표현합니다.

## v1.35 수정사항 (v1.33 대비)

### 🔧 핵심 버그 수정
- **Canvas가 비어 보이는 문제 해결**: `style.css` 파일에 JavaScript 코드가 섞여 있어서 CSS가 전혀 로드되지 않던 문제를 근본적으로 해결
  - `css/style.css` → 실제 CSS 스타일시트로 새로 작성
  - `js/lawgraph.js` → 시각화 엔진 JavaScript 코드를 올바른 위치에 분리 저장
- **Play 버튼 동작 정상화**: CSS 미로딩으로 인한 레이아웃 깨짐과 Canvas 크기 0px 문제 해결
- **초기 프리뷰 정상 렌더링**: 페이지 로드 시 즉시 그래프 프리뷰가 표시됨

### ✂️ 기능 변경
- **ZIP 다운로드 버튼/링크 삭제**: `index.html`에서 `download.html` 링크 제거
- **`download.html` 파일 미포함**: 프로그램 내 ZIP 다운로드 기능 완전 제거
- **버전 표기 업데이트**: v1.33 → v1.35

### 🎈 Balloon 위치 수정
- **Stage 2 X/Y 메모툴팁(벌룬) 위치 수정**: 그래프를 가리지 않도록 재배치
  - X balloon: 그래프 끝점 바로 아래에 배치 (화살표 머리 따라감)
  - Y balloon: 그래프 끝점 바로 위에 배치 (중앙 상단 약간 우측)
  - Preview badge: 좌측 하단으로 이동
- **Y 그래프 grey1 끝부분 화살표 머리 추가**: stage2의 Y그래프 grey→pink→grey 그라디언트에서 첫 번째 grey 세그먼트 끝(t=0.35)에 회색 화살표 머리 추가

### 🆕 영문 번역 케이스 추가 (풀다운 메뉴 2-1)
- **Creditor's Surrogation (2017Da228618)** — 채권자대위권의 영문 번역 버전
  - 풀다운 메뉴 2번(한국어)과 3번(Roe v. Dobbs) 사이에 2-1번으로 삽입
  - 모든 라벨, 논거, 타임라인 설명이 영어로 번역
  - `제3채무자` → `Trustees`, `채권자대위권` → `Creditor's Surrogation`
  - 별도의 영문 정보 카드(Stage 1 EN, Stage 2 EN) 제공
  - 회색 Z 벡터 라벨도 영문화: `Z (② Debtor)` / `Passive (Subrogated)`
  - 소 각하 배지: `Dismissed` / `Reversal — No preserved right`
  - 귀무가설/대립가설: `Null Hypothesis (H₀)` / `Alternative Hypothesis (H₁)`

## 현재 완성된 기능

1. **4가지 판례/학설 시각화**
   - 채권자대위권(surrogation) (2017다228618) — 한국어
   - Creditor's Surrogation (2017Da228618) — English (번역)
   - Roe v. Wade → Dobbs v. Jackson — English
   - Habermas-Luhmann-Kontroverse (~1971) — Deutsch

2. **2단계 애니메이션**
   - Stage 1 → Transition → Stage 2 자동 진행
   - Play / Pause / Reset 버튼 제어
   - 실시간 진행 표시줄

3. **인터랙티브 기능**
   - 판례 선택 드롭다운 (4개 케이스)
   - 노란색 풍선(balloon) 위에 마우스 오버 → 상세 툴팁
   - 풍선 클릭 → 모달 팝업으로 상세 정보

4. **시각화 요소**
   - X/Y 그래프 벡터 (방향+강도)
   - 검은색 호(Arc) 화살표로 승자 표시
   - 녹색 "Ground Truth" 배지
   - 빨간색 "소 각하" / "Dismissed" 배지 (채권자대위권 케이스)
   - Z 벡터 (회색, 채무자/甲 — 패시브)
   - Y그래프 grey1 끝부분 회색 화살표 머리 (채권자대위권 케이스)

## 파일 구조

```
index.html              — 메인 시각화 페이지
css/
  └── style.css         — 스타일시트 (다크 테마)
js/
  └── lawgraph.js       — 시각화 엔진 (Canvas 2D)
README.md               — 프로젝트 설명서
```

## 기능 엔트리 URI

| 경로 | 설명 |
|------|------|
| `/index.html` | 메인 시각화 페이지 |
| `/css/style.css` | 스타일시트 |
| `/js/lawgraph.js` | 시각화 엔진 (ES module) |

## 풀다운 메뉴 구성

| 순번 | value | 표시 텍스트 | 언어 |
|------|-------|------------|------|
| 1 | `creditorSubrogation` | 채권자대위권(surrogation) (2017다228618) | KR |
| 2-1 | `creditorSubrogationEN` | Creditor's Surrogation (2017Da228618) | EN |
| 2 | `roeVsDobbs` | Roe v. Wade → Dobbs v. Jackson | EN |
| 3 | `habermasLuhmann` | Habermas-Luhmann-Kontroverse (~1971) | DE |

## 미구현 기능

- 소스코드 ZIP 다운로드 기능 (의도적으로 제거됨, 채팅 패널에서 별도 제공)
- 모바일 터치 제스처 지원
- 판례 데이터 외부 JSON 파일 분리
- 애니메이션 속도 조절 슬라이더

## 권장 다음 단계

1. 판례 데이터를 외부 JSON으로 분리하여 확장성 확보
2. 모바일 터치 이벤트 지원 추가
3. 애니메이션 속도 조절 기능
4. 추가 판례 케이스 확장
5. 접근성(a11y) 개선 — ARIA 라벨 등

## 기술 스택

- **HTML5 Canvas 2D** — 그래프 렌더링
- **ES Modules** — JavaScript 모듈 시스템
- **Inter (Google Fonts)** — 타이포그래피
- **Font Awesome 6.4** — 아이콘
- **CSS3** — 다크 테마, 반응형 레이아웃
