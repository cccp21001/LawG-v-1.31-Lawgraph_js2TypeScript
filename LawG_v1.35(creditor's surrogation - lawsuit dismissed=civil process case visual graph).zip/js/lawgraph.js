/* ===================================================
   LawG v1.35 — Lawgraph Visualization Engine
   js/lawgraph.js
   =================================================== */

const CONFIG = {
  STAGE1_DURATION: 7000,
  STAGE2_DURATION: 7000,
  TRANSITION_DURATION: 750,

  COLORS: {
    BLUE: '#2563EB',
    PINK: '#DB2777',
    GREEN: '#16A34A',
    BLACK: '#111111',
    GRID_LINE: '#e8e8e8',
    GRID_AXIS: '#9CA3AF',
    BATTLE_POINT: '#EF4444',
    TOOLTIP_BG: '#FFFDE7',
    TOOLTIP_BORDER: '#FBC02D',
    GRAY: '#9CA3AF',
  },

  GRAPH: {
    LINE_WIDTH: 3,
    ARROW_SIZE: 14,
    ARROW_ANGLE: Math.PI / 6,
    SCALE_FACTOR: 22,
  },

  ARC: {
    LINE_WIDTH: 4.5,
    ARROW_SIZE: 14,
    RADIUS: 62,
  },

  BATTLE_POINT: {
    RADIUS: 6,
    PULSE_AMPLITUDE: 3,
    PULSE_SPEED: 250,
  },
};

const Ease = {
  inOutCubic(t) {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  },
  lerp(a, b, t) {
    return a + (b - a) * t;
  },
  clamp01(t) {
    return Math.max(0, Math.min(1, t));
  },
};

function escapeHtml(str = '') {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/* ---- Case Data ---- */
const CASE_DATA = {
  roeVsDobbs: {
    preview: {
      title: 'Dobbs v. Jackson (2022)',
      subtitle: 'Overruling Roe v. Wade',
      info: 'Supreme Court Decision: 6-3 — Roe Overruled',
      url: 'https://www.oyez.org/cases/2021/19-1392',
      x: {
        label: 'X (Plaintiff)',
        ground: 'Constitutional textualism / Stare decisis reexamined',
        arguments: [
          'Constitution does not confer right to abortion',
          'Roe was egregiously wrong from the start',
          'Authority returned to the people',
          'No basis in text, history, or structure',
        ],
      },
      y: {
        label: 'Y (Defendant)',
        ground: 'Precedent / Substantive due process',
        arguments: [
          'Overruling Roe undermines Court legitimacy',
          'Women lose constitutional protection',
          'Stare decisis abandoned without justification',
        ],
      },
    },
    stage1: {
      title: 'Roe v. Wade (1973)',
      subtitle: 'Legal Battle Timeline Visualization',
      info: 'Supreme Court Decision: 7-2 Majority Opinion',
      url: 'https://www.oyez.org/cases/1971/70-18',
      x: {
        label: 'X (Plaintiff)',
        ground: '14th Amendment Due Process / Privacy',
        arguments: [
          'Privacy rights are protected',
          'Right to choose recognized',
          'Trimester framework balances interests',
          'Constitutional liberty protected',
        ],
      },
      y: {
        label: 'Y (Defendant)',
        ground: 'Legislative authority / States rights',
        arguments: [
          'No constitutional basis for abortion rights',
          'Court exceeded authority',
          'Legislatures should decide',
        ],
      },
    },
    stage2: {
      title: 'Dobbs v. Jackson (2022)',
      subtitle: 'Overruling Roe v. Wade',
      info: 'Supreme Court Decision: 6-3 — Roe Overruled',
      url: 'https://www.oyez.org/cases/2021/19-1392',
      x: {
        label: 'X (Plaintiff)',
        ground: 'Constitutional textualism / Stare decisis reexamined',
        arguments: [
          'Constitution does not confer right to abortion',
          'Roe was egregiously wrong from the start',
          'Authority returned to the people',
          'No basis in text, history, or structure',
        ],
      },
      y: {
        label: 'Y (Defendant)',
        ground: 'Precedent / Substantive due process',
        arguments: [
          'Overruling Roe undermines Court legitimacy',
          'Women lose constitutional protection',
          'Stare decisis abandoned without justification',
        ],
      },
    },
  },

  creditorSubrogation: {
    preview: {
      title: '채권자대위권(surrogation) (2017다228618)',
      subtitle: '피보전권리의 존부 판단',
      info: '대법원 판결: 파기자판(각하) — 피고들 승',
      url: 'https://www.scourt.go.kr/',
      x: {
        label: '원고(대위청구)',
        ground: '조정조서의 기판력 주장',
        arguments: [
          '재판상 조정에 기초한 피보전권리',
          '확정판결 효력 주장',
        ],
      },
      y: {
        label: '피고들(제3채무자)',
        ground: '강행법규 우선 / 제3자 보호',
        arguments: [
          '조정 내용이 강행법규 위반으로 무효',
          '소송목적 권리취득은 허용 불가',
          '제3채무자는 피보전권리 존부 다툴 수 있다',
          '조정 당사자 아닌 자에게는 효력 없음',
        ],
      },
    },
    stage1: {
      title: '채권자대위권(surrogation) - 조정(기판력 : Res Judicata)성립 단계',
      subtitle: '원고 vs 甲 등 - 재판상 조정(기판력 : Res Judicata)',
      info: '조정 성립: 원고(채권자) 승',
      url: 'https://www.scourt.go.kr/',
      x: {
        label: '원고(채권자)',
        ground: '재판상 조정 / 확정판결 효력',
        arguments: [
          '甲 등에 대한 소유권이전등기청구권 보유',
          '재판상 조정으로 확정된 권리',
          '조정조서는 확정판결과 동일한 효력',
          '피보전권리가 인정된다',
        ],
      },
      y: {
        label: '甲 등(채무자)',
        ground: '조정의 실질 검토 필요',
        arguments: [
          '조정 내용의 실질적 문제',
          '강행법규 위반 가능성',
        ],
      },
    },
    stage2: {
      title: '채권자대위권(surrogation) (2017다228618)',
      subtitle: '피보전권리의 존부 판단',
      info: '대법원 판결: 파기자판(각하) — 피고들 승',
      url: 'https://www.scourt.go.kr/',
      x: {
        label: '원고(대위청구)',
        ground: '조정조서의 기판력 주장',
        arguments: [
          '재판상 조정에 기초한 피보전권리',
          '확정판결 효력 주장',
        ],
      },
      y: {
        label: '피고들(제3채무자)',
        ground: '강행법규 우선 / 제3자 보호',
        arguments: [
          '조정 내용이 강행법규 위반으로 무효',
          '소송목적 권리취득은 허용 불가',
          '제3채무자는 피보전권리 존부 다툴 수 있다',
          '조정 당사자 아닌 자에게는 효력 없음',
        ],
      },
    },
  },

  creditorSubrogationEN: {
    preview: {
      title: "Creditor's Surrogation (2017Da228618)",
      subtitle: 'Determination of the Preserved Right',
      info: 'Supreme Court: Reversal & Dismissal — Defendants (Trustees) Win',
      url: 'https://www.scourt.go.kr/',
      x: {
        label: 'Plaintiff (Subrogation Claim)',
        ground: 'Res judicata of mediation protocol',
        arguments: [
          'Preserved right based on judicial mediation',
          'Asserting effect of final judgment',
        ],
      },
      y: {
        label: 'Defendants (Trustees)',
        ground: 'Mandatory rules prevail / Third-party protection',
        arguments: [
          'Mediation void for violating mandatory rules',
          'Acquisition of litigation rights not permitted',
          'Trustees may contest existence of preserved right',
          'Mediation has no effect on non-parties',
        ],
      },
    },
    stage1: {
      title: "Creditor's Surrogation — Mediation (Res Judicata) Established",
      subtitle: 'Plaintiff vs Debtor(s) — Judicial Mediation (Res Judicata)',
      info: 'Mediation Established: Plaintiff (Creditor) Wins',
      url: 'https://www.scourt.go.kr/',
      x: {
        label: 'Plaintiff (Creditor)',
        ground: 'Judicial mediation / Effect of final judgment',
        arguments: [
          'Holds right to claim ownership transfer registration',
          'Right confirmed through judicial mediation',
          'Mediation protocol has same effect as final judgment',
          'Preserved right is recognized',
        ],
      },
      y: {
        label: 'Debtor(s)',
        ground: 'Substantive review of mediation required',
        arguments: [
          'Substantive issues with mediation content',
          'Possible violation of mandatory rules',
        ],
      },
    },
    stage2: {
      title: "Creditor's Surrogation (2017Da228618)",
      subtitle: 'Determination of the Preserved Right',
      info: 'Supreme Court: Reversal & Dismissal — Defendants (Trustees) Win',
      url: 'https://www.scourt.go.kr/',
      x: {
        label: 'Plaintiff (Subrogation Claim)',
        ground: 'Res judicata of mediation protocol',
        arguments: [
          'Preserved right based on judicial mediation',
          'Asserting effect of final judgment',
        ],
      },
      y: {
        label: 'Defendants (Trustees)',
        ground: 'Mandatory rules prevail / Third-party protection',
        arguments: [
          'Mediation void for violating mandatory rules',
          'Acquisition of litigation rights not permitted',
          'Trustees may contest existence of preserved right',
          'Mediation has no effect on non-parties',
        ],
      },
    },
  },

  habermasLuhmann: {
    preview: {
      title: 'Luhmann — Antithese: Systemtheorie',
      subtitle: 'Autopoiesis & funktionale Differenzierung',
      info: 'Akademische Debatte: Luhmann setzt sich durch',
      url: 'https://www.lernhelfer.de/schuelerlexikon/politikwirtschaft/artikel/die-habermas-luhmann-kontroverse-theorie-der-gesellschaft',
      x: {
        label: 'Habermas',
        ground: 'Normative Vernunft / Rechtstheorie',
        arguments: [
          'Zwischen Fakten und Normen',
          'Elemente der Systemtheorie integriert',
        ],
      },
      y: {
        label: 'Luhmann',
        ground: 'Autopoiesis / Funktionale Differenzierung',
        arguments: [
          'Autopoietische Subsysteme',
          'Binäre Codes',
          'Funktionale Differenzierung',
          'Komplexität ist unvermeidbar',
        ],
      },
    },
    stage1: {
      title: 'Habermas — These: Normative Theorie (~1971)',
      subtitle: 'Kommunikative Rationalität & Lebenswelt',
      info: 'Akademische Debatte: Habermas dominiert',
      url: 'https://www.lernhelfer.de/schuelerlexikon/politikwirtschaft/artikel/die-habermas-luhmann-kontroverse-theorie-der-gesellschaft',
      x: {
        label: 'Habermas',
        ground: 'Kommunikatives Handeln / Konsens',
        arguments: [
          'Lebenswelt als Basis',
          'Kommunikative Rationalität',
          'Konsens durch Verständigung',
          'Demokratie durch Diskurs',
        ],
      },
      y: {
        label: 'Luhmann',
        ground: 'Komplexitätsreduktion / Funktion',
        arguments: [
          'Gesellschaft = System aus Kommunikation',
          'Normative Ansprüche sind naiv',
        ],
      },
    },
    stage2: {
      title: 'Luhmann — Antithese: Systemtheorie',
      subtitle: 'Autopoiesis & funktionale Differenzierung',
      info: 'Akademische Debatte: Luhmann setzt sich durch',
      url: 'https://www.lernhelfer.de/schuelerlexikon/politikwirtschaft/artikel/die-habermas-luhmann-kontroverse-theorie-der-gesellschaft',
      x: {
        label: 'Habermas',
        ground: 'Normative Vernunft / Rechtstheorie',
        arguments: [
          'Zwischen Fakten und Normen',
          'Elemente der Systemtheorie integriert',
        ],
      },
      y: {
        label: 'Luhmann',
        ground: 'Autopoiesis / Funktionale Differenzierung',
        arguments: [
          'Autopoietische Subsysteme',
          'Binäre Codes',
          'Funktionale Differenzierung',
          'Komplexität ist unvermeidbar',
        ],
      },
    },
  },
};

/* ---- Phase Keyframes ---- */
const PHASES = {
  roeVsDobbs: {
    stage1: [
      { time: 0, xStr: 3, yStr: 3, xAng: 25, yAng: -20, desc: 'Case filed' },
      { time: 1250, xStr: 5, yStr: 4, xAng: 32, yAng: -28, desc: 'Initial arguments' },
      { time: 2500, xStr: 7, yStr: 5, xAng: 40, yAng: -35, desc: 'Due process debate' },
      { time: 4000, xStr: 8, yStr: 5, xAng: 48, yAng: -32, desc: 'Trimester framework' },
      { time: 5250, xStr: 6, yStr: 6, xAng: 42, yAng: -38, desc: 'Dissent objects' },
      { time: 6500, xStr: 10, yStr: 4, xAng: 55, yAng: -25, desc: 'Decision: Roe majority wins' },
    ],
    stage2: [
      { time: 0, xStr: 3, yStr: 3, xAng: -22, yAng: 22, desc: 'Dobbs begins' },
      { time: 1250, xStr: 5, yStr: 5, xAng: -30, yAng: 30, desc: 'Stare decisis debate' },
      { time: 2500, xStr: 7, yStr: 6, xAng: -42, yAng: 35, desc: 'Textualist reading' },
      { time: 4000, xStr: 8, yStr: 5, xAng: -48, yAng: 30, desc: 'Roe attacked' },
      { time: 5250, xStr: 6, yStr: 6, xAng: -38, yAng: 38, desc: 'Strong dissent' },
      { time: 6500, xStr: 10, yStr: 4, xAng: -55, yAng: 22, desc: 'Decision: Dobbs wins' },
    ],
  },

  creditorSubrogation: {
    stage1: [
      { time: 0, xStr: 3, yStr: 3, xAng: 25, yAng: -20, desc: '소송제기' },
      { time: 1250, xStr: 5, yStr: 4, xAng: 32, yAng: -25, desc: '조정 진행' },
      { time: 2500, xStr: 6, yStr: 5, xAng: 40, yAng: -22, desc: '재판상 조정 성립' },
      { time: 4000, xStr: 7, yStr: 5, xAng: 48, yAng: -20, desc: '조정조서 효력' },
      { time: 5250, xStr: 8, yStr: 4, xAng: 52, yAng: -18, desc: '피보전권리 확보' },
      { time: 6500, xStr: 7, yStr: 3, xAng: 50, yAng: -20, desc: '원고 승' },
    ],
    stage2: [
      { time: 0, xStr: 3, yStr: 6, xAng: 22, yAng: -22, desc: '대위소송 제기' },
      { time: 1250, xStr: 4, yStr: 7, xAng: 30, yAng: -28, desc: '피고들 항변' },
      { time: 2500, xStr: 5, yStr: 8, xAng: 38, yAng: -25, desc: '소송목적 권리취득 검토' },
      { time: 4000, xStr: 6, yStr: 9, xAng: 45, yAng: -22, desc: '제3채무자 항변 가능' },
      { time: 5250, xStr: 7, yStr: 10, xAng: 48, yAng: -20, desc: '강행법규 우선' },
      { time: 6500, xStr: 7, yStr: 12, xAng: 52, yAng: -18, desc: '소 각하 — 피고들 승' },
    ],
  },

  creditorSubrogationEN: {
    stage1: [
      { time: 0, xStr: 3, yStr: 3, xAng: 25, yAng: -20, desc: 'Lawsuit filed' },
      { time: 1250, xStr: 5, yStr: 4, xAng: 32, yAng: -25, desc: 'Mediation in progress' },
      { time: 2500, xStr: 6, yStr: 5, xAng: 40, yAng: -22, desc: 'Judicial mediation established' },
      { time: 4000, xStr: 7, yStr: 5, xAng: 48, yAng: -20, desc: 'Mediation protocol in effect' },
      { time: 5250, xStr: 8, yStr: 4, xAng: 52, yAng: -18, desc: 'Preserved right secured' },
      { time: 6500, xStr: 7, yStr: 3, xAng: 50, yAng: -20, desc: 'Plaintiff wins' },
    ],
    stage2: [
      { time: 0, xStr: 3, yStr: 6, xAng: 22, yAng: -22, desc: 'Subrogation suit filed' },
      { time: 1250, xStr: 4, yStr: 7, xAng: 30, yAng: -28, desc: 'Defendants raise defense' },
      { time: 2500, xStr: 5, yStr: 8, xAng: 38, yAng: -25, desc: 'Review of litigation right acquisition' },
      { time: 4000, xStr: 6, yStr: 9, xAng: 45, yAng: -22, desc: 'Trustees may raise defense' },
      { time: 5250, xStr: 7, yStr: 10, xAng: 48, yAng: -20, desc: 'Mandatory rules prevail' },
      { time: 6500, xStr: 7, yStr: 12, xAng: 52, yAng: -18, desc: 'Dismissed — Defendants win' },
    ],
  },

  habermasLuhmann: {
    stage1: [
      { time: 0, xStr: 3, yStr: 3, xAng: 25, yAng: -20, desc: 'Debattenbeginn' },
      { time: 1250, xStr: 5, yStr: 4, xAng: 32, yAng: -25, desc: 'Habermas develops thesis' },
      { time: 2500, xStr: 6, yStr: 3, xAng: 40, yAng: -22, desc: 'Kommunikative Rationalität' },
      { time: 4000, xStr: 7, yStr: 4, xAng: 48, yAng: -25, desc: 'Lebenswelt' },
      { time: 5250, xStr: 8, yStr: 3, xAng: 52, yAng: -20, desc: 'Diskurs' },
      { time: 6500, xStr: 7, yStr: 3, xAng: 50, yAng: -20, desc: 'Habermas dominates' },
    ],
    stage2: [
      { time: 0, xStr: 3, yStr: 3, xAng: -22, yAng: 22, desc: 'Luhmann responds' },
      { time: 1250, xStr: 3, yStr: 5, xAng: -28, yAng: 30, desc: 'Autopoiesis' },
      { time: 2500, xStr: 3, yStr: 6, xAng: -25, yAng: 38, desc: 'Binary codes' },
      { time: 4000, xStr: 3, yStr: 7, xAng: -22, yAng: 45, desc: 'Functional differentiation' },
      { time: 5250, xStr: 3, yStr: 8, xAng: -20, yAng: 48, desc: 'Complexity management' },
      { time: 6500, xStr: 3, yStr: 7, xAng: -18, yAng: 52, desc: 'Luhmann dominates' },
    ],
  },
};

/* ===================================================
   LawGraphVisualization Class
   =================================================== */
class LawGraphVisualization {
  constructor() {
    this.canvas = document.getElementById('battleCanvas');
    if (!this.canvas) throw new Error('Canvas element #battleCanvas not found');

    this.ctx = this.canvas.getContext('2d');
    if (!this.ctx) throw new Error('2D context not available');

    this.tooltip = document.getElementById('tooltip');

    this.dim = { w: 0, h: 0, originX: 0, originY: 0, cx: 0, cy: 0 };

    this.state = {
      stage: 'preview',
      isPlaying: false,
      currentTime: 0,
      lastTimestamp: 0,
      animFrameId: null,
    };

    this.currentCaseType = 'creditorSubrogation';
    this.xGraph = { strength: 7, angle: 52, color: CONFIG.COLORS.BLUE };
    this.yGraph = { strength: 12, angle: -18, color: CONFIG.COLORS.PINK };
    this.winnerSide = 'y';
    this.showGroundTruth = true;
    this.balloons = [];
    this.xGraphEnd = null;
    this.yGraphEnd = null;

    this.init();
  }

  /** Returns true for both KR and EN creditor subrogation cases */
  _isCreditorCase() {
    return this.currentCaseType === 'creditorSubrogation' ||
           this.currentCaseType === 'creditorSubrogationEN';
  }

  init() {
    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());

    document.getElementById('playBtn')?.addEventListener('click', () => this.play());
    document.getElementById('pauseBtn')?.addEventListener('click', () => this.pause());
    document.getElementById('resetBtn')?.addEventListener('click', () => this.reset());
    document.getElementById('caseSelector')?.addEventListener('change', (e) => this.switchCase(e.target.value));
    document.getElementById('closeModalBtn')?.addEventListener('click', () => this.closeModal());
    document.getElementById('detailModal')?.addEventListener('click', (e) => {
      if (e.target.id === 'detailModal') this.closeModal();
    });

    this.canvas.addEventListener('mousemove', (e) => this.onMouseMove(e));
    this.canvas.addEventListener('click', (e) => this.onClick(e));

    this.switchCase('creditorSubrogation');
  }

  resizeCanvas() {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;

    this.ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.canvas.width = Math.max(1, Math.floor(rect.width * dpr));
    this.canvas.height = Math.max(1, Math.floor(rect.height * dpr));
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    this.dim.w = rect.width;
    this.dim.h = rect.height;
    this.dim.originX = rect.width * 0.38;
    this.dim.originY = rect.height * 0.5;
    this.dim.cx = rect.width / 2;
    this.dim.cy = rect.height / 2;

    this.draw();
  }

  switchCase(caseType) {
    this.pause();
    this.currentCaseType = caseType;

    const sel = document.getElementById('caseSelector');
    if (sel) sel.value = caseType;

    const allCards = [
      'roeInfo', 'dobbsInfo',
      'creditorStage1Info', 'creditorStage2Info',
      'creditorStage1InfoEN', 'creditorStage2InfoEN',
      'habermasStage1Info', 'habermasStage2Info',
      'howToEN', 'howToKR', 'howToDE'
    ];
    allCards.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });

    const refs = document.getElementById('referencesList');

    if (caseType === 'roeVsDobbs') {
      this._show('roeInfo');
      this._show('dobbsInfo');
      this._show('howToEN');
      if (refs) refs.innerHTML = `
        <li><a href="https://www.oyez.org/cases/1971/70-18" target="_blank" rel="noopener">Roe v. Wade — Oyez</a></li>
        <li><a href="https://www.oyez.org/cases/2021/19-1392" target="_blank" rel="noopener">Dobbs v. Jackson — Oyez</a></li>
      `;
      this.state.stage = 'preview';
      this.xGraph = { strength: 10, angle: -55, color: CONFIG.COLORS.PINK };
      this.yGraph = { strength: 4, angle: 22, color: CONFIG.COLORS.BLUE };
      this.winnerSide = 'x';
      this.showGroundTruth = true;
    }

    if (caseType === 'creditorSubrogation') {
      this._show('creditorStage1Info');
      this._show('creditorStage2Info');
      this._show('howToKR');
      if (refs) refs.innerHTML = `
        <li><a href="https://www.scourt.go.kr/" target="_blank" rel="noopener">대법원 판례 — 2017다228618</a></li>
        <li>채권자대위권(surrogation)의 피보전권리 존부 판단 기준</li>
      `;
      this.state.stage = 'preview';
      this.xGraph = { strength: 7, angle: 52, color: CONFIG.COLORS.BLUE };
      this.yGraph = { strength: 12, angle: -18, color: CONFIG.COLORS.PINK };
      this.winnerSide = 'y';
      this.showGroundTruth = true;
    }

    if (caseType === 'creditorSubrogationEN') {
      this._show('creditorStage1InfoEN');
      this._show('creditorStage2InfoEN');
      this._show('howToEN');
      if (refs) refs.innerHTML = `
        <li><a href="https://www.scourt.go.kr/" target="_blank" rel="noopener">Supreme Court — 2017Da228618</a></li>
        <li>Creditor's surrogation: determination of preserved right</li>
      `;
      this.state.stage = 'preview';
      this.xGraph = { strength: 7, angle: 52, color: CONFIG.COLORS.BLUE };
      this.yGraph = { strength: 12, angle: -18, color: CONFIG.COLORS.PINK };
      this.winnerSide = 'y';
      this.showGroundTruth = true;
    }

    if (caseType === 'habermasLuhmann') {
      this._show('habermasStage1Info');
      this._show('habermasStage2Info');
      this._show('howToDE');
      if (refs) refs.innerHTML = `
        <li><a href="https://www.lernhelfer.de/schuelerlexikon/politikwirtschaft/artikel/die-habermas-luhmann-kontroverse-theorie-der-gesellschaft" target="_blank" rel="noopener">Die Habermas-Luhmann-Kontroverse — Lernhelfer</a></li>
        <li>Theorie der Gesellschaft oder Sozialtechnologie?</li>
      `;
      this.state.stage = 'preview';
      this.xGraph = { strength: 3, angle: -18, color: CONFIG.COLORS.PINK };
      this.yGraph = { strength: 7, angle: 52, color: CONFIG.COLORS.BLUE };
      this.winnerSide = 'y';
      this.showGroundTruth = true;
    }

    this.state.currentTime = 0;
    this.updateHeader();
    this.updateButtons();
    this.updatePreviewBalloons();
    this.draw();
  }

  _show(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'block';
  }

  getCurrentCaseData() {
    return CASE_DATA[this.currentCaseType][this.state.stage === 'stage1' ? 'stage1' : 'stage2'];
  }

  getPreviewData() {
    return CASE_DATA[this.currentCaseType].preview;
  }

  updateHeader() {
    const titleEl = document.getElementById('caseTitle');
    const subEl = document.getElementById('caseSubtitle');
    const infoEl = document.getElementById('caseInfo');
    const dot1 = document.getElementById('stage1Dot');
    const dot2 = document.getElementById('stage2Dot');
    const text1 = document.getElementById('stageText1');
    const text2 = document.getElementById('stageText2');

    if (this.currentCaseType === 'creditorSubrogation') {
      if (text1) text1.textContent = 'Stage 1: 조정(기판력 : Res Judicata)성립';
      if (text2) text2.textContent = 'Stage 2: 대위소송';
      if (this.state.stage === 'stage1') {
        if (titleEl) titleEl.textContent = CASE_DATA.creditorSubrogation.stage1.title;
        if (subEl) subEl.textContent = CASE_DATA.creditorSubrogation.stage1.subtitle;
        if (infoEl) infoEl.textContent = CASE_DATA.creditorSubrogation.stage1.info;
        dot1?.classList.add('active');
        dot2?.classList.remove('active');
      } else {
        if (titleEl) titleEl.textContent = CASE_DATA.creditorSubrogation.stage2.title;
        if (subEl) subEl.textContent = CASE_DATA.creditorSubrogation.stage2.subtitle;
        if (infoEl) infoEl.textContent = CASE_DATA.creditorSubrogation.stage2.info;
        dot1?.classList.remove('active');
        dot2?.classList.add('active');
      }
    }

    if (this.currentCaseType === 'creditorSubrogationEN') {
      if (text1) text1.textContent = 'Stage 1: Mediation (Res Judicata)';
      if (text2) text2.textContent = 'Stage 2: Subrogation Suit';
      const cData = CASE_DATA.creditorSubrogationEN;
      if (this.state.stage === 'stage1') {
        if (titleEl) titleEl.textContent = cData.stage1.title;
        if (subEl) subEl.textContent = cData.stage1.subtitle;
        if (infoEl) infoEl.textContent = cData.stage1.info;
        dot1?.classList.add('active');
        dot2?.classList.remove('active');
      } else {
        if (titleEl) titleEl.textContent = cData.stage2.title;
        if (subEl) subEl.textContent = cData.stage2.subtitle;
        if (infoEl) infoEl.textContent = cData.stage2.info;
        dot1?.classList.remove('active');
        dot2?.classList.add('active');
      }
    }

    if (this.currentCaseType === 'roeVsDobbs') {
      if (text1) text1.textContent = 'Stage 1: Roe v. Wade';
      if (text2) text2.textContent = 'Stage 2: Dobbs v. Jackson';
      if (this.state.stage === 'stage1') {
        if (titleEl) titleEl.textContent = CASE_DATA.roeVsDobbs.stage1.title;
        if (subEl) subEl.textContent = CASE_DATA.roeVsDobbs.stage1.subtitle;
        if (infoEl) infoEl.textContent = CASE_DATA.roeVsDobbs.stage1.info;
        dot1?.classList.add('active');
        dot2?.classList.remove('active');
      } else {
        if (titleEl) titleEl.textContent = CASE_DATA.roeVsDobbs.stage2.title;
        if (subEl) subEl.textContent = CASE_DATA.roeVsDobbs.stage2.subtitle;
        if (infoEl) infoEl.textContent = CASE_DATA.roeVsDobbs.stage2.info;
        dot1?.classList.remove('active');
        dot2?.classList.add('active');
      }
    }

    if (this.currentCaseType === 'habermasLuhmann') {
      if (text1) text1.textContent = 'These: Habermas';
      if (text2) text2.textContent = 'Antithese: Luhmann';
      if (this.state.stage === 'stage1') {
        if (titleEl) titleEl.textContent = CASE_DATA.habermasLuhmann.stage1.title;
        if (subEl) subEl.textContent = CASE_DATA.habermasLuhmann.stage1.subtitle;
        if (infoEl) infoEl.textContent = CASE_DATA.habermasLuhmann.stage1.info;
        dot1?.classList.add('active');
        dot2?.classList.remove('active');
      } else {
        if (titleEl) titleEl.textContent = CASE_DATA.habermasLuhmann.stage2.title;
        if (subEl) subEl.textContent = CASE_DATA.habermasLuhmann.stage2.subtitle;
        if (infoEl) infoEl.textContent = CASE_DATA.habermasLuhmann.stage2.info;
        dot1?.classList.remove('active');
        dot2?.classList.add('active');
      }
    }
  }

  updateButtons() {
    const playBtn = document.getElementById('playBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    if (playBtn) playBtn.disabled = this.state.isPlaying;
    if (pauseBtn) pauseBtn.disabled = !this.state.isPlaying;
  }

  /* ---- Play / Pause / Reset ---- */
  play() {
    if (this.state.isPlaying) return;

    if (this.state.stage === 'preview' || this.state.stage === 'done') {
      this.state.stage = 'stage1';
      this.state.currentTime = 0;
      this.showGroundTruth = false;
      this.winnerSide = null;

      const start = PHASES[this.currentCaseType].stage1[0];
      this.xGraph.strength = start.xStr;
      this.xGraph.angle = start.xAng;
      this.yGraph.strength = start.yStr;
      this.yGraph.angle = start.yAng;
      this.xGraph.color = CONFIG.COLORS.BLUE;
      this.yGraph.color = CONFIG.COLORS.PINK;

      this.updateHeader();
    }

    this.state.isPlaying = true;
    this.state.lastTimestamp = performance.now();
    this.updateButtons();
    this.state.animFrameId = requestAnimationFrame((t) => this.animate(t));
  }

  pause() {
    this.state.isPlaying = false;
    this.updateButtons();

    if (this.state.animFrameId) {
      cancelAnimationFrame(this.state.animFrameId);
      this.state.animFrameId = null;
    }
  }

  reset() {
    this.pause();
    this.switchCase(this.currentCaseType);
  }

  /* ---- Animation Loop ---- */
  animate(timestamp) {
    if (!this.state.isPlaying) return;

    const dt = timestamp - this.state.lastTimestamp;
    this.state.lastTimestamp = timestamp;
    this.state.currentTime += dt;

    if (this.state.stage === 'stage1') {
      this.updateAnimatedGraphs(PHASES[this.currentCaseType].stage1, this.state.currentTime);

      if (this.state.currentTime >= CONFIG.STAGE1_DURATION) {
        this.state.stage = 'transition';
        this.state.currentTime = 0;
        this.winnerSide = 'x';
        this.showGroundTruth = true;
        this.updateHeader();
      } else {
        this.winnerSide = this.state.currentTime > CONFIG.STAGE1_DURATION * 0.85 ? 'x' : null;
        this.showGroundTruth = this.state.currentTime > CONFIG.STAGE1_DURATION * 0.9;
      }
    } else if (this.state.stage === 'transition') {
      this.updateTransition(this.state.currentTime);

      if (this.state.currentTime >= CONFIG.TRANSITION_DURATION) {
        this.state.stage = 'stage2';
        this.state.currentTime = 0;
        this.winnerSide = null;
        this.showGroundTruth = false;

        const s2 = PHASES[this.currentCaseType].stage2[0];
        this.xGraph.strength = s2.xStr;
        this.xGraph.angle = s2.xAng;
        this.yGraph.strength = s2.yStr;
        this.yGraph.angle = s2.yAng;

        if (this._isCreditorCase()) {
          this.xGraph.color = CONFIG.COLORS.BLUE;
          this.yGraph.color = CONFIG.COLORS.PINK;
        } else {
          this.xGraph.color = CONFIG.COLORS.PINK;
          this.yGraph.color = CONFIG.COLORS.BLUE;
        }

        this.updateHeader();
      }
    } else if (this.state.stage === 'stage2') {
      this.updateAnimatedGraphs(PHASES[this.currentCaseType].stage2, this.state.currentTime);

      const finalWinner = this.currentCaseType === 'roeVsDobbs' ? 'x' : 'y';

      if (this.state.currentTime >= CONFIG.STAGE2_DURATION) {
        this.state.stage = 'done';
        this.state.currentTime = CONFIG.STAGE2_DURATION;
        this.updateAnimatedGraphs(PHASES[this.currentCaseType].stage2, CONFIG.STAGE2_DURATION);
        this.winnerSide = finalWinner;
        this.showGroundTruth = true;
        this.pause();
      } else {
        this.winnerSide = this.state.currentTime > CONFIG.STAGE2_DURATION * 0.85 ? finalWinner : null;
        this.showGroundTruth = this.state.currentTime > CONFIG.STAGE2_DURATION * 0.9;
      }
    }

    this.updateDynamicBalloons();
    this.draw();

    if (this.state.isPlaying) {
      this.state.animFrameId = requestAnimationFrame((t) => this.animate(t));
    }
  }

  updateAnimatedGraphs(phases, time) {
    let current = phases[0];
    let next = phases[phases.length - 1];

    for (let i = 0; i < phases.length - 1; i++) {
      if (time >= phases[i].time && time < phases[i + 1].time) {
        current = phases[i];
        next = phases[i + 1];
        break;
      }
    }

    if (time >= phases[phases.length - 1].time) {
      current = phases[phases.length - 1];
      next = phases[phases.length - 1];
    }

    const span = next.time - current.time;
    const rawT = span > 0 ? (time - current.time) / span : 1;
    const t = Ease.inOutCubic(Ease.clamp01(rawT));

    this.xGraph.strength = Ease.lerp(current.xStr, next.xStr, t);
    this.xGraph.angle = Ease.lerp(current.xAng, next.xAng, t);
    this.yGraph.strength = Ease.lerp(current.yStr, next.yStr, t);
    this.yGraph.angle = Ease.lerp(current.yAng, next.yAng, t);

    if (this.state.stage === 'stage1') {
      this.xGraph.color = CONFIG.COLORS.BLUE;
      this.yGraph.color = CONFIG.COLORS.PINK;
    }

    if (this.state.stage === 'stage2') {
      if (this._isCreditorCase()) {
        this.xGraph.color = CONFIG.COLORS.BLUE;
        this.yGraph.color = CONFIG.COLORS.PINK;
      } else {
        this.xGraph.color = CONFIG.COLORS.PINK;
        this.yGraph.color = CONFIG.COLORS.BLUE;
      }
    }
  }

  updateTransition(time) {
    const t = Ease.inOutCubic(Ease.clamp01(time / CONFIG.TRANSITION_DURATION));
    const s1 = PHASES[this.currentCaseType].stage1.at(-1);
    const s2 = PHASES[this.currentCaseType].stage2[0];

    this.xGraph.strength = Ease.lerp(s1.xStr, s2.xStr, t);
    this.xGraph.angle = Ease.lerp(s1.xAng, s2.xAng, t);
    this.yGraph.strength = Ease.lerp(s1.yStr, s2.yStr, t);
    this.yGraph.angle = Ease.lerp(s1.yAng, s2.yAng, t);

    if (this._isCreditorCase()) {
      this.xGraph.color = CONFIG.COLORS.BLUE;
      this.yGraph.color = CONFIG.COLORS.PINK;
    } else {
      this.xGraph.color = this.lerpColor(CONFIG.COLORS.BLUE, CONFIG.COLORS.PINK, t);
      this.yGraph.color = this.lerpColor(CONFIG.COLORS.PINK, CONFIG.COLORS.BLUE, t);
    }
  }

  /* ---- Balloon Position Helpers ---- */

  /**
   * Place each balloon so its tail-tip "sticks to" its graph arrowhead
   * WITHOUT the box body covering the graph line.
   *
   * Balloon box is drawn ABOVE the anchor (tail-tip) point.
   * Box size: W ≈ 170–220, H ≈ 70.
   *
   * X graph (angle > 0 → lower-right):
   *   Anchor BELOW the arrowhead → box body sits between endpoint and anchor,
   *   which is below the line.  Shift slightly right so the tail aligns.
   *
   * Y graph (angle < 0 → upper-right):
   *   Anchor just BELOW the arrowhead → box body rises ABOVE the endpoint,
   *   sitting above the line.  Place near centre-top, slightly right.
   *
   * Preview badge → left-bottom.
   */
  _computeBalloonPositions() {
    const W = this.dim.w;
    const H = this.dim.h;
    const ox = this.dim.originX;
    const oy = this.dim.originY;

    const xRad = this.xGraph.angle * Math.PI / 180;
    const yRad = this.yGraph.angle * Math.PI / 180;

    const xEnd = this.xGraphEnd || {
      x: ox + Math.cos(xRad) * this.xGraph.strength * CONFIG.GRAPH.SCALE_FACTOR,
      y: oy + Math.sin(xRad) * this.xGraph.strength * CONFIG.GRAPH.SCALE_FACTOR,
    };
    const yEnd = this.yGraphEnd || {
      x: ox + Math.cos(yRad) * this.yGraph.strength * CONFIG.GRAPH.SCALE_FACTOR,
      y: oy + Math.sin(yRad) * this.yGraph.strength * CONFIG.GRAPH.SCALE_FACTOR,
    };

    const BOX_H = 70;   // approximate balloon box height

    // ── X balloon: stick to X arrowhead, anchor BELOW it ──
    // Tail-tip sits ~30 px below the arrowhead so the box body
    // hangs below the graph line, not across it.
    let xAnchorX = xEnd.x + 15;                        // slight right so tail points at tip
    let xAnchorY = xEnd.y + BOX_H + 12;                // anchor well below → box bottom = anchor, box top ≈ endpoint

    // ── Y balloon: stick to Y arrowhead, box body fully ABOVE the tip ──
    // Anchor = tail-tip, box is drawn upward from anchor.
    // Place anchor a small gap ABOVE the arrowhead so the tail points
    // down toward the tip, and the entire box body sits above it.
    let yAnchorX = yEnd.x + 15;                         // slight right
    let yAnchorY = yEnd.y - 18;                          // above tip → tail points down to arrowhead

    // Clamp into canvas
    const clampX = (v) => Math.max(120, Math.min(W - 120, v));
    const clampY = (v) => Math.max(BOX_H + 10, Math.min(H - 10, v));

    xAnchorX = clampX(xAnchorX);
    xAnchorY = clampY(xAnchorY);
    yAnchorX = clampX(yAnchorX);
    yAnchorY = clampY(yAnchorY);

    return { xAnchorX, xAnchorY, yAnchorX, yAnchorY };
  }

  /* ---- Balloons ---- */
  updatePreviewBalloons() {
    const data = this.getPreviewData();
    const pos = this._computeBalloonPositions();

    this.balloons = [
      {
        x: pos.xAnchorX,
        y: pos.xAnchorY,
        title: data.x.label,
        lines: data.x.arguments.slice(0, 2),
        detail: data.x,
        isWinner: this.winnerSide === 'x',
      },
      {
        x: pos.yAnchorX,
        y: pos.yAnchorY,
        title: data.y.label,
        lines: data.y.arguments.slice(0, 2),
        detail: data.y,
        isWinner: this.winnerSide === 'y',
      },
    ];
  }

  updateDynamicBalloons() {
    if (this.state.stage === 'preview' || this.state.stage === 'done') {
      this.updatePreviewBalloons();
      return;
    }

    if (this.state.stage === 'transition') {
      this.balloons = [];
      return;
    }

    const data = this.getCurrentCaseData();
    const duration = this.state.stage === 'stage1' ? CONFIG.STAGE1_DURATION : CONFIG.STAGE2_DURATION;
    const progress = Ease.clamp01(this.state.currentTime / duration);
    const isStage2 = this.state.stage === 'stage2';
    const winnerKey = isStage2 ? (this.currentCaseType === 'roeVsDobbs' ? 'x' : 'y') : 'x';

    this.balloons = [];
    const pos = this._computeBalloonPositions();

    if (progress > 0.12) {
      this.balloons.push({
        x: pos.xAnchorX,
        y: pos.xAnchorY,
        title: data.x.label,
        lines: data.x.arguments.slice(0, 2),
        detail: data.x,
        isWinner: winnerKey === 'x',
      });
    }

    if (progress > 0.22) {
      this.balloons.push({
        x: pos.yAnchorX,
        y: pos.yAnchorY,
        title: data.y.label,
        lines: data.y.arguments.slice(0, 2),
        detail: data.y,
        isWinner: winnerKey === 'y',
      });
    }
  }

  /* ===================================================
     Drawing Methods
     =================================================== */
  draw() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.dim.w, this.dim.h);

    this.drawGrid();
    this.drawAxes();
    this.drawGraphs();

    if (this._isCreditorCase() &&
      (this.state.stage === 'preview' || this.state.stage === 'stage2' || this.state.stage === 'done')) {
      this.drawGrayDebtor();
    }

    this.drawArc();

    if (this.showGroundTruth) {
      this.drawGroundTruth();
    }

    if (this._isCreditorCase() &&
      (this.state.stage === 'preview' || this.state.stage === 'done') &&
      this.winnerSide === 'y') {
      this.drawDismissalBadge();
    }

    this.drawBalloons();
    this.drawLegend();
    this.drawProgressBar();
    this.drawPhaseDescription();

    if (this.state.stage === 'preview') {
      this.drawPreviewBadge();
    }
  }

  drawGrid() {
    const ctx = this.ctx;
    ctx.strokeStyle = CONFIG.COLORS.GRID_LINE;
    ctx.lineWidth = 0.5;

    for (let x = 0; x < this.dim.w; x += 50) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, this.dim.h);
      ctx.stroke();
    }

    for (let y = 0; y < this.dim.h; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(this.dim.w, y);
      ctx.stroke();
    }
  }

  drawAxes() {
    const ctx = this.ctx;
    const ox = this.dim.originX;
    const oy = this.dim.originY;

    ctx.strokeStyle = CONFIG.COLORS.GRID_AXIS;
    ctx.lineWidth = 1.2;
    ctx.setLineDash([6, 4]);

    ctx.beginPath();
    ctx.moveTo(ox, 25);
    ctx.lineTo(ox, this.dim.h - 25);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(25, oy);
    ctx.lineTo(this.dim.w - 25, oy);
    ctx.stroke();

    ctx.setLineDash([]);

    ctx.fillStyle = '#777';
    ctx.font = 'italic 11px Inter, Arial';
    ctx.textAlign = 'right';
    ctx.fillText('ratio', ox - 6, oy - 10);

    ctx.fillStyle = CONFIG.COLORS.BATTLE_POINT;
    ctx.beginPath();
    ctx.arc(ox, oy, CONFIG.BATTLE_POINT.RADIUS, 0, Math.PI * 2);
    ctx.fill();

    const pulse = CONFIG.BATTLE_POINT.RADIUS + Math.sin(Date.now() / CONFIG.BATTLE_POINT.PULSE_SPEED) * CONFIG.BATTLE_POINT.PULSE_AMPLITUDE;
    ctx.strokeStyle = 'rgba(239,68,68,0.35)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(ox, oy, pulse, 0, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = '#777';
    ctx.font = 'italic 11px Inter, Arial';

    ctx.save();
    ctx.translate(ox - 20, this.dim.h * 0.28);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = 'center';
    ctx.fillText(
      this.currentCaseType === 'creditorSubrogation' ? '귀무가설 (H₀)' :
      this.currentCaseType === 'creditorSubrogationEN' ? 'Null Hypothesis (H₀)' :
      this.currentCaseType === 'habermasLuhmann' ? 'These (H₀)' :
      'Null Hypothesis (H₀)',
      0, 0
    );
    ctx.restore();

    ctx.textAlign = 'right';
    ctx.fillText(
      this.currentCaseType === 'creditorSubrogation' ? '대립가설 (H₁)' :
      this.currentCaseType === 'creditorSubrogationEN' ? 'Alternative Hypothesis (H₁)' :
      this.currentCaseType === 'habermasLuhmann' ? 'Antithese (H₁)' :
      'Alternative Hypothesis (H₁)',
      this.dim.w - 30, oy + 18
    );
  }

  drawGraphs() {
    const ctx = this.ctx;
    const ox = this.dim.originX;
    const oy = this.dim.originY;

    const xRad = this.xGraph.angle * Math.PI / 180;
    const yRad = this.yGraph.angle * Math.PI / 180;

    const xLen = this.xGraph.strength * CONFIG.GRAPH.SCALE_FACTOR;
    const yLen = this.yGraph.strength * CONFIG.GRAPH.SCALE_FACTOR;

    const xSx = ox - Math.cos(xRad) * xLen * 0.45;
    const xSy = oy - Math.sin(xRad) * xLen * 0.45;
    const xEx = ox + Math.cos(xRad) * xLen;
    const xEy = oy + Math.sin(xRad) * xLen;

    const ySx = ox - Math.cos(yRad) * yLen * 0.4;
    const ySy = oy - Math.sin(yRad) * yLen * 0.4;
    const yEx = ox + Math.cos(yRad) * yLen;
    const yEy = oy + Math.sin(yRad) * yLen;

    this.xGraphEnd = { x: xEx, y: xEy };
    this.yGraphEnd = { x: yEx, y: yEy };

    // X graph
    ctx.strokeStyle = this.xGraph.color;
    ctx.lineWidth = CONFIG.GRAPH.LINE_WIDTH;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(xSx, xSy);
    ctx.lineTo(xEx, xEy);
    ctx.stroke();
    this.drawArrowHead(xEx, xEy, xRad, this.xGraph.color);

    // Y graph (with gradient for creditor case)
    if (this._isCreditorCase() &&
      (this.state.stage === 'preview' || this.state.stage === 'stage2' || this.state.stage === 'done')) {
      const grad = ctx.createLinearGradient(ox, oy, yEx, yEy);
      grad.addColorStop(0, CONFIG.COLORS.GRAY);
      grad.addColorStop(0.35, CONFIG.COLORS.GRAY);
      grad.addColorStop(0.36, CONFIG.COLORS.PINK);
      grad.addColorStop(0.75, CONFIG.COLORS.PINK);
      grad.addColorStop(0.76, CONFIG.COLORS.GRAY);
      grad.addColorStop(1, CONFIG.COLORS.GRAY);
      ctx.strokeStyle = grad;
    } else {
      ctx.strokeStyle = this.yGraph.color;
    }

    ctx.lineWidth = CONFIG.GRAPH.LINE_WIDTH;
    ctx.beginPath();
    ctx.moveTo(ySx, ySy);
    ctx.lineTo(yEx, yEy);
    ctx.stroke();
    this.drawArrowHead(yEx, yEy, yRad, this.yGraph.color);

    // Extra grey arrowhead at the end of the first GRAY segment (t ≈ 0.35)
    // for the creditor subrogation gradient Y graph.
    if (this._isCreditorCase() &&
      (this.state.stage === 'preview' || this.state.stage === 'stage2' || this.state.stage === 'done')) {
      const t1 = 0.35;
      const gray1X = ox + (yEx - ox) * t1;
      const gray1Y = oy + (yEy - oy) * t1;
      this.drawArrowHead(gray1X, gray1Y, yRad, CONFIG.COLORS.GRAY);
    }

    // Labels
    ctx.font = 'bold 14px Inter, Arial';
    ctx.textAlign = 'left';
    ctx.fillStyle = this.xGraph.color;
    ctx.fillText('X (Π)', xEx + Math.cos(xRad) * 16, xEy + Math.sin(xRad) * 16);

    ctx.fillStyle = this.yGraph.color;
    ctx.fillText('Y (Δ)', yEx + Math.cos(yRad) * 16, yEy + Math.sin(yRad) * 16);
  }

  drawArrowHead(x, y, angle, color) {
    const ctx = this.ctx;
    const s = CONFIG.GRAPH.ARROW_SIZE;
    const a = CONFIG.GRAPH.ARROW_ANGLE;

    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x - s * Math.cos(angle - a), y - s * Math.sin(angle - a));
    ctx.lineTo(x - s * Math.cos(angle + a), y - s * Math.sin(angle + a));
    ctx.closePath();
    ctx.fill();
  }

  drawGrayDebtor() {
    const ctx = this.ctx;
    const ox = this.dim.originX;
    const oy = this.dim.originY;
    const zAngle = ((this.xGraph.angle + this.yGraph.angle) / 2) * Math.PI / 180;
    const zLen = 4 * CONFIG.GRAPH.SCALE_FACTOR;

    const zSx = ox - Math.cos(zAngle) * zLen * 0.3;
    const zSy = oy - Math.sin(zAngle) * zLen * 0.3;
    const zEx = ox + Math.cos(zAngle) * zLen;
    const zEy = oy + Math.sin(zAngle) * zLen;

    ctx.save();
    ctx.strokeStyle = CONFIG.COLORS.GRAY;
    ctx.lineWidth = 2;
    ctx.setLineDash([8, 5]);
    ctx.beginPath();
    ctx.moveTo(zSx, zSy);
    ctx.lineTo(zEx, zEy);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = CONFIG.COLORS.GRAY;
    ctx.font = 'bold 12px Inter, Arial';
    const isEN = this.currentCaseType === 'creditorSubrogationEN';
    ctx.fillText(isEN ? 'Z (② Debtor)' : 'Z (② 채무자/甲)', zEx + 10, zEy + 8);
    ctx.font = '10px Inter, Arial';
    ctx.fillText(isEN ? 'Passive (Subrogated)' : '패시브(피대위자)', zEx + 10, zEy + 22);
    ctx.restore();
  }

  drawArc() {
    if (!this.winnerSide) return;

    const ctx = this.ctx;
    const ox = this.dim.originX;
    const oy = this.dim.originY;

    const xRad = this.xGraph.angle * Math.PI / 180;
    const yRad = this.yGraph.angle * Math.PI / 180;

    const startAng = this.winnerSide === 'x' ? yRad : xRad;
    const endAng = this.winnerSide === 'x' ? xRad : yRad;

    let diff = endAng - startAng;
    while (diff > Math.PI) diff -= 2 * Math.PI;
    while (diff < -Math.PI) diff += 2 * Math.PI;

    const ccw = diff < 0;

    ctx.strokeStyle = CONFIG.COLORS.BLACK;
    ctx.lineWidth = CONFIG.ARC.LINE_WIDTH;
    ctx.beginPath();
    ctx.arc(ox, oy, CONFIG.ARC.RADIUS, startAng, endAng, ccw);
    ctx.stroke();

    const arrowX = ox + Math.cos(endAng) * CONFIG.ARC.RADIUS;
    const arrowY = oy + Math.sin(endAng) * CONFIG.ARC.RADIUS;
    const tangent = endAng + (ccw ? -Math.PI / 2 : Math.PI / 2);
    const as = CONFIG.ARC.ARROW_SIZE;
    const aa = Math.PI / 5;

    ctx.fillStyle = CONFIG.COLORS.BLACK;
    ctx.beginPath();
    ctx.moveTo(arrowX, arrowY);
    ctx.lineTo(arrowX - as * Math.cos(tangent - aa), arrowY - as * Math.sin(tangent - aa));
    ctx.lineTo(arrowX - as * Math.cos(tangent + aa), arrowY - as * Math.sin(tangent + aa));
    ctx.closePath();
    ctx.fill();

    if (this.currentCaseType !== 'habermasLuhmann') {
      const midAng = startAng + diff / 2;
      ctx.font = 'bold 12px Inter, Arial';
      ctx.textAlign = 'center';
      ctx.fillText(
        'WIN',
        ox + Math.cos(midAng) * (CONFIG.ARC.RADIUS + 22),
        oy + Math.sin(midAng) * (CONFIG.ARC.RADIUS + 22)
      );
    }
  }

  drawGroundTruth() {
    const ctx = this.ctx;
    const end = this.winnerSide === 'x' ? this.xGraphEnd : this.yGraphEnd;
    if (!end) return;

    const text =
      this.currentCaseType === 'creditorSubrogation' ? '✓ 법적 근거' :
      this.currentCaseType === 'creditorSubrogationEN' ? '✓ Ground Truth' :
      this.currentCaseType === 'habermasLuhmann' ? '✓ Theoretische Basis' :
      '✓ Ground Truth';

    const bw = 120;
    const bh = 24;
    const bx = end.x - bw / 2;
    const by = end.y - 48;

    ctx.fillStyle = CONFIG.COLORS.GREEN;
    this.roundRect(ctx, bx, by, bw, bh, 12);
    ctx.fill();

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 11px Inter, Arial';
    ctx.textAlign = 'center';
    ctx.fillText(text, end.x, by + 16);

    ctx.strokeStyle = CONFIG.COLORS.GREEN;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(end.x, by + bh);
    ctx.lineTo(end.x, end.y - 10);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  drawDismissalBadge() {
    const ctx = this.ctx;
    const bw = 180;
    const bh = 52;
    const bx = this.dim.w - bw - 20;
    const by = 20;

    ctx.fillStyle = 'rgba(220,38,38,0.92)';
    this.roundRect(ctx, bx, by, bw, bh, 10);
    ctx.fill();

    ctx.strokeStyle = 'rgba(185,28,28,1)';
    ctx.lineWidth = 2;
    this.roundRect(ctx, bx, by, bw, bh, 10);
    ctx.stroke();

    ctx.fillStyle = '#fff';
    ctx.font = 'bold 14px Inter, Arial';
    ctx.textAlign = 'center';
    const isEN2 = this.currentCaseType === 'creditorSubrogationEN';
    ctx.fillText(isEN2 ? 'Dismissed' : '소 각하', bx + bw / 2, by + 20);
    ctx.font = '11px Inter, Arial';
    ctx.fillText(isEN2 ? 'Reversal — No preserved right' : '파기자판 — 피보전권리 부존재', bx + bw / 2, by + 38);
  }

  drawBalloons() {
    const ctx = this.ctx;

    this.balloons.forEach(b => {
      const w = b.isWinner ? 220 : 170;
      const titleH = 20;
      const lineH = 15;
      const pad = 10;
      const h = titleH + b.lines.length * lineH + pad * 2;

      const bx = b.x - w / 2;
      const by = b.y - h;
      const tail = 8;

      // Shadow
      ctx.fillStyle = 'rgba(0,0,0,0.08)';
      this.roundRect(ctx, bx + 2, by + 2, w, h, 3);
      ctx.fill();

      // Background
      ctx.fillStyle = CONFIG.COLORS.TOOLTIP_BG;
      ctx.strokeStyle = CONFIG.COLORS.TOOLTIP_BORDER;
      ctx.lineWidth = 1;
      this.roundRect(ctx, bx, by, w, h, 3);
      ctx.fill();
      ctx.stroke();

      // Tail triangle
      ctx.beginPath();
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x - tail, by + h);
      ctx.lineTo(b.x + tail, by + h);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Title bar
      ctx.fillStyle = b.isWinner ? '#2563EB' : '#DB2777';
      ctx.fillRect(bx + 3, by + 4, 3, titleH - 2);

      ctx.fillStyle = '#222';
      ctx.font = `bold ${b.isWinner ? 12 : 11}px Inter, Arial`;
      ctx.textAlign = 'left';
      ctx.fillText(b.title, bx + 11, by + 16);

      // Separator
      ctx.strokeStyle = '#FDD835';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(bx + 5, by + titleH + 2);
      ctx.lineTo(bx + w - 5, by + titleH + 2);
      ctx.stroke();

      // Lines
      ctx.fillStyle = '#555';
      ctx.font = `${b.isWinner ? 11 : 10}px Inter, Arial`;

      b.lines.forEach((line, i) => {
        let txt = line;
        while (ctx.measureText(txt).width > w - 20 && txt.length > 6) {
          txt = txt.slice(0, -4) + '…';
        }
        ctx.fillText(txt, bx + 9, by + titleH + pad + i * lineH + 6);
      });

      b.bounds = { x: bx, y: by, w, h: h + tail };
    });
  }

  drawLegend() {
    const ctx = this.ctx;
    const x = 14;
    const y = 14;
    const w = 300;
    const h = 108;

    const data = this.state.stage === 'preview' || this.state.stage === 'done'
      ? this.getPreviewData()
      : this.getCurrentCaseData();

    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    this.roundRect(ctx, x, y, w, h, 8);
    ctx.fill();

    ctx.strokeStyle = '#ddd';
    ctx.lineWidth = 1;
    this.roundRect(ctx, x, y, w, h, 8);
    ctx.stroke();

    ctx.fillStyle = '#222';
    ctx.font = 'bold 13px Inter, Arial';
    ctx.textAlign = 'left';

    const stageLabel =
      this.state.stage === 'stage1' ? 'Stage 1' :
      this.state.stage === 'stage2' ? 'Stage 2' :
      this.state.stage === 'transition' ? 'Transition' :
      'Preview';

    ctx.fillText(stageLabel, x + 10, y + 20);
    ctx.font = '10px Inter, Arial';
    ctx.fillStyle = '#888';
    ctx.fillText(data.title, x + 10, y + 34);

    ctx.strokeStyle = this.xGraph.color;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x + 10, y + 52);
    ctx.lineTo(x + 32, y + 52);
    ctx.stroke();

    ctx.fillStyle = '#333';
    ctx.font = '11px Inter, Arial';
    ctx.fillText(`${data.x.label}${this.winnerSide === 'x' ? ' ✓WIN' : ''}`, x + 38, y + 56);

    ctx.strokeStyle = this.yGraph.color;
    ctx.beginPath();
    ctx.moveTo(x + 10, y + 72);
    ctx.lineTo(x + 32, y + 72);
    ctx.stroke();

    ctx.fillText(`${data.y.label}${this.winnerSide === 'y' ? ' ✓WIN' : ''}`, x + 38, y + 76);

    ctx.fillStyle = '#aaa';
    ctx.font = 'italic 9px Inter, Arial';
    ctx.fillText('LawG v1.35', x + 10, y + 98);
  }

  drawProgressBar() {
    const ctx = this.ctx;
    const barW = 260;
    const barH = 6;
    const barX = this.dim.w - barW - 18;
    const barY = this.dim.h - 28;

    const total = CONFIG.STAGE1_DURATION + CONFIG.TRANSITION_DURATION + CONFIG.STAGE2_DURATION;
    let elapsed = 0;

    if (this.state.stage === 'preview') elapsed = total;
    if (this.state.stage === 'stage1') elapsed = this.state.currentTime;
    if (this.state.stage === 'transition') elapsed = CONFIG.STAGE1_DURATION + this.state.currentTime;
    if (this.state.stage === 'stage2') elapsed = CONFIG.STAGE1_DURATION + CONFIG.TRANSITION_DURATION + this.state.currentTime;
    if (this.state.stage === 'done') elapsed = total;

    const p = Math.min(1, elapsed / total);

    ctx.fillStyle = 'rgba(200,200,200,0.5)';
    this.roundRect(ctx, barX, barY, barW, barH, 3);
    ctx.fill();

    if (p > 0) {
      const grad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
      grad.addColorStop(0, CONFIG.COLORS.BLUE);
      grad.addColorStop(0.5, '#8B5CF6');
      grad.addColorStop(1, CONFIG.COLORS.PINK);
      ctx.fillStyle = grad;
      this.roundRect(ctx, barX, barY, barW * p, barH, 3);
      ctx.fill();
    }

    ctx.strokeStyle = '#ccc';
    ctx.lineWidth = 0.5;
    this.roundRect(ctx, barX, barY, barW, barH, 3);
    ctx.stroke();

    ctx.fillStyle = '#777';
    ctx.font = '10px Inter, Arial';
    ctx.textAlign = 'right';
    ctx.fillText(`${Math.floor(elapsed / 1000)}s / ${Math.floor(total / 1000)}s`, barX + barW, barY - 4);
  }

  drawPhaseDescription() {
    if (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 'transition') return;

    const phases = PHASES[this.currentCaseType][this.state.stage];
    let current = phases[0];

    for (let i = phases.length - 1; i >= 0; i--) {
      if (this.state.currentTime >= phases[i].time) {
        current = phases[i];
        break;
      }
    }

    const ctx = this.ctx;
    const bw = 440;
    const bh = 46;
    const bx = (this.dim.w - bw) / 2;
    const by = this.dim.h - 80;

    ctx.fillStyle = 'rgba(15,23,42,0.85)';
    this.roundRect(ctx, bx, by, bw, bh, 10);
    ctx.fill();

    ctx.fillStyle = '#fff';
    ctx.font = '600 12px Inter, Arial';
    ctx.textAlign = 'center';
    ctx.fillText(current.desc, this.dim.w / 2, by + 20);

    ctx.font = '10px Inter, Arial';
    ctx.fillStyle = 'rgba(255,255,255,0.65)';
    ctx.fillText(
      `${phases.indexOf(current) + 1} / ${phases.length}`,
      this.dim.w / 2,
      by + 36
    );
  }

  drawPreviewBadge() {
    const ctx = this.ctx;
    const text =
      this.currentCaseType === 'creditorSubrogation'
        ? '▶ Play 버튼을 눌러 애니메이션 시작'
        : this.currentCaseType === 'habermasLuhmann'
        ? '▶ Play drücken: These → Antithese'
        : '▶ Press Play to animate';  // covers creditorSubrogationEN + roeVsDobbs

    const bw = 280;
    const bh = 32;
    const bx = 14;                                // left-aligned
    const by = this.dim.h - 48;                   // bottom

    ctx.fillStyle = 'rgba(37,99,235,0.92)';
    this.roundRect(ctx, bx, by, bw, bh, 16);
    ctx.fill();

    ctx.fillStyle = '#fff';
    ctx.font = '600 12px Inter, Arial';
    ctx.textAlign = 'center';
    ctx.fillText(text, bx + bw / 2, by + 21);
  }

  /* ---- Mouse Events ---- */
  onMouseMove(e) {
    const rect = this.canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    let hovered = null;
    for (const b of this.balloons) {
      if (b.bounds && mx >= b.bounds.x && mx <= b.bounds.x + b.bounds.w && my >= b.bounds.y && my <= b.bounds.y + b.bounds.h) {
        hovered = b;
        break;
      }
    }

    if (!this.tooltip) return;

    if (!hovered) {
      this.tooltip.style.display = 'none';
      this.canvas.style.cursor = 'default';
      return;
    }

    this.tooltip.innerHTML = `
      <strong>${escapeHtml(hovered.title)}</strong>
      <div class="tooltip-line"></div>
      ${hovered.lines.map(line => `<div>• ${escapeHtml(line)}</div>`).join('')}
      <div class="tooltip-line"></div>
      <div style="font-size:10px;color:#999;">Ground: ${escapeHtml(hovered.detail.ground)}</div>
      <div style="font-size:10px;color:#bbb;margin-top:3px;">클릭하여 상세 보기</div>
    `;
    this.tooltip.style.display = 'block';
    this.tooltip.style.left = `${Math.min(mx + 12, this.dim.w - 280)}px`;
    this.tooltip.style.top = `${my + 12}px`;
    this.canvas.style.cursor = 'pointer';
  }

  onClick(e) {
    const rect = this.canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    for (const b of this.balloons) {
      if (b.bounds && mx >= b.bounds.x && mx <= b.bounds.x + b.bounds.w && my >= b.bounds.y && my <= b.bounds.y + b.bounds.h) {
        this.showModal(b);
        return;
      }
    }
  }

  showModal(balloon) {
    const modal = document.getElementById('detailModal');
    const titleEl = document.getElementById('modalTitle');
    const contentEl = document.getElementById('modalContent');

    if (titleEl) titleEl.textContent = balloon.title;
    if (contentEl) contentEl.innerHTML = `
      <p><strong>${escapeHtml(balloon.detail.label)}</strong></p>
      <p style="font-size:0.9em;color:#666;">Ground: ${escapeHtml(balloon.detail.ground)}</p>
      <ul>${balloon.detail.arguments.map(arg => `<li>${escapeHtml(arg)}</li>`).join('')}</ul>
    `;
    if (modal) modal.style.display = 'flex';
  }

  closeModal() {
    const modal = document.getElementById('detailModal');
    if (modal) modal.style.display = 'none';
  }

  /* ---- Utilities ---- */
  roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  lerpColor(c1, c2, t) {
    const parse = (c) => ({
      r: parseInt(c.slice(1, 3), 16),
      g: parseInt(c.slice(3, 5), 16),
      b: parseInt(c.slice(5, 7), 16),
    });

    const a = parse(c1);
    const b = parse(c2);

    const r = Math.round(Ease.lerp(a.r, b.r, t));
    const g = Math.round(Ease.lerp(a.g, b.g, t));
    const b2 = Math.round(Ease.lerp(a.b, b.b, t));

    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b2.toString(16).padStart(2, '0')}`;
  }
}

/* ===================================================
   Initialization
   =================================================== */
function initApp() {
  try {
    window.lawgraph = new LawGraphVisualization();
  } catch (err) {
    // 실패 시 콘솔에 내부 상태를 노출하지 않도록 조용히 처리
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initApp);
} else {
  initApp();
}

export default LawGraphVisualization;
