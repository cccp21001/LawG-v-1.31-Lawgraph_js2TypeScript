# 🚀 Build Instructions

Follow these steps to compile and run the TypeScript version.

## Option 1: Quick Start (Recommended)

```bash
# 1. Install dependencies
npm install

# 2. Build the project
npm run build

# 3. Open index.html in your browser
# The compiled JavaScript will be in dist/lawgraph.js
```

## Option 2: Development Mode

```bash
# Watch for changes and auto-recompile
npm run watch

# Then open index.html in your browser
```

## What Gets Built

After running `npm run build`, you'll have:

```
dist/
├── types.js          (Compiled from src/types.ts)
├── types.d.ts        (Type declarations)
├── types.js.map      (Source map)
├── lawgraph.js       (Compiled from src/lawgraph.ts)
├── lawgraph.d.ts     (Type declarations)
└── lawgraph.js.map   (Source map)
```

## Troubleshooting

### TypeScript not found
```bash
npm install -g typescript
# or use npx
npx tsc
```

### Build errors
```bash
# Clean and rebuild
npm run clean
npm run build
```

### Module not found in browser
Make sure `index.html` points to:
```html
<script type="module" src="dist/lawgraph.js"></script>
```
