/**
 * LawG v2.0 TypeScript - Lawgraph Visualization Engine
 * Roe v. Wade (1973) → Dobbs v. Jackson Women's Health Organization (2022)
 * 
 * v2.0 Changes:
 * - Complete TypeScript rewrite with full type safety
 * - Removed recording functionality for simplified codebase
 * - Enhanced type definitions for better IDE support
 * 
 * Features:
 * - Crossing X/Y graphs with dynamic angles and lengths
 * - Two-stage continuous animation (1 click plays both)
 * - Color swap between stages (Blue/Pink → Pink/Blue)
 * - Position swap in Stage 2 (X goes up, Y goes down)
 * - Thick black arc with arrow pointing upward to winner
 * - Excel-style yellow balloon tooltips
 * - Null Hypothesis / Alternative Hypothesis axis labels
 * - Ground Truth marking on winning graph
 */

import type {
    Config,
    CaseData,
    CaseDatabase,
    AnimationPhase,
    AnimationState,
    Graph,
    Dimensions,
    Balloon,
    Point,
    StageType
} from './types';

// ============================================================
// CONSTANTS
// ============================================================
const CONFIG: Config = {
    STAGE1_DURATION: 28000,
    STAGE2_DURATION: 28000,
    TRANSITION_DURATION: 3000,

    COLORS: {
        BLUE: '#2563EB',
        BLUE_DARK: '#1D4ED8',
        PINK: '#DB2777',
        PINK_DARK: '#BE185D',
        GREEN: '#16A34A',
        GREEN_DARK: '#15803D',
        ARC_BLACK: '#111111',
        BATTLE_POINT: '#EF4444',
        GRID_LINE: '#e8e8e8',
        GRID_AXIS: '#9CA3AF',
        GROUND_TRUTH: '#16A34A',
        TOOLTIP_BG: '#FFFDE7',
        TOOLTIP_BORDER: '#FBC02D',
    },

    GRAPH: {
        LINE_WIDTH: 2.5,
        ARROW_SIZE: 14,
        ARROW_ANGLE: Math.PI / 6,
        SCALE_FACTOR: 22,
    },

    ARC: {
        LINE_WIDTH: 4.5,
        ARROW_SIZE: 14,
    },

    BALLOON: {
        MAJOR_WIDTH: 220,
        MAJOR_HEIGHT: 90,
        MINOR_WIDTH: 170,
        MINOR_HEIGHT: 70,
        RADIUS: 3,
        TAIL_SIZE: 8,
    },

    GRID: { SPACING: 50 },

    BATTLE_POINT: {
        RADIUS: 6,
        PULSE_AMPLITUDE: 3,
        PULSE_SPEED: 250,
    },
};

// ============================================================
// EASING HELPERS
// ============================================================
const Ease = {
    inOutCubic(t: number): number {
        return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    },
    lerp(a: number, b: number, t: number): number {
        return a + (b - a) * t;
    },
    clamp01(t: number): number {
        return Math.max(0, Math.min(1, t));
    }
};

function escapeHtml(str: string): string {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

// ============================================================
// CASE DATA
// ============================================================
const CASE_DATA: CaseDatabase = {
    roeVWade: {
        title: 'Roe v. Wade (1973)',
        subtitle: 'Legal Battle Timeline Visualization',
        info: 'Supreme Court Decision: 7-2 Majority Opinion',
        url: 'https://www.oyez.org/cases/1971/70-18',
        majority: {
            justices: 7,
            label: 'Majority (7)',
            arguments: [
                '14th Amdt Due Process → privacy rights',
                "Woman's right to choose is constitutional",
                'Trimester framework balances rights & state interest',
                '1st tri: No regulation; 2nd: Health; 3rd: May prohibit',
            ],
            ground: '14th Amdt. Due Process / Privacy',
        },
        dissent: {
            justices: 2,
            label: 'Dissent (2)',
            arguments: [
                'No constitutional basis for abortion rights',
                '"Raw Judicial Power" — exceeded authority',
                'State legislatures should decide democratically',
            ],
            ground: 'Legislative authority / States rights',
        },
    },
    dobbsVJackson: {
        title: 'Dobbs v. Jackson (2022)',
        subtitle: 'Overruling Roe v. Wade',
        info: 'Supreme Court Decision: 6-3 — Roe Overruled',
        url: 'https://www.oyez.org/cases/2021/19-1392',
        majority: {
            justices: 6,
            label: 'Majority (6)',
            arguments: [
                'Constitution does not confer right to abortion',
                'Roe was "egregiously wrong from the start"',
                'Authority returned to people & elected representatives',
                'No basis in text, history, or structure of Constitution',
            ],
            ground: 'Constitutional textualism / Stare decisis reexamined',
        },
        dissent: {
            justices: 3,
            label: 'Dissent (3)',
            arguments: [
                'Overruling Roe undermines Court legitimacy',
                'Women lose fundamental constitutional protection',
                'Stare decisis abandoned without justification',
            ],
            ground: 'Precedent / Substantive due process',
        },
    },
};

// ============================================================
// ANIMATION PHASES
// ============================================================
const STAGE1_PHASES: AnimationPhase[] = [
    { time: 0,     xStr: 3, yStr: 3, xAng: 25,  yAng: -20,  desc: 'Case Filed: Texas abortion law challenged' },
    { time: 5000,  xStr: 5, yStr: 4, xAng: 32,  yAng: -28,  desc: 'Initial Arguments: Privacy vs. State Authority' },
    { time: 10000, xStr: 7, yStr: 5, xAng: 40,  yAng: -35,  desc: '14th Amendment Debate: Due Process scope' },
    { time: 16000, xStr: 8, yStr: 5, xAng: 48,  yAng: -32,  desc: 'Trimester Framework Proposed' },
    { time: 21000, xStr: 6, yStr: 6, xAng: 42,  yAng: -38,  desc: 'Dissent Objects: Judicial overreach claimed' },
    { time: 26000, xStr: 10,yStr: 4, xAng: 55,  yAng: -25,  desc: 'DECISION: Majority prevails 7-2 — X(Blue) WINS' },
];

const STAGE2_PHASES: AnimationPhase[] = [
    { time: 0,     xStr: 3, yStr: 3, xAng: -22, yAng: 22,   desc: 'New Case: Mississippi 15-week ban challenged' },
    { time: 5000,  xStr: 5, yStr: 5, xAng: -30, yAng: 30,   desc: 'Stare Decisis Debate: Should Roe be overturned?' },
    { time: 10000, xStr: 7, yStr: 6, xAng: -42, yAng: 35,   desc: 'Constitutional Textualism: No explicit right found' },
    { time: 16000, xStr: 8, yStr: 5, xAng: -48, yAng: 30,   desc: '"Roe was egregiously wrong from the start"' },
    { time: 21000, xStr: 6, yStr: 6, xAng: -38, yAng: 38,   desc: 'Fierce Dissent: Legitimacy of Court questioned' },
    { time: 26000, xStr: 10,yStr: 4, xAng: -55, yAng: 22,   desc: 'DECISION: Roe OVERRULED 6-3 — X(Pink) WINS' },
];

// ============================================================
// MAIN VISUALIZATION CLASS
// ============================================================
class LawGraphVisualization {
    private canvas: HTMLCanvasElement;
    private ctx: CanvasRenderingContext2D;
    private tooltip: HTMLElement | null;
    private dim: Dimensions;
    private xGraph: Graph;
    private yGraph: Graph;
    private state: AnimationState;
    private balloons: Balloon[];
    private currentCase: CaseData;
    private currentPhases: AnimationPhase[];
    private winnerSide: 'x' | 'y' | null;
    private showGroundTruth: boolean;
    private hoveredBalloon: Balloon | null;
    private xGraphEnd: Point | null;
    private yGraphEnd: Point | null;

    constructor() {
        const canvas = document.getElementById('battleCanvas') as HTMLCanvasElement | null;
        if (!canvas) throw new Error('Canvas element not found');
        this.canvas = canvas;
        
        const ctx = this.canvas.getContext('2d');
        if (!ctx) throw new Error('Could not get 2D context');
        this.ctx = ctx;

        this.tooltip = document.getElementById('tooltip');
        
        this.dim = { w: 0, h: 0, cx: 0, cy: 0, originX: 0, originY: 0 };
        
        this.state = {
            stage: 'preview',
            isPlaying: false,
            currentTime: 0,
            lastTimestamp: 0,
            animFrameId: null,
        };

        // Default for preview: Stage 2 final state (Dobbs) — X=Pink(up) wins, Y=Blue(down)
        this.xGraph = { strength: 10, angle: -55, color: CONFIG.COLORS.PINK, label: 'X' };
        this.yGraph = { strength: 4, angle: 22, color: CONFIG.COLORS.BLUE, label: 'Y' };

        this.currentCase = CASE_DATA.dobbsVJackson;
        this.currentPhases = STAGE2_PHASES;
        this.winnerSide = 'x';
        this.showGroundTruth = true;
        this.balloons = [];
        this.xGraphEnd = null;
        this.yGraphEnd = null;
        this.hoveredBalloon = null;

        this.init();
    }

    private init(): void {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        this.setupControls();
        this.canvas.addEventListener('mousemove', (e) => this.onMouseMove(e));
        this.canvas.addEventListener('click', (e) => this.onClick(e));

        this.setStageUI('preview');
        this.updateBalloonsForPreview();
        this.draw();
        console.log('✅ LawG v2.0 TypeScript Visualization initialized (Preview: Dobbs v. Jackson final)');
    }

    private resizeCanvas(): void {
        const rect = this.canvas.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        this.canvas.width = rect.width * dpr;
        this.canvas.height = rect.height * dpr;
        this.ctx.scale(dpr, dpr);
        this.dim.w = rect.width;
        this.dim.h = rect.height;
        this.dim.originX = rect.width * 0.38;
        this.dim.originY = rect.height * 0.50;
        this.dim.cx = rect.width / 2;
        this.dim.cy = rect.height / 2;

        if (!this.state.isPlaying) {
            if (this.state.stage === 'preview') this.updateBalloonsForPreview();
            this.draw();
        }
    }

    private setupControls(): void {
        const playBtn = document.getElementById('playBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const resetBtn = document.getElementById('resetBtn');
        const closeBtn = document.getElementById('closeModalBtn');

        if (playBtn) playBtn.addEventListener('click', () => this.play());
        if (pauseBtn) pauseBtn.addEventListener('click', () => this.pause());
        if (resetBtn) resetBtn.addEventListener('click', () => this.reset());
        if (closeBtn) closeBtn.addEventListener('click', () => this.closeModal());

        const modal = document.getElementById('detailModal');
        if (modal) modal.addEventListener('click', (e) => { 
            if (e.target === modal) this.closeModal(); 
        });
    }

    // ======================== PREVIEW STATE ========================
    private updateBalloonsForPreview(): void {
        this.balloons = [];
        const cd = CASE_DATA.dobbsVJackson;
        const ox = this.dim.originX;
        const oy = this.dim.originY;

        this.balloons.push({
            x: ox - 80, y: oy - 140,
            type: 'majority', title: cd.majority.label,
            lines: cd.majority.arguments.slice(0, 2), isMajority: true,
        });
        this.balloons.push({
            x: ox - 160, y: oy - 40,
            type: 'majority', title: 'Key Argument',
            lines: cd.majority.arguments.slice(2, 4), isMajority: true,
        });

        this.balloons.push({
            x: ox + 200, y: oy + 120,
            type: 'dissent', title: cd.dissent.label,
            lines: cd.dissent.arguments.slice(0, 2), isMajority: false,
        });
        this.balloons.push({
            x: ox + 120, y: oy + 200,
            type: 'dissent', title: 'Rebuttal',
            lines: cd.dissent.arguments.slice(2, 3), isMajority: false,
        });
    }

    // ======================== PLAYBACK ========================
    private play(): void {
        if (this.state.isPlaying) return;

        if (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 0) {
            this.state.stage = 1;
            this.state.currentTime = 0;
            this.winnerSide = null;
            this.showGroundTruth = false;
            this.balloons = [];
            this.xGraphEnd = null;
            this.yGraphEnd = null;

            this.currentCase = CASE_DATA.roeVWade;
            this.currentPhases = STAGE1_PHASES;
            this.xGraph = { strength: 3, angle: 25, color: CONFIG.COLORS.BLUE, label: 'X' };
            this.yGraph = { strength: 3, angle: -20, color: CONFIG.COLORS.PINK, label: 'Y' };
            this.setStageUI(1);
        }

        this.state.isPlaying = true;
        this.state.lastTimestamp = performance.now();
        this.updateButtons(true);
        this.animate();
    }

    private pause(): void {
        this.state.isPlaying = false;
        this.updateButtons(false);
        if (this.state.animFrameId) {
            cancelAnimationFrame(this.state.animFrameId);
            this.state.animFrameId = null;
        }
    }

    private reset(): void {
        this.pause();
        this.state.stage = 'preview';
        this.state.currentTime = 0;
        this.winnerSide = 'x';
        this.showGroundTruth = true;
        this.xGraphEnd = null;
        this.yGraphEnd = null;

        this.xGraph = { strength: 10, angle: -55, color: CONFIG.COLORS.PINK, label: 'X' };
        this.yGraph = { strength: 4, angle: 22, color: CONFIG.COLORS.BLUE, label: 'Y' };
        this.currentCase = CASE_DATA.dobbsVJackson;
        this.currentPhases = STAGE2_PHASES;

        this.setStageUI('preview');
        this.updateBalloonsForPreview();
        this.updateButtons(false);
        const playBtn = document.getElementById('playBtn') as HTMLButtonElement | null;
        if (playBtn) playBtn.disabled = false;
        this.draw();
    }

    private updateButtons(isPlaying: boolean): void {
        const playBtn = document.getElementById('playBtn') as HTMLButtonElement | null;
        const pauseBtn = document.getElementById('pauseBtn') as HTMLButtonElement | null;
        if (playBtn) playBtn.disabled = isPlaying;
        if (pauseBtn) pauseBtn.disabled = !isPlaying;
    }

    private animate(timestamp: number = 0): void {
        if (!this.state.isPlaying) return;

        const elapsed = timestamp - this.state.lastTimestamp;
        this.state.lastTimestamp = timestamp;
        this.state.currentTime += elapsed;

        if (this.state.stage === 1) {
            this.currentCase = CASE_DATA.roeVWade;
            this.currentPhases = STAGE1_PHASES;
            this.xGraph.color = CONFIG.COLORS.BLUE;
            this.yGraph.color = CONFIG.COLORS.PINK;

            if (this.state.currentTime >= CONFIG.STAGE1_DURATION) {
                this.state.stage = 2;
                this.state.currentTime = 0;
                this.winnerSide = null;
                this.showGroundTruth = false;
                this.setStageUI(2);
            } else {
                this.interpolatePhases(STAGE1_PHASES, this.state.currentTime);
                const prog = this.state.currentTime / CONFIG.STAGE1_DURATION;
                this.winnerSide = prog > 0.85 ? 'x' : null;
                this.showGroundTruth = prog > 0.9;
            }
        } else if (this.state.stage === 2) {
            if (this.state.currentTime >= CONFIG.TRANSITION_DURATION) {
                this.state.stage = 3;
                this.state.currentTime = 0;
                this.winnerSide = null;
                this.showGroundTruth = false;
                this.balloons = [];

                this.xGraph.color = CONFIG.COLORS.PINK;
                this.yGraph.color = CONFIG.COLORS.BLUE;
                this.currentCase = CASE_DATA.dobbsVJackson;
                this.currentPhases = STAGE2_PHASES;
                this.xGraph.strength = STAGE2_PHASES[0].xStr;
                this.xGraph.angle = STAGE2_PHASES[0].xAng;
                this.yGraph.strength = STAGE2_PHASES[0].yStr;
                this.yGraph.angle = STAGE2_PHASES[0].yAng;
                this.setStageUI(3);
            }
        } else if (this.state.stage === 3) {
            this.currentCase = CASE_DATA.dobbsVJackson;
            this.currentPhases = STAGE2_PHASES;
            this.xGraph.color = CONFIG.COLORS.PINK;
            this.yGraph.color = CONFIG.COLORS.BLUE;

            if (this.state.currentTime >= CONFIG.STAGE2_DURATION) {
                this.state.currentTime = CONFIG.STAGE2_DURATION;
                this.interpolatePhases(STAGE2_PHASES, CONFIG.STAGE2_DURATION);
                this.winnerSide = 'x';
                this.showGroundTruth = true;
                this.state.stage = 'done';
                this.pause();
                const playBtn = document.getElementById('playBtn') as HTMLButtonElement | null;
                if (playBtn) playBtn.disabled = true;
            } else {
                this.interpolatePhases(STAGE2_PHASES, this.state.currentTime);
                const prog = this.state.currentTime / CONFIG.STAGE2_DURATION;
                this.winnerSide = prog > 0.85 ? 'x' : null;
                this.showGroundTruth = prog > 0.9;
            }
        }

        this.updateBalloons();
        this.draw();

        if (this.state.isPlaying) {
            this.state.animFrameId = requestAnimationFrame((t) => this.animate(t));
        }
    }

    private interpolatePhases(phases: AnimationPhase[], time: number): void {
        let cur = phases[0];
        let nxt = phases[1] || phases[0];
        
        for (let i = 0; i < phases.length - 1; i++) {
            if (time >= phases[i].time && time < phases[i + 1].time) {
                cur = phases[i];
                nxt = phases[i + 1];
                break;
            }
        }
        
        if (time >= phases[phases.length - 1].time) {
            cur = nxt = phases[phases.length - 1];
        }

        const dur = nxt.time - cur.time;
        const t = dur > 0 ? Ease.clamp01((time - cur.time) / dur) : 1;
        const e = Ease.inOutCubic(t);

        this.xGraph.strength = Ease.lerp(cur.xStr, nxt.xStr, e);
        this.xGraph.angle = Ease.lerp(cur.xAng, nxt.xAng, e);
        this.yGraph.strength = Ease.lerp(cur.yStr, nxt.yStr, e);
        this.yGraph.angle = Ease.lerp(cur.yAng, nxt.yAng, e);
    }

    // ======================== DRAWING ========================
    private draw(): void {
        this.ctx.clearRect(0, 0, this.dim.w, this.dim.h);
        this.drawGrid();
        this.drawAxes();
        this.drawCrossingGraphs();
        this.drawArc();
        this.drawBalloons();
        this.drawLegend();
        this.drawProgressBar();
        this.drawPhaseDescription();
        if (this.showGroundTruth) this.drawGroundTruth();
        if (this.state.stage === 'preview') this.drawPreviewBadge();
    }

    private drawPreviewBadge(): void {
        const text = '▶ Press Play to animate: Stage 1 (Roe) → Stage 2 (Dobbs)';
        const bw = 380;
        const bh = 32;
        const bx = (this.dim.w - bw) / 2;
        const by = this.dim.h - 55;

        this.ctx.fillStyle = 'rgba(37, 99, 235, 0.9)';
        this.roundRect(this.ctx, bx, by, bw, bh, 16);
        this.ctx.fill();

        this.ctx.fillStyle = '#fff';
        this.ctx.font = '600 13px Inter, Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(text, this.dim.w / 2, by + 21);
    }

    private drawGrid(): void {
        const ctx = this.ctx;
        const { originX, originY } = this.dim;
        const spacing = CONFIG.GRID.SPACING;

        ctx.strokeStyle = CONFIG.COLORS.GRID_LINE;
        ctx.lineWidth = 0.5;

        for (let x = originX % spacing; x < this.dim.w; x += spacing) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, this.dim.h);
            ctx.stroke();
        }

        for (let y = originY % spacing; y < this.dim.h; y += spacing) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(this.dim.w, y);
            ctx.stroke();
        }
    }

    private drawAxes(): void {
        const ctx = this.ctx;
        const { originX, originY, w, h } = this.dim;

        ctx.strokeStyle = CONFIG.COLORS.GRID_AXIS;
        ctx.lineWidth = 2;

        // Vertical axis (H₀)
        ctx.beginPath();
        ctx.moveTo(originX, 0);
        ctx.lineTo(originX, h);
        ctx.stroke();

        // Horizontal axis (H₁)
        ctx.beginPath();
        ctx.moveTo(0, originY);
        ctx.lineTo(w, originY);
        ctx.stroke();

        // Labels
        ctx.fillStyle = CONFIG.COLORS.GRID_AXIS;
        ctx.font = '600 12px Inter, Arial';
        ctx.textAlign = 'center';
        ctx.fillText('H₀ (Null Hypothesis)', originX, 16);
        ctx.textAlign = 'left';
        ctx.fillText('H₁ (Alternative)', w - 140, originY - 8);
    }

    private drawCrossingGraphs(): void {
        const ctx = this.ctx;
        const { originX, originY } = this.dim;
        const scale = CONFIG.GRAPH.SCALE_FACTOR;

        // Calculate end points
        const xRad = (this.xGraph.angle * Math.PI) / 180;
        const yRad = (this.yGraph.angle * Math.PI) / 180;

        const xLen = this.xGraph.strength * scale;
        const yLen = this.yGraph.strength * scale;

        this.xGraphEnd = {
            x: originX + xLen * Math.cos(xRad),
            y: originY - xLen * Math.sin(xRad)
        };

        this.yGraphEnd = {
            x: originX + yLen * Math.cos(yRad),
            y: originY - yLen * Math.sin(yRad)
        };

        // Draw X graph
        this.drawArrowLine(
            ctx,
            originX, originY,
            this.xGraphEnd.x, this.xGraphEnd.y,
            this.xGraph.color,
            CONFIG.GRAPH.LINE_WIDTH,
            CONFIG.GRAPH.ARROW_SIZE
        );

        // Draw Y graph
        this.drawArrowLine(
            ctx,
            originX, originY,
            this.yGraphEnd.x, this.yGraphEnd.y,
            this.yGraph.color,
            CONFIG.GRAPH.LINE_WIDTH,
            CONFIG.GRAPH.ARROW_SIZE
        );

        // Origin point
        ctx.fillStyle = CONFIG.COLORS.BATTLE_POINT;
        ctx.beginPath();
        ctx.arc(originX, originY, CONFIG.BATTLE_POINT.RADIUS, 0, Math.PI * 2);
        ctx.fill();
    }

    private drawArc(): void {
        if (!this.winnerSide || !this.xGraphEnd || !this.yGraphEnd) return;

        const ctx = this.ctx;
        const { originX, originY } = this.dim;

        const winnerEnd = this.winnerSide === 'x' ? this.xGraphEnd : this.yGraphEnd;
        const dx = winnerEnd.x - originX;
        const dy = winnerEnd.y - originY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const radius = dist * 0.4;

        const startAngle = Math.atan2(originY - this.yGraphEnd.y, this.yGraphEnd.x - originX);
        const endAngle = Math.atan2(originY - this.xGraphEnd.y, this.xGraphEnd.x - originX);

        ctx.strokeStyle = CONFIG.COLORS.ARC_BLACK;
        ctx.lineWidth = CONFIG.ARC.LINE_WIDTH;
        ctx.beginPath();
        ctx.arc(originX, originY, radius, startAngle, endAngle, false);
        ctx.stroke();

        // Arrow at end
        const arrX = originX + radius * Math.cos(endAngle);
        const arrY = originY - radius * Math.sin(endAngle);
        const arrAngle = endAngle + Math.PI / 2;

        this.drawArrowHead(ctx, arrX, arrY, arrAngle, CONFIG.COLORS.ARC_BLACK, CONFIG.ARC.ARROW_SIZE);
    }

    private drawArrowLine(
        ctx: CanvasRenderingContext2D,
        x1: number, y1: number,
        x2: number, y2: number,
        color: string,
        lineWidth: number,
        arrowSize: number
    ): void {
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        const angle = Math.atan2(y2 - y1, x2 - x1);
        this.drawArrowHead(ctx, x2, y2, angle, color, arrowSize);
    }

    private drawArrowHead(
        ctx: CanvasRenderingContext2D,
        x: number, y: number,
        angle: number,
        color: string,
        size: number
    ): void {
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(
            x - size * Math.cos(angle - Math.PI / 6),
            y - size * Math.sin(angle - Math.PI / 6)
        );
        ctx.lineTo(
            x - size * Math.cos(angle + Math.PI / 6),
            y - size * Math.sin(angle + Math.PI / 6)
        );
        ctx.closePath();
        ctx.fill();
    }

    private drawBalloons(): void {
        const ctx = this.ctx;
        
        for (const balloon of this.balloons) {
            const isHovered = balloon === this.hoveredBalloon;
            const w = balloon.isMajority ? CONFIG.BALLOON.MAJOR_WIDTH : CONFIG.BALLOON.MINOR_WIDTH;
            const h = balloon.isMajority ? CONFIG.BALLOON.MAJOR_HEIGHT : CONFIG.BALLOON.MINOR_HEIGHT;

            // Shadow
            if (isHovered) {
                ctx.shadowColor = 'rgba(0, 0, 0, 0.3)';
                ctx.shadowBlur = 12;
                ctx.shadowOffsetX = 0;
                ctx.shadowOffsetY = 4;
            }

            // Balloon body
            ctx.fillStyle = CONFIG.COLORS.TOOLTIP_BG;
            this.roundRect(ctx, balloon.x, balloon.y, w, h, CONFIG.BALLOON.RADIUS);
            ctx.fill();

            ctx.strokeStyle = CONFIG.COLORS.TOOLTIP_BORDER;
            ctx.lineWidth = isHovered ? 2 : 1;
            ctx.stroke();

            ctx.shadowColor = 'transparent';
            ctx.shadowBlur = 0;

            // Text
            ctx.fillStyle = '#333';
            ctx.font = `600 ${balloon.isMajority ? 12 : 11}px Inter, Arial`;
            ctx.textAlign = 'left';
            ctx.fillText(balloon.title, balloon.x + 10, balloon.y + 18);

            ctx.font = `400 ${balloon.isMajority ? 10 : 9}px Inter, Arial`;
            let yOffset = balloon.y + 35;
            for (const line of balloon.lines) {
                const wrapped = this.wrapText(ctx, line, w - 20);
                for (const wl of wrapped) {
                    ctx.fillText(wl, balloon.x + 10, yOffset);
                    yOffset += 14;
                }
            }
        }
    }

    private wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
        const words = text.split(' ');
        const lines: string[] = [];
        let currentLine = '';

        for (const word of words) {
            const testLine = currentLine + (currentLine ? ' ' : '') + word;
            const metrics = ctx.measureText(testLine);
            
            if (metrics.width > maxWidth && currentLine) {
                lines.push(currentLine);
                currentLine = word;
            } else {
                currentLine = testLine;
            }
        }
        
        if (currentLine) lines.push(currentLine);
        return lines;
    }

    private drawLegend(): void {
        const ctx = this.ctx;
        const x = this.dim.w - 180;
        const y = 20;

        ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
        this.roundRect(ctx, x, y, 160, 100, 8);
        ctx.fill();

        ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.font = '600 11px Inter, Arial';
        ctx.fillStyle = '#333';
        ctx.textAlign = 'left';
        ctx.fillText('Graph Legend', x + 12, y + 20);

        const items = [
            { color: this.xGraph.color, label: `X: ${this.xGraph.label} graph (Plaintiff/Π)` },
            { color: this.yGraph.color, label: `Y: ${this.yGraph.label} graph (Defendant/Δ)` },
        ];

        ctx.font = '400 10px Inter, Arial';
        let yPos = y + 40;
        
        for (const item of items) {
            ctx.fillStyle = item.color;
            ctx.fillRect(x + 12, yPos - 6, 16, 3);
            
            ctx.fillStyle = '#555';
            ctx.fillText(item.label, x + 35, yPos);
            yPos += 22;
        }
    }

    private drawProgressBar(): void {
        if (this.state.stage === 'preview' || this.state.stage === 'done') return;

        const ctx = this.ctx;
        const barW = 300;
        const barH = 6;
        const barX = (this.dim.w - barW) / 2;
        const barY = this.dim.h - 30;

        let progress = 0;
        const totalDuration = CONFIG.STAGE1_DURATION + CONFIG.TRANSITION_DURATION + CONFIG.STAGE2_DURATION;

        if (this.state.stage === 1) {
            progress = this.state.currentTime / totalDuration;
        } else if (this.state.stage === 2) {
            progress = (CONFIG.STAGE1_DURATION + this.state.currentTime) / totalDuration;
        } else if (this.state.stage === 3) {
            progress = (CONFIG.STAGE1_DURATION + CONFIG.TRANSITION_DURATION + this.state.currentTime) / totalDuration;
        }

        progress = Ease.clamp01(progress);

        // Background
        ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
        this.roundRect(ctx, barX, barY, barW, barH, 3);
        ctx.fill();

        // Progress
        const gradient = ctx.createLinearGradient(barX, 0, barX + barW, 0);
        gradient.addColorStop(0, CONFIG.COLORS.BLUE);
        gradient.addColorStop(0.5, CONFIG.COLORS.PINK);
        gradient.addColorStop(1, CONFIG.COLORS.PINK);

        ctx.fillStyle = gradient;
        this.roundRect(ctx, barX, barY, barW * progress, barH, 3);
        ctx.fill();
    }

    private drawPhaseDescription(): void {
        if (this.state.stage === 'preview' || this.state.stage === 'done') return;

        const phase = this.getCurrentPhase();
        if (!phase) return;

        const ctx = this.ctx;
        const text = phase.desc;
        const maxWidth = 500;
        const padding = 16;

        ctx.font = '500 13px Inter, Arial';
        const metrics = ctx.measureText(text);
        const textWidth = Math.min(metrics.width, maxWidth);
        const boxWidth = textWidth + padding * 2;
        const boxHeight = 36;
        const x = (this.dim.w - boxWidth) / 2;
        const y = 20;

        ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
        this.roundRect(ctx, x, y, boxWidth, boxHeight, 8);
        ctx.fill();

        ctx.strokeStyle = 'rgba(0, 0, 0, 0.1)';
        ctx.lineWidth = 1;
        ctx.stroke();

        ctx.fillStyle = '#1e3a5f';
        ctx.textAlign = 'center';
        ctx.fillText(text, this.dim.w / 2, y + 23);
    }

    private getCurrentPhase(): AnimationPhase | null {
        const time = this.state.currentTime;
        
        for (let i = this.currentPhases.length - 1; i >= 0; i--) {
            if (time >= this.currentPhases[i].time) {
                return this.currentPhases[i];
            }
        }
        
        return this.currentPhases[0] || null;
    }

    private drawGroundTruth(): void {
        if (!this.winnerSide || !this.xGraphEnd || !this.yGraphEnd) return;

        const end = this.winnerSide === 'x' ? this.xGraphEnd : this.yGraphEnd;
        const ctx = this.ctx;

        ctx.fillStyle = CONFIG.COLORS.GROUND_TRUTH;
        ctx.beginPath();
        ctx.arc(end.x, end.y, 8, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.font = '600 11px Inter, Arial';
        ctx.fillStyle = CONFIG.COLORS.GROUND_TRUTH;
        ctx.textAlign = 'center';
        ctx.fillText('Ground Truth', end.x, end.y - 15);
    }

    private roundRect(
        ctx: CanvasRenderingContext2D,
        x: number, y: number,
        w: number, h: number,
        r: number
    ): void {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.arcTo(x + w, y, x + w, y + r, r);
        ctx.lineTo(x + w, y + h - r);
        ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
        ctx.lineTo(x + r, y + h);
        ctx.arcTo(x, y + h, x, y + h - r, r);
        ctx.lineTo(x, y + r);
        ctx.arcTo(x, y, x + r, y, r);
        ctx.closePath();
    }

    // ======================== BALLOONS UPDATE ========================
    private updateBalloons(): void {
        if (this.state.stage === 1 || this.state.stage === 3) {
            const progress = this.state.currentTime / 
                (this.state.stage === 1 ? CONFIG.STAGE1_DURATION : CONFIG.STAGE2_DURATION);
            
            if (progress > 0.3 && this.balloons.length === 0) {
                this.createBalloons();
            }
        } else if (this.state.stage === 2) {
            this.balloons = [];
        }
    }

    private createBalloons(): void {
        const cd = this.currentCase;
        const ox = this.dim.originX;
        const oy = this.dim.originY;

        this.balloons = [];

        if (this.state.stage === 1) {
            // Stage 1: Roe — X=Blue(bottom-right), Y=Pink(top-left)
            this.balloons.push({
                x: ox + 80, y: oy + 80,
                type: 'majority', title: cd.majority.label,
                lines: cd.majority.arguments.slice(0, 2), isMajority: true,
            });
            this.balloons.push({
                x: ox + 180, y: oy - 20,
                type: 'majority', title: 'Key Argument',
                lines: cd.majority.arguments.slice(2, 4), isMajority: true,
            });

            this.balloons.push({
                x: ox - 220, y: oy - 140,
                type: 'dissent', title: cd.dissent.label,
                lines: cd.dissent.arguments.slice(0, 2), isMajority: false,
            });
        } else if (this.state.stage === 3) {
            // Stage 3: Dobbs — X=Pink(up), Y=Blue(down)
            this.balloons.push({
                x: ox - 80, y: oy - 140,
                type: 'majority', title: cd.majority.label,
                lines: cd.majority.arguments.slice(0, 2), isMajority: true,
            });
            this.balloons.push({
                x: ox - 160, y: oy - 40,
                type: 'majority', title: 'Key Argument',
                lines: cd.majority.arguments.slice(2, 4), isMajority: true,
            });

            this.balloons.push({
                x: ox + 200, y: oy + 120,
                type: 'dissent', title: cd.dissent.label,
                lines: cd.dissent.arguments.slice(0, 2), isMajority: false,
            });
            this.balloons.push({
                x: ox + 120, y: oy + 200,
                type: 'dissent', title: 'Rebuttal',
                lines: cd.dissent.arguments.slice(2, 3), isMajority: false,
            });
        }
    }

    // ======================== MOUSE EVENTS ========================
    private onMouseMove(e: MouseEvent): void {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;

        let foundHover = false;

        for (const balloon of this.balloons) {
            const w = balloon.isMajority ? CONFIG.BALLOON.MAJOR_WIDTH : CONFIG.BALLOON.MINOR_WIDTH;
            const h = balloon.isMajority ? CONFIG.BALLOON.MAJOR_HEIGHT : CONFIG.BALLOON.MINOR_HEIGHT;

            if (mx >= balloon.x && mx <= balloon.x + w &&
                my >= balloon.y && my <= balloon.y + h) {
                this.hoveredBalloon = balloon;
                this.canvas.style.cursor = 'pointer';
                foundHover = true;
                this.showTooltip(balloon, mx, my);
                break;
            }
        }

        if (!foundHover) {
            this.hoveredBalloon = null;
            this.canvas.style.cursor = 'default';
            this.hideTooltip();
        }

        if (!this.state.isPlaying) {
            this.draw();
        }
    }

    private onClick(e: MouseEvent): void {
        if (this.hoveredBalloon) {
            this.openDetailModal(this.hoveredBalloon);
        }
    }

    private showTooltip(balloon: Balloon, mx: number, my: number): void {
        if (!this.tooltip) return;

        const html = `<strong>${escapeHtml(balloon.title)}</strong><div class="tooltip-line"></div>${balloon.lines.map(l => escapeHtml(l)).join('<br>')}`;
        this.tooltip.innerHTML = html;
        this.tooltip.style.display = 'block';
        this.tooltip.style.left = `${mx + 15}px`;
        this.tooltip.style.top = `${my + 15}px`;
    }

    private hideTooltip(): void {
        if (this.tooltip) {
            this.tooltip.style.display = 'none';
        }
    }

    private openDetailModal(balloon: Balloon): void {
        const modal = document.getElementById('detailModal');
        const tEl = document.getElementById('modalTitle');
        const cEl = document.getElementById('modalContent');
        if (!modal || !tEl || !cEl) return;

        const cd = this.currentCase;
        const side = balloon.isMajority ? cd.majority : cd.dissent;
        tEl.textContent = `${balloon.title} — ${cd.title}`;

        let html = `<p><strong>${escapeHtml(side.label)}</strong></p>`;
        html += `<p style="font-size:0.9em;color:#666;">Ground: ${escapeHtml(side.ground)}</p><ul>`;
        side.arguments.forEach(a => { html += `<li>${escapeHtml(a)}</li>`; });
        html += `</ul><p style="margin-top:14px;font-size:0.85em;"><a href="${escapeHtml(cd.url)}" target="_blank" rel="noopener">View on Oyez.org →</a></p>`;
        cEl.innerHTML = html;
        modal.style.display = 'flex';
    }

    private closeModal(): void {
        const modal = document.getElementById('detailModal');
        if (modal) modal.style.display = 'none';
    }

    // ======================== UI UPDATES ========================
    private setStageUI(stage: StageType): void {
        const titleEl = document.getElementById('caseTitle');
        const subtitleEl = document.getElementById('caseSubtitle');
        const infoEl = document.getElementById('caseInfo');
        const stage1Dot = document.getElementById('stage1Dot');
        const stage2Dot = document.getElementById('stage2Dot');

        if (stage === 'preview') {
            if (titleEl) titleEl.textContent = '⚖️ Dobbs v. Jackson (2022)';
            if (subtitleEl) subtitleEl.textContent = 'Overruling Roe v. Wade';
            if (infoEl) infoEl.textContent = 'Supreme Court Decision: 6-3 — Roe Overruled';
            if (stage1Dot) stage1Dot.classList.remove('active');
            if (stage2Dot) {
                stage2Dot.classList.add('active');
                stage2Dot.classList.add('preview');
            }
        } else if (stage === 1) {
            if (titleEl) titleEl.textContent = '⚖️ Roe v. Wade (1973)';
            if (subtitleEl) subtitleEl.textContent = 'Legal Battle Timeline Visualization';
            if (infoEl) infoEl.textContent = 'Supreme Court Decision: 7-2 Majority Opinion';
            if (stage1Dot) stage1Dot.classList.add('active');
            if (stage2Dot) {
                stage2Dot.classList.remove('active');
                stage2Dot.classList.remove('preview');
            }
        } else if (stage === 2) {
            if (titleEl) titleEl.textContent = '⚖️ Transition: Roe → Dobbs';
            if (subtitleEl) subtitleEl.textContent = 'Graph positions & colors swapping...';
            if (infoEl) infoEl.textContent = 'Animating transition between stages';
        } else if (stage === 3) {
            if (titleEl) titleEl.textContent = '⚖️ Dobbs v. Jackson (2022)';
            if (subtitleEl) subtitleEl.textContent = 'Overruling Roe v. Wade';
            if (infoEl) infoEl.textContent = 'Supreme Court Decision: 6-3 — Roe Overruled';
            if (stage1Dot) stage1Dot.classList.remove('active');
            if (stage2Dot) {
                stage2Dot.classList.add('active');
                stage2Dot.classList.remove('preview');
            }
        }
    }
}

// ============================================================
// INIT
// ============================================================
function initApp(): void {
    (window as any).lawgraph = new LawGraphVisualization();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

export default LawGraphVisualization;
