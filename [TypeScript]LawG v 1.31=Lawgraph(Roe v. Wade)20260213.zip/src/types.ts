/**
 * LawG v2.0 TypeScript - Type Definitions
 * TypeScript type definitions for Lawgraph Visualization
 */

// ============================================================
// CONFIG TYPES
// ============================================================

export interface ColorConfig {
    BLUE: string;
    BLUE_DARK: string;
    PINK: string;
    PINK_DARK: string;
    GREEN: string;
    GREEN_DARK: string;
    ARC_BLACK: string;
    BATTLE_POINT: string;
    GRID_LINE: string;
    GRID_AXIS: string;
    GROUND_TRUTH: string;
    TOOLTIP_BG: string;
    TOOLTIP_BORDER: string;
}

export interface GraphConfig {
    LINE_WIDTH: number;
    ARROW_SIZE: number;
    ARROW_ANGLE: number;
    SCALE_FACTOR: number;
}

export interface ArcConfig {
    LINE_WIDTH: number;
    ARROW_SIZE: number;
}

export interface BalloonConfig {
    MAJOR_WIDTH: number;
    MAJOR_HEIGHT: number;
    MINOR_WIDTH: number;
    MINOR_HEIGHT: number;
    RADIUS: number;
    TAIL_SIZE: number;
}

export interface GridConfig {
    SPACING: number;
}

export interface BattlePointConfig {
    RADIUS: number;
    PULSE_AMPLITUDE: number;
    PULSE_SPEED: number;
}

export interface Config {
    STAGE1_DURATION: number;
    STAGE2_DURATION: number;
    TRANSITION_DURATION: number;
    COLORS: ColorConfig;
    GRAPH: GraphConfig;
    ARC: ArcConfig;
    BALLOON: BalloonConfig;
    GRID: GridConfig;
    BATTLE_POINT: BattlePointConfig;
}

// ============================================================
// CASE DATA TYPES
// ============================================================

export interface Opinion {
    label: string;
    ground: string;
    arguments: string[];
    justices: number;
}

export interface CaseData {
    title: string;
    subtitle: string;
    info: string;
    url: string;
    majority: Opinion;
    dissent: Opinion;
}

export interface CaseDatabase {
    roeVWade: CaseData;
    dobbsVJackson: CaseData;
}

// ============================================================
// ANIMATION TYPES
// ============================================================

export interface AnimationPhase {
    time: number;
    xStr: number;
    xAng: number;
    yStr: number;
    yAng: number;
    desc: string;
}

export type StageType = 'preview' | 1 | 2 | 3 | 'done';

export interface AnimationState {
    stage: StageType;
    isPlaying: boolean;
    currentTime: number;
    lastTimestamp: number;
    animFrameId: number | null;
}

// ============================================================
// GRAPH TYPES
// ============================================================

export interface Graph {
    strength: number;
    angle: number;
    color: string;
    label: string;
}

export interface Dimensions {
    w: number;
    h: number;
    originX: number;
    originY: number;
    cx: number;
    cy: number;
}

export interface Point {
    x: number;
    y: number;
}

// ============================================================
// BALLOON TYPES
// ============================================================

export interface Balloon {
    x: number;
    y: number;
    type: 'majority' | 'dissent';
    title: string;
    lines: string[];
    isMajority: boolean;
}
