# LawG v1.34 — Lawgraph Visualization ⚖️📚

> **Multi-Case Legal & Academic Debate Visualization System**  
> Interactive Canvas-based visualization of landmark legal cases & intellectual debates

[![Version](https://img.shields.io/badge/Version-1.34-blue)](.)
[![Cases](https://img.shields.io/badge/Cases-3-green)](.)
[![Speed](https://img.shields.io/badge/Speed-2x-orange)](.)
[![Download](https://img.shields.io/badge/Download-Publish_Tab-059669)](.)

---

## 📖 Overview

An interactive Canvas-based visualization system supporting multiple landmark legal cases and academic debates with two-stage animations showing how positions evolve and clash.

### Supported Cases

#### 1. **Roe v. Wade → Dobbs v. Jackson** (English / 판례)
- **Stage 1: Roe v. Wade (1973)** — X(Blue/Plaintiff) wins 7-2  
- **Stage 2: Dobbs v. Jackson (2022)** — X(Pink/↑Up) wins 6-3 (overrules Roe)

#### 2. **채권자대위권 (2017다228618)** (Korean / 판례)
- **Stage 1: 조정성립 단계** — 원고(채권자) vs 甲 등(채무자) - X(Blue) wins  
- **Stage 2: 대위소송 단계** — 피고들(제3채무자) - Y(Blue/↓Down) wins (각하)

#### 3. **Habermas-Luhmann-Kontroverse (~1971)** (German / 학설 대립 📚)
- **These (Habermas)** — X(Blue/Habermas) dominiert mit kommunikativer Rationalität  
- **Antithese (Luhmann)** — Y(Blue/↓Unten/Luhmann) dominiert mit Autopoiesis  
- ⚠️ *Akademischer Schulenstreit, kein Gerichtsurteil*

---

## ✅ Completed Features

### v1.34 (2026-03-07)
- [x] **Habermas-Luhmann → 학설 대립 전환**: 법률 용어(판결/승/패) → 학술 논쟁 용어(These/Antithese/dominiert)
- [x] **WIN 라벨 정책 변경**: 메뉴 1(Roe/Dobbs), 2(채권자대위권)에서 `WIN` 표시 유지 (⬅ 화살표만 제거), 메뉴 3(Habermas)에서는 WIN 라벨 완전 제거
- [x] **프로그램 소스 다운로드**: 왼쪽 개발자 창의 **Publish 탭**에서 다운로드
- [x] 📚 아이콘 (⚖️ → 📚) 및 학술 용어 적용 (Grundlage → Theoretische Basis 등)
- [x] These(H₀)/Antithese(H₁) 축 라벨

### v1.33
- [x] Habermas-Luhmann-Kontroverse 3rd case (German)
- [x] 2x animation speed (28s → 14s per stage)

### v1.32
- [x] Multi-case dropdown selector
- [x] 채권자대위권 case

### v1.31 and earlier
- [x] Crossing X/Y graphs, two-stage animation, color/position swap
- [x] Black arc with arrow, Excel-style tooltips, Ground Truth markers
- [x] Progress bar, phase descriptions, detail modals
- [x] Responsive design, XSS prevention

---

## 🗂️ Project Structure

```
index.html              Main page (3 cases)
css/
  └── style.css         Styles (glassmorphism, responsive)
js/
  └── lawgraph.js       Core visualization engine
README.md               This documentation
```

## 🔗 Functional Entry URIs

| Path | Description |
|------|------------|
| `index.html` | Main application |
| Dropdown: "Roe v. Wade → Dobbs" | US Supreme Court (English) |
| Dropdown: "채권자대위권" | Korean creditor case |
| Dropdown: "Habermas-Luhmann" | German academic debate 📚 |
| Publish 탭 | 전체 소스 다운로드 (개발자 창 좌측) |

## 🔒 Security & Compliance

- ✅ 개인정보 수집/전송 없음
- ✅ 구글 드라이브/외부 폴더 접근 없음
- ✅ 소스 다운로드: Publish 탭 통해 제공 (외부 CDN 불필요)
- ✅ XSS 방지 (`escapeHtml()`)
- ✅ 외부 링크 `rel="noopener"` 적용
- ✅ CDN: jsDelivr (Font Awesome), Google Fonts — 신뢰된 소스만 사용

---

## 🚀 Recommended Next Steps

1. Add more cases / academic debates
2. Audio narration for each phase
3. Canvas → PNG image export
4. Side-by-side comparison mode
5. Timeline scrubbing (drag progress bar)

---

*LawG v1.34 — Built 2026-03-07 | 3 Cases | 2x Speed | Source via Publish Tab*
