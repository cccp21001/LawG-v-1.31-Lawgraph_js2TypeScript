# LawG v1.36 Secure Build

보안 강화 패치:
- CSP(Content-Security-Policy) 추가
- X-Content-Type-Options 추가
- Referrer-Policy 추가
- innerHTML 사용부 safeSetHTML() sanitizer 적용
- javascript: URL 및 inline event handler 제거 방어
- defer script 로딩 대응
- CONFIG/Ease 객체 freeze 적용

권장 서버 헤더:
- X-Frame-Options: DENY
- Permissions-Policy
- Strict-Transport-Security (HTTPS 환경)
