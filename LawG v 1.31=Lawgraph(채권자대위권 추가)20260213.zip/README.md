# LawG v1.32 — Lawgraph Visualization ⚖️

> **Multi-Case Legal Battle Visualization System**  
> Interactive Canvas-based visualization of landmark legal cases with crossing graph animations

[![Version](https://img.shields.io/badge/Version-1.32-blue)](.)
[![Cases](https://img.shields.io/badge/Cases-2-green)](.)
[![Security](https://img.shields.io/badge/Security-Passed-4CAF50)](.)

---

## 📖 Overview

An interactive Canvas-based visualization system supporting multiple landmark legal cases with two-stage animations showing how legal positions evolve and clash.

### Supported Cases

#### 1. **Roe v. Wade → Dobbs v. Jackson**
- **Stage 1: Roe v. Wade (1973)** — X(Blue/Plaintiff) wins 7-2  
- **Stage 2: Dobbs v. Jackson (2022)** — X/Y positions & colors swap, X(Pink/↑Up) wins 6-3 (overrules Roe)

#### 2. **채권자대위권 (2017다228618)**
- **Stage 1: 조정성립 단계** — 원고(채권자) vs 甲 등(채무자) - X(Blue) wins  
- **Stage 2: 대위소송 단계** — 원고(甲 등 대위) vs 피고들(제3채무자) - Y(Blue/↓Down) wins (각하)

---

## ✅ Completed Features (v1.32)

### Core Visualization
- **Crossing X/Y Graph Pattern**: Two graph vectors extend through origin point, crossing each other
- **Dynamic Angles & Lengths**: Proportional to strength of arguments (justice count, legal reasoning power)
- **Two-Stage Animation**: Continuous flow from Stage 1 → Transition → Stage 2
- **Position & Color Swap**: Graphs swap positions and colors between stages
- **Winner Indication**: Thick black arc with arrow pointing to winner
- **Ground Truth Markers**: Green text on winning graph showing legal foundation

### Multi-Case Support
- **Case Selector Dropdown**: Switch between different legal cases
- **Dynamic UI Updates**: Header, stage indicators, and info cards update based on selected case
- **Case-Specific Data**: Each case has unique stage configurations, arguments, and outcomes

### Interactive Elements
- **Excel-Style Tooltips**: Yellow balloon tooltips on hover (larger = majority opinion)
- **Playback Controls**: Play, Pause, Reset buttons
- **Stage Indicators**: Visual dots showing current stage progression
- **Modal Details**: Click balloons for detailed case information

### Visual Design
- **Gradient Background**: Deep blue gradient with glassmorphism effects
- **Color Coding**:
  - Blue (#2563EB) — Plaintiff/원고
  - Pink (#DB2777) — Defendant/피고
  - Green (#16A34A) — Ground Truth markers
  - Black (#111111) — Winner arc arrow
- **Responsive Layout**: Adapts to different screen sizes
- **Smooth Animations**: Eased transitions with cubic easing functions

---

## 🎯 Case Details

### Case 1: Roe v. Wade → Dobbs v. Jackson

**Stage 1: Roe v. Wade (1973)**
- **Winner**: X(Blue) — Majority Opinion 7-2
- **Key Arguments**:
  - 14th Amendment Due Process includes privacy rights
  - Woman's right to choose abortion is constitutional
  - Trimester framework balances rights and state interest
- **Ground Truth**: 14th Amdt. Due Process / Privacy

**Stage 2: Dobbs v. Jackson (2022)**
- **Winner**: X(Pink) — Majority Opinion 6-3
- **Key Arguments**:
  - Constitution does not confer right to abortion
  - Roe was "egregiously wrong from the start"
  - Authority returned to people & elected representatives
- **Ground Truth**: Constitutional textualism / Stare decisis reexamined
- **Result**: Roe v. Wade OVERRULED

---

### Case 2: 채권자대위권 (2017다228618)

**Stage 1: 조정성립 단계**
- **당사자**: 원고(채권자) vs 甲 등(채무자)
- **Winner**: X(Blue) — 원고(채권자)
- **주요 논거**:
  - 甲 등에 대한 소유권이전등기청구권 보유
  - 재판상 조정으로 확정된 권리
  - 조정조서는 확정판결과 동일한 효력
  - 피보전권리가 인정된다
- **Ground Truth**: 재판상 조정 / 확정판결 효력

**Stage 2: 대위소송 단계**
- **당사자**: 원고(甲 등 대위) vs 피고들(제3채무자)
- **Winner**: Y(Blue) — 피고들(제3채무자)
- **주요 논거**:
  - 조정 내용이 강행법규 위반으로 무효
  - 소송목적 권리취득은 허용 불가
  - 제3채무자는 피보전권리 존부 다툴 수 있다
  - 조정 당사자 아닌 자에 대해서는 효력 없음
- **Ground Truth**: 강행법규 우선 / 제3자 보호
- **Result**: 대법원 판결 — 소 각하 (파기자판)

**핵심 법리**:
> 채권자대위권 행사 시, 채권자와 채무자 사이의 확정판결이나 조정이 있더라도, 그 내용이 강행법규 위반으로 무효인 경우, 제3채무자에 대한 관계에서는 피보전권리가 존재하지 않는다.

---

## 📊 How to Read the Visualization

1. **X Graph (Plaintiff/Π)**: Starts from origin, represents plaintiff's position
2. **Y Graph (Defendant/Δ)**: Starts from origin, crosses X graph
3. **Crossing Pattern**: Graphs cross each other showing legal battle tension
4. **Graph Length**: Proportional to argument strength
5. **Graph Angle**: Shows direction/nature of arguments
6. **Black Arc with Arrow**: Points to the winning side
7. **Vertical Axis**: Null Hypothesis (H₀)
8. **Horizontal Axis**: Alternative Hypothesis (H₁)
9. **Ground Truth**: Green text on winning graph showing legal foundation
10. **Yellow Tooltips**: Hover for case details (larger = majority opinion)

---

## 🚀 Usage

### Basic Controls
- **Play Button**: Start animation from Stage 1
- **Pause Button**: Pause current animation
- **Reset Button**: Return to preview state (Stage 2 final result)
- **Case Selector**: Switch between different legal cases

### Animation Flow
1. **Preview State**: Shows final result of Stage 2 (winner declared)
2. **Click Play**: Animation starts from Stage 1
3. **Stage 1**: First case/stage animates with evolving arguments
4. **Transition**: Color and position swap (3 seconds)
5. **Stage 2**: Second case/stage animates
6. **Done**: Animation completes, winner declared

### Interaction
- **Hover over balloons**: View detailed arguments
- **Click balloons**: Open modal with full case details
- **Switch cases**: Use dropdown to change case visualization

---

## 🏗️ Technical Architecture

### File Structure
```
.
├── index.html          # Main HTML structure
├── css/
│   └── style.css       # Styling and animations
├── js/
│   └── lawgraph.js     # Core visualization engine
└── README.md           # This file
```

### Key Components

#### JavaScript (lawgraph.js)
- **CASE_DATA**: Contains all case information and arguments
- **PHASES**: Animation keyframes for each stage
- **LawGraphVisualization Class**: Main visualization engine
  - `constructor()`: Initialize canvas and state
  - `animate()`: Animation loop with easing
  - `draw()`: Render graphs, axes, balloons, arcs
  - `switchCase()`: Change between cases
  - `updateBalloons()`: Dynamic tooltip positioning

#### Data Structure
```javascript
CASE_DATA = {
    roeVWade: { title, subtitle, info, majority, dissent },
    dobbsVJackson: { title, subtitle, info, majority, dissent },
    creditorSubrogation: {
        stage1: { plaintiff, defendant },
        stage2: { plaintiff, defendant }
    }
}
```

#### Animation Phases
```javascript
STAGE_PHASES = [
    { time: 0, xStr: 3, yStr: 3, xAng: 25, yAng: -20, desc: '...' },
    // ... more keyframes
]
```

---

## 🎨 Design System

### Colors
- **Blue (#2563EB)**: Plaintiff/원고/Majority in Stage 1
- **Pink (#DB2777)**: Defendant/피고/Dissent in Stage 1
- **Green (#16A34A)**: Ground Truth markers
- **Black (#111111)**: Winner arc arrow
- **Yellow (#FFFDE7)**: Tooltip background

### Typography
- **Font Family**: Inter, Segoe UI, Tahoma
- **Heading**: 2.2em, bold, text-shadow
- **Body**: 0.95-1.1em, variable opacity

### Effects
- **Glassmorphism**: `backdrop-filter: blur(12px)`
- **Gradients**: Background and header badges
- **Shadows**: Subtle shadows on cards and tooltips
- **Transitions**: 0.3-0.8s ease

---

## 📦 Dependencies

- **No external JavaScript libraries** — Pure vanilla JS
- **Font Awesome 6.4.0** — Icon fonts (via CDN)
- **Google Fonts (Inter)** — Typography (via CDN)

---

## 🔄 Version History

### v1.32 (2026-02-13) — Multi-Case Support
- ✨ Added case selector dropdown
- ✨ Added 채권자대위권 (2017다228618) case
- ✨ Dynamic UI updates based on selected case
- ✨ Case-specific stage indicators and info cards
- 🐛 Fixed balloon positioning for different cases

### v1.31 (2026-02-13) — Initial Release
- ✨ Initial release with Roe v. Wade → Dobbs v. Jackson
- ✨ Two-stage crossing graph animation
- ✨ Position and color swap between stages
- ✨ Excel-style yellow balloon tooltips
- ✨ Ground Truth markers on winning graphs

---

## 🔗 References

### Roe v. Wade → Dobbs v. Jackson
- [Roe v. Wade — Oyez.org](https://www.oyez.org/cases/1971/70-18)
- [Dobbs v. Jackson — Oyez.org](https://www.oyez.org/cases/2021/19-1392)

### 채권자대위권 (2017다228618)
- [대법원 종합법률정보](https://www.scourt.go.kr/)
- 대법원 2017다228618 판결 (파기자판)

---

## 📝 Future Enhancements

### Planned Features
- [ ] Add more landmark cases
- [ ] Export animation as video/GIF
- [ ] Share visualization via URL parameters
- [ ] Multi-language support (EN/KO toggle)
- [ ] Custom case creation tool
- [ ] Statistical analysis overlay
- [ ] Timeline view of case history

### Under Consideration
- [ ] 3D visualization mode
- [ ] Sound effects for transitions
- [ ] Mobile touch gestures
- [ ] Print-friendly PDF export
- [ ] API for case data import

---

## 🤝 Contributing

This visualization system is designed to make complex legal battles understandable through visual storytelling. If you have suggestions for additional cases or improvements, please consider:

1. Identifying landmark cases with clear two-stage progression
2. Providing detailed argument breakdowns
3. Ensuring accurate legal citations and grounds

---

## 📄 License

Educational and demonstration purposes.  
Legal case information is based on public court records and decisions.

---

## 👤 Author

**LawG v1.32 — Lawgraph Visualization System**  
Built: 2026-02-13  
Multi-Case Support: Roe/Dobbs & 채권자대위권

---

**⚖️ Justice through Visualization**
