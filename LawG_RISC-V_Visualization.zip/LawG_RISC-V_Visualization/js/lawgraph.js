/**
 * LawG v1.33 - Lawgraph 채권자대위권(surrogation) v2 Engine (Multi-Case Support)
 * 
 * Supported Cases:
 * 1. Roe v. Wade (1973) → Dobbs v. Jackson Women's Health Organization (2022)
 * 2. 채권자대위권(surrogation) (2017다228618) - 조정(기판력 : Res Judicata)성립 → 대위소송 단계 ⭐ DEFAULT
 * 3. Habermas-Luhmann-Kontroverse (~1971) - Akademische Debatte (German)
 * 
 * v1.33 Changes (from v1.31):
 * - DEFAULT case: 채권자대위권(surrogation) (첫화면에 XYZ 마지막 장면 표시)
 * - Menu 2 채권자대위권(surrogation) 한국어 수정/강화
 * - Speed 2x: STAGE_DURATION 14000→7000ms, TRANSITION 1500→750ms
 * - Download removed from UI (available only in workspace)
 * - UML 2.0 instead of ERD
 * - WIN label: shown on menu 1 (Roe/Dobbs) & 2 (채권자대위권(surrogation)), removed for menu 3 (Habermas)
 * - Removed ⬅ arrow from WIN label (clean 'WIN' text only)
 * 
 * Features:
 * - Crossing X/Y graphs with dynamic angles and lengths
 * - Two-stage continuous animation (1 click plays both)
 * - Color swap between stages (Blue/Pink → Pink/Blue)
 * - Position swap in Stage 2 (X goes up, Y goes down)
 * - Thick black arc with arrow pointing to winner
 * - Excel-style yellow balloon tooltips
 * - Null Hypothesis / Alternative Hypothesis axis labels
 * - Ground Truth marking on winning graph
 */

// ============================================================
// CONSTANTS — SPEED 2x OPTIMIZED
// ============================================================
const CONFIG = {
    STAGE1_DURATION: 7000,      // was 14000 → 7000 (2x)
    STAGE2_DURATION: 7000,      // was 14000 → 7000 (2x)
    TRANSITION_DURATION: 750,   // was 1500 → 750 (2x)

    COLORS: {
        BLUE: '#2563EB',
        BLUE_DARK: '#1D4ED8',
        PINK: '#DB2777',
        PINK_DARK: '#BE185D',
        GREEN: '#16A34A',
        GREEN_DARK: '#15803D',
        ARC_BLACK: '#111111',
        BATTLE_POINT: '#EF4444',
        GRID_LINE: '#e8e8e8',
        GRID_AXIS: '#9CA3AF',
        GROUND_TRUTH: '#16A34A',
        TOOLTIP_BG: '#FFFDE7',
        TOOLTIP_BORDER: '#FBC02D',
    },

    GRAPH: {
        LINE_WIDTH: 2.5,
        ARROW_SIZE: 14,
        ARROW_ANGLE: Math.PI / 6,
        SCALE_FACTOR: 22,
    },

    ARC: {
        LINE_WIDTH: 4.5,
        ARROW_SIZE: 14,
    },

    BALLOON: {
        MAJOR_WIDTH: 220,
        MAJOR_HEIGHT: 90,
        MINOR_WIDTH: 170,
        MINOR_HEIGHT: 70,
        RADIUS: 3,
        TAIL_SIZE: 8,
    },

    GRID: { SPACING: 50 },

    BATTLE_POINT: {
        RADIUS: 6,
        PULSE_AMPLITUDE: 3,
        PULSE_SPEED: 250,
    },
};

// ============================================================
// EASING HELPERS
// ============================================================
const Ease = {
    inOutCubic(t) {
        return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    },
    lerp(a, b, t) {
        return a + (b - a) * t;
    },
    clamp01(t) {
        return Math.max(0, Math.min(1, t));
    }
};

function escapeHtml(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

// ============================================================
// CASE DATA
// ============================================================
const CASE_DATA = {
    roeVWade: {
        title: 'Roe v. Wade (1973)',
        subtitle: 'Legal Battle Timeline Visualization',
        info: 'Supreme Court Decision: 7-2 Majority Opinion',
        url: 'https://www.oyez.org/cases/1971/70-18',
        majority: {
            justices: 7,
            label: 'Majority (7)',
            arguments: [
                '14th Amdt Due Process → privacy rights',
                "Woman's right to choose is constitutional",
                'Trimester framework balances rights & state interest',
                '1st tri: No regulation; 2nd: Health; 3rd: May prohibit',
            ],
            ground: '14th Amdt. Due Process / Privacy',
        },
        dissent: {
            justices: 2,
            label: 'Dissent (2)',
            arguments: [
                'No constitutional basis for abortion rights',
                '"Raw Judicial Power" — exceeded authority',
                'State legislatures should decide democratically',
            ],
            ground: 'Legislative authority / States rights',
        },
    },
    dobbsVJackson: {
        title: 'Dobbs v. Jackson (2022)',
        subtitle: 'Overruling Roe v. Wade',
        info: 'Supreme Court Decision: 6-3 — Roe Overruled',
        url: 'https://www.oyez.org/cases/2021/19-1392',
        majority: {
            justices: 6,
            label: 'Majority (6)',
            arguments: [
                'Constitution does not confer right to abortion',
                'Roe was "egregiously wrong from the start"',
                'Authority returned to people & elected representatives',
                'No basis in text, history, or structure of Constitution',
            ],
            ground: 'Constitutional textualism / Stare decisis reexamined',
        },
        dissent: {
            justices: 3,
            label: 'Dissent (3)',
            arguments: [
                'Overruling Roe undermines Court legitimacy',
                'Women lose fundamental constitutional protection',
                'Stare decisis abandoned without justification',
            ],
            ground: 'Precedent / Substantive due process',
        },
    },
    creditorSubrogation: {
        title: '채권자대위권(surrogation) (2017다228618)',
        subtitle: '피보전권리의 존부 판단',
        info: '대법원 판결: 파기자판(각하)',
        url: 'https://www.scourt.go.kr/',
        stage1: {
            title: '조정(기판력 : Res Judicata)성립 단계',
            subtitle: '원고 vs 甲 등 - 재판상 조정(기판력 : Res Judicata)',
            plaintiff: {
                strength: 7,
                label: '원고(채권자)',
                arguments: [
                    '甲 등에 대한 소유권이전등기청구권 보유',
                    '재판상 조정(기판력 : Res Judicata)으로 확정된 권리',
                    '조정(기판력 : Res Judicata)조서는 확정판결과 동일한 효력',
                    '피보전권리가 인정된다',
                ],
                ground: '재판상 조정(기판력 : Res Judicata) / 확정판결 효력',
            },
            defendant: {
                strength: 3,
                label: '甲 등(채무자)',
                arguments: [
                    '조정(기판력 : Res Judicata) 내용의 실질적 문제',
                    '강행법규 위반 가능성',
                ],
                ground: '조정(기판력 : Res Judicata)의 실질 검토 필요',
            },
        },
        stage2: {
            title: '대위소송 단계',
            subtitle: '원고(甲 등 대위) vs 피고들',
            plaintiff: {
                strength: 3,
                label: '원고(대위청구)',
                arguments: [
                    '재판상 조정(기판력 : Res Judicata)에 기초한 피보전권리',
                    '확정판결 효력 주장',
                ],
                ground: '조정(기판력 : Res Judicata)조서의 기판력',
            },
            defendant: {
                strength: 7,
                label: '피고들(제3채무자)',
                arguments: [
                    '조정(기판력 : Res Judicata) 내용이 강행법규 위반으로 무효',
                    '소송목적 권리취득은 허용 불가',
                    '제3채무자는 피보전권리 존부 다툴 수 있다',
                    '조정(기판력 : Res Judicata) 당사자 아닌 자에 대해서는 효력 없음',
                ],
                ground: '강행법규 우선 / 제3자 보호',
            },
        },
    },
    riscVFragmentation: {
        title: 'RISC-V 명령어셋 단편화 해결방안 (ISA Modularization)',
        subtitle: 'ISA Fragmentation → Modular ISA + Automated Compatibility Verification',
        info: 'Stage 1: 표준 Base ISA와 비표준 커스텀 확장의 충돌',
        url: 'https://riscv.org/specifications/',
        stage1: {
            title: 'Stage 1: ISA 단편화 및 호환성 난립',
            subtitle: '표준 Base ISA vs 비표준 커스텀 확장',
            plaintiff: {
                strength: 7,
                label: '표준 Base ISA',
                arguments: [
                    '표준 RISC-V Base ISA를 기준으로 툴체인 호환성 유지',
                    'M/A/F/D/V 등 표준 확장 조합을 명시적으로 관리',
                    '비표준 확장이 ABI·컴파일러·시뮬레이터와 충돌',
                    '확장 조합이 늘수록 호환성 검증 비용 증가',
                ],
                ground: '표준 ISA 계층 / 호환성 기준',
            },
            defendant: {
                strength: 10,
                label: '비표준 Custom Extensions',
                arguments: [
                    '벤더별 커스텀 명령어가 독립적으로 추가됨',
                    '동일 기능에 서로 다른 인코딩·ABI·툴체인 지원 발생',
                    '컴파일러와 시뮬레이터 간 지원 범위 불일치',
                    '결과: 툴체인/시뮬레이터 호환성 충돌',
                ],
                ground: '벤더 특화 확장 / 파편화',
            },
        },
        stage2: {
            title: 'Stage 2: 표준 모듈화 및 자동 호환 검증',
            subtitle: '계층형 모듈 ISA + 자동 검증 + Vendor Plug-in 격리',
            plaintiff: {
                strength: 9,
                label: '계층형 Modular ISA',
                arguments: [
                    '표준 Base ISA와 확장 모듈을 독립적인 레이어로 구성',
                    'riscv-config.toml 메타데이터로 ISA 조합과 버전 명시',
                    '확장 간 의존성과 호환 규칙을 기계적으로 표현',
                    '표준 모듈 조합은 공통 툴체인 경로로 처리',
                ],
                ground: 'ISA Modularization / Metadata-driven configuration',
            },
            defendant: {
                strength: 10,
                label: 'riscv-verify 자동 검증',
                arguments: [
                    'ISA 메타데이터를 파싱하여 지원 조합을 자동 검증',
                    '컴파일러·시뮬레이터·ABI 호환성 체크를 파이프라인화',
                    '벤더 확장은 RVX_vendor_id 형태의 ABI 경계로 격리',
                    '표준 베이스에 영향 없이 플러그인으로 연결',
                ],
                ground: '자동 호환 검증 / Plugin ABI isolation',
            },
        },
        vendorPlugin: {
            label: 'Z (Vendor Plug-in)',
            strength: 5,
            arguments: [
                'RVX_vendor_id 형태로 벤더 명령어를 격리',
                'Base ISA에 영향을 주지 않는 passive extension',
                '표준 검증 경로와 독립적인 플러그인 ABI 경계',
            ],
            ground: 'Vendor extension isolation',
        },
    },
    habermasLuhmann: {
        title: 'Habermas-Luhmann-Kontroverse (~1971)',
        subtitle: 'Akademischer Streit — Normativ vs. Systemisch',
        info: 'Grundlagendebatte der deutschen Soziologie (Schulenstreit)',
        url: 'https://www.lernhelfer.de/schuelerlexikon/politikwirtschaft/artikel/die-habermas-luhmann-kontroverse-theorie-der-gesellschaft',
        stage1: {
            title: 'These: Normative Theorie (Habermas)',
            subtitle: 'Habermas vs. Luhmann — Kommunikative Rationalität',
            plaintiff: {
                strength: 7,
                label: 'Habermas (Krit. Theorie)',
                arguments: [
                    'Lebenswelt als Basis der sozialen Ordnung',
                    'Kommunikative Rationalität erzeugt Konsens',
                    'Kolonisierung der Lebenswelt durch Geld & Macht',
                    'Demokratie durch rationale Verständigung',
                ],
                ground: 'Kommunikatives Handeln / Konsens',
            },
            defendant: {
                strength: 3,
                label: 'Luhmann (Gegenthese)',
                arguments: [
                    'Gesellschaft = System aus Kommunikation',
                    'Normative Ansprüche sind naiv',
                ],
                ground: 'Komplexitätsreduktion / Funktion',
            },
        },
        stage2: {
            title: 'Antithese: Systemtheorie (Luhmann)',
            subtitle: 'Autopoiesis & funktionale Differenzierung',
            plaintiff: {
                strength: 3,
                label: 'Habermas (Einwand)',
                arguments: [
                    'Zwischen Fakten und Normen — Recht als Brücke',
                    'Elemente der Systemtheorie integriert',
                ],
                ground: 'Normative Vernunft / Rechtstheorie',
            },
            defendant: {
                strength: 7,
                label: 'Luhmann (Autopoiesis)',
                arguments: [
                    'Autopoietische, selbstreferentielle Subsysteme',
                    'Binäre Codes: Recht/Unrecht, wahr/unwahr',
                    'Funktionale Differenzierung der Moderne',
                    'Komplexität ist unvermeidbar — Systeme managen sie',
                ],
                ground: 'Autopoiesis / Funktionale Differenzierung',
            },
        },
    },
};

// ============================================================
// ANIMATION PHASES — SPEED 2x (time values halved)
// ============================================================
const STAGE1_PHASES = [
    { time: 0,    xStr: 3, yStr: 3, xAng: 25,  yAng: -20,  desc: 'Case Filed: Texas abortion law challenged' },
    { time: 1250, xStr: 5, yStr: 4, xAng: 32,  yAng: -28,  desc: 'Initial Arguments: Privacy vs. State Authority' },
    { time: 2500, xStr: 7, yStr: 5, xAng: 40,  yAng: -35,  desc: '14th Amendment Debate: Due Process scope' },
    { time: 4000, xStr: 8, yStr: 5, xAng: 48,  yAng: -32,  desc: 'Trimester Framework Proposed' },
    { time: 5250, xStr: 6, yStr: 6, xAng: 42,  yAng: -38,  desc: 'Dissent Objects: Judicial overreach claimed' },
    { time: 6500, xStr: 10,yStr: 4, xAng: 55,  yAng: -25,  desc: 'DECISION: Majority prevails 7-2 — X(Blue) WINS' },
];

const STAGE2_PHASES = [
    { time: 0,    xStr: 3, yStr: 3, xAng: -22, yAng: 22,   desc: 'New Case: Mississippi 15-week ban challenged' },
    { time: 1250, xStr: 5, yStr: 5, xAng: -30, yAng: 30,   desc: 'Stare Decisis Debate: Should Roe be overturned?' },
    { time: 2500, xStr: 7, yStr: 6, xAng: -42, yAng: 35,   desc: 'Constitutional Textualism: No explicit right found' },
    { time: 4000, xStr: 8, yStr: 5, xAng: -48, yAng: 30,   desc: '"Roe was egregiously wrong from the start"' },
    { time: 5250, xStr: 6, yStr: 6, xAng: -38, yAng: 38,   desc: 'Fierce Dissent: Legitimacy of Court questioned' },
    { time: 6500, xStr: 10,yStr: 4, xAng: -55, yAng: 22,   desc: 'DECISION: Roe OVERRULED 6-3 — X(Pink) WINS' },
];

// 채권자대위권(surrogation) — Stage 1: 조정(기판력 : Res Judicata)성립 (2x speed)
const CREDITOR_STAGE1_PHASES = [
    { time: 0,    xStr: 3, yStr: 6, xAng: 25,  yAng: -20,  desc: '소송제기: 원고 vs 甲 등 - 소유권이전등기 청구' },
    { time: 1250, xStr: 5, yStr: 8, xAng: 32,  yAng: -25,  desc: '조정(기판력 : Res Judicata) 진행: 당사자 간 합의 시도' },
    { time: 2500, xStr: 6, yStr: 6, xAng: 40,  yAng: -22,  desc: '재판상 조정(기판력 : Res Judicata) 성립: 소유권이전등기청구권 인정' },
    { time: 4000, xStr: 7, yStr: 6, xAng: 48,  yAng: -20,  desc: '조정(기판력 : Res Judicata)조서 작성: 확정판결 동일 효력' },
    { time: 5250, xStr: 8, yStr: 4, xAng: 52,  yAng: -18,  desc: '원고의 피보전권리 확보' },
    { time: 6500, xStr: 7, yStr: 6, xAng: 50,  yAng: -20,  desc: '조정(기판력 : Res Judicata) 확정 — 원고(채권자) 승' },
];

// 채권자대위권(surrogation) — Stage 2: 대위소송 (2x speed)
const CREDITOR_STAGE2_PHASES = [
    { time: 0,    xStr: 3, yStr: 8.4, xAng: 22, yAng: -22,   desc: '채권자대위권(surrogation)소송 제기: 원고(甲 등 대위) vs 피고들' },
    { time: 1250, xStr: 5, yStr: 8.4, xAng: 30, yAng: -28,   desc: '피고들의 항변: 조정(기판력 : Res Judicata)내용 강행법규 위반 주장' },
    { time: 2500, xStr: 6, yStr: 8.4, xAng: 38, yAng: -25,   desc: '법원 검토: 소송목적 권리취득의 유효성' },
    { time: 4000, xStr: 7, yStr: 8.4, xAng: 45, yAng: -22,   desc: '법리 판단: 제3채무자는 피보전권리 존부 다툴 수 있다' },
    { time: 5250, xStr: 8, yStr: 8.4, xAng: 48, yAng: -20,   desc: '강행법규 우선: 조정(기판력 : Res Judicata) 무효 인정' },
    { time: 6500, xStr: 7, yStr: 12, xAng: 52, yAng: -18,   desc: '대법원 판결: 소 각하 — 피고들(제3채무자) 승' },
];

// Habermas-Luhmann (2x speed)
const RISCV_STAGE1_PHASES = [
    { time: 0,    xStr: 3, yStr: 4, xAng: 24, yAng: -22, desc: 'Stage 1 시작: 표준 Base ISA와 비표준 확장 공존' },
    { time: 1250, xStr: 5, yStr: 6, xAng: 32, yAng: -28, desc: '벤더별 Custom Extension 증가: 동일 기능의 구현 방식 분화' },
    { time: 2500, xStr: 6, yStr: 8, xAng: 40, yAng: -34, desc: 'ABI·컴파일러·시뮬레이터 지원 범위 불일치 발생' },
    { time: 4000, xStr: 7, yStr: 9, xAng: 48, yAng: -30, desc: '확장 조합 증가: 호환성 검증 비용과 충돌 지점 확대' },
    { time: 5250, xStr: 8, yStr: 10, xAng: 54, yAng: -26, desc: '파편화 정점: 툴체인/시뮬레이터 호환성 난립' },
    { time: 6500, xStr: 8, yStr: 10, xAng: 56, yAng: -24, desc: '문제 정의 완료 → 표준화·검증 기반 Transition 시작' },
];

const RISCV_STAGE2_PHASES = [
    { time: 0,    xStr: 3, yStr: 3, xAng: -24, yAng: 24, desc: 'Transition: 모듈화 레이어와 표준 확장 경계 정의' },
    { time: 1250, xStr: 5, yStr: 5, xAng: -30, yAng: 30, desc: 'riscv-config.toml 메타데이터로 ISA 조합·버전 선언' },
    { time: 2500, xStr: 7, yStr: 7, xAng: -38, yAng: 36, desc: '확장 의존성·호환 규칙을 기계적으로 표현' },
    { time: 4000, xStr: 8, yStr: 8, xAng: -46, yAng: 32, desc: 'riscv-verify 파이프라인: ISA·ABI·툴체인 조합 자동 검증' },
    { time: 5250, xStr: 9, yStr: 9, xAng: -52, yAng: 28, desc: 'RVX_vendor_id 기반 Vendor Plug-in ABI 격리' },
    { time: 6500, xStr: 9, yStr: 10, xAng: -56, yAng: 24, desc: 'COMPATIBILITY 100%: 표준 모듈 + 자동 검증 + 플러그인 격리 완료' },
];

const HABERMAS_STAGE1_PHASES = [
    { time: 0,    xStr: 3, yStr: 3, xAng: 25,  yAng: -20,  desc: 'Debattenbeginn: Theorie der Gesellschaft oder Sozialtechnologie? (1971)' },
    { time: 1250, xStr: 5, yStr: 4, xAng: 32,  yAng: -25,  desc: 'Habermas: Lebenswelt als Fundament sozialer Ordnung' },
    { time: 2500, xStr: 6, yStr: 3, xAng: 40,  yAng: -22,  desc: 'Kommunikative Rationalität: Konsens durch Verständigung' },
    { time: 4000, xStr: 7, yStr: 4, xAng: 48,  yAng: -25,  desc: 'Kolonisierung der Lebenswelt durch System (Geld & Macht)' },
    { time: 5250, xStr: 8, yStr: 3, xAng: 52,  yAng: -20,  desc: 'Demokratische Legitimation durch rationale Diskurse' },
    { time: 6500, xStr: 7, yStr: 3, xAng: 50,  yAng: -20,  desc: 'THESE DOMINIERT: Normative Theorie setzt sich durch — Habermas' },
];

const HABERMAS_STAGE2_PHASES = [
    { time: 0,    xStr: 3, yStr: 3, xAng: -22, yAng: 22,   desc: 'Luhmanns Antwort: Gesellschaft als System, nicht als Subjekt' },
    { time: 1250, xStr: 4, yStr: 5, xAng: -28, yAng: 30,   desc: 'Autopoiesis: Selbstreferentielle Subsysteme (Recht, Wissenschaft, Wirtschaft)' },
    { time: 2500, xStr: 3, yStr: 6, xAng: -25, yAng: 38,   desc: 'Binäre Codes: Recht/Unrecht, wahr/unwahr, Zahlung/Nicht-Zahlung' },
    { time: 4000, xStr: 3, yStr: 7, xAng: -22, yAng: 45,   desc: 'Funktionale Differenzierung: Moderne als irreversibler Prozess' },
    { time: 5250, xStr: 3, yStr: 8, xAng: -20, yAng: 48,   desc: 'Komplexität ist unvermeidbar — Systeme managen sie' },
    { time: 6500, xStr: 3, yStr: 7, xAng: -18, yAng: 52,   desc: 'ANTITHESE DOMINIERT: Systemtheorie gewinnt die Debatte — Luhmann' },
];

// ============================================================
// MAIN VISUALIZATION CLASS
// ============================================================
class LawGraphVisualization {
    constructor() {
        this.canvas = document.getElementById('battleCanvas');
        if (!this.canvas) throw new Error('Canvas not found');
        this.ctx = this.canvas.getContext('2d');
        if (!this.ctx) throw new Error('Could not get 2D context');

        this.dim = { w: 0, h: 0, cx: 0, cy: 0, originX: 0, originY: 0 };

        this.state = {
            stage: 'preview',
            isPlaying: false,
            currentTime: 0,
            lastTimestamp: 0,
            animFrameId: null,
        };

        // ⭐ DEFAULT: 채권자대위권 Stage 2 final (피고들 승) — Y(Mixed) 길이 2배
        this.xGraph = { strength: 7, angle: 52, color: CONFIG.COLORS.BLUE, label: 'X' };
        this.yGraph = { strength: 12, angle: -18, color: CONFIG.COLORS.PINK, label: 'Y' };

        this.currentCaseType = 'creditorSubrogation'; // ⭐ DEFAULT changed
        this.currentCase = CASE_DATA.creditorSubrogation.stage2;
        this.currentPhases = CREDITOR_STAGE2_PHASES;
        this.stage1Phases = CREDITOR_STAGE1_PHASES;
        this.stage2Phases = CREDITOR_STAGE2_PHASES;
        this.winnerSide = 'y';       // Y(Blue/피고들) wins in preview
        this.showGroundTruth = true;
        this.balloons = [];
        this.xGraphEnd = null;
        this.yGraphEnd = null;

        this.init();
    }

    init() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        this.setupControls();
        this.canvas.addEventListener('mousemove', (e) => this.onMouseMove(e));
        this.canvas.addEventListener('click', (e) => this.onClick(e));

        const caseSelector = document.getElementById('caseSelector');
        if (caseSelector) {
            caseSelector.value = this.currentCaseType;
        }

        this.setStageUI('preview');
        this.updateBalloonsForPreview();
        this.draw();
        console.log('✅ LawG v1.33 채권자대위권(surrogation) v2 initialized (Default: 채권자대위권(surrogation), Speed: 2x)');
    }

    resizeCanvas() {
        const rect = this.canvas.getBoundingClientRect();
        const dpr = window.devicePixelRatio || 1;
        this.canvas.width = rect.width * dpr;
        this.canvas.height = rect.height * dpr;
        this.ctx.scale(dpr, dpr);
        this.dim.w = rect.width;
        this.dim.h = rect.height;
        this.dim.originX = rect.width * 0.38;
        this.dim.originY = rect.height * 0.50;
        this.dim.cx = rect.width / 2;
        this.dim.cy = rect.height / 2;
        if (!this.state.isPlaying) {
            if (this.state.stage === 'preview') this.updateBalloonsForPreview();
            this.draw();
        }
    }

    setupControls() {
        const playBtn = document.getElementById('playBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        const resetBtn = document.getElementById('resetBtn');
        const closeBtn = document.getElementById('closeModalBtn');
        const caseSelector = document.getElementById('caseSelector');

        if (playBtn) playBtn.addEventListener('click', () => this.play());
        if (pauseBtn) pauseBtn.addEventListener('click', () => this.pause());
        if (resetBtn) resetBtn.addEventListener('click', () => this.reset());
        if (closeBtn) closeBtn.addEventListener('click', () => this.closeModal());
        if (caseSelector) caseSelector.addEventListener('change', (e) => this.switchCase(e.target.value));

        const modal = document.getElementById('detailModal');
        if (modal) modal.addEventListener('click', (e) => { if (e.target === modal) this.closeModal(); });
    }

    // ======================== PREVIEW STATE ========================
    updateBalloonsForPreview() {
        this.balloons = [];
        const ox = this.dim.originX, oy = this.dim.originY;

        if (this.currentCaseType === 'roeVsDobbs') {
            const cd = CASE_DATA.dobbsVJackson;
            this.balloons.push({
                x: ox - 80, y: oy - 140,
                type: 'majority', title: cd.majority.label,
                lines: cd.majority.arguments.slice(0, 2), isMajority: true,
            });
            this.balloons.push({
                x: ox - 160, y: oy - 40,
                type: 'majority', title: 'Key Argument',
                lines: cd.majority.arguments.slice(2, 4), isMajority: true,
            });
            this.balloons.push({
                x: ox + 200, y: oy + 120,
                type: 'dissent', title: cd.dissent.label,
                lines: cd.dissent.arguments.slice(0, 2), isMajority: false,
            });
            this.balloons.push({
                x: ox + 120, y: oy + 200,
                type: 'dissent', title: 'Rebuttal',
                lines: cd.dissent.arguments.slice(2, 3), isMajority: false,
            });
        } else if (this.currentCaseType === 'creditorSubrogation') {
            const cd = CASE_DATA.creditorSubrogation.stage2;
            this.balloons.push({
                x: ox - 80, y: oy - 100,
                type: 'plaintiff', title: cd.plaintiff.label,
                lines: cd.plaintiff.arguments.slice(0, 2), isMajority: false,
            });
            this.balloons.push({
                x: ox + 180, y: oy + 140,
                type: 'defendant', title: cd.defendant.label,
                lines: cd.defendant.arguments.slice(0, 2), isMajority: true,
            });
            this.balloons.push({
                x: ox + 100, y: oy + 220,
                type: 'defendant', title: '법리 판단',
                lines: cd.defendant.arguments.slice(2, 4), isMajority: true,
            });
        } else if (this.currentCaseType === 'riscVFragmentation') {
            const cd = CASE_DATA.riscVFragmentation.stage2;
            this.balloons.push({ x: ox - 80, y: oy - 105, type: 'plaintiff', title: cd.plaintiff.label, lines: cd.plaintiff.arguments.slice(0, 2), isMajority: false });
            this.balloons.push({ x: ox + 180, y: oy + 125, type: 'defendant', title: cd.defendant.label, lines: cd.defendant.arguments.slice(0, 2), isMajority: true });
            this.balloons.push({ x: ox + 80, y: oy + 215, type: 'vendor', title: cd.vendorPlugin.label, lines: cd.vendorPlugin.arguments.slice(0, 2), isMajority: true, isVendor: true });
        } else if (this.currentCaseType === 'habermasLuhmann') {
            const cd = CASE_DATA.habermasLuhmann.stage2;
            this.balloons.push({
                x: ox - 80, y: oy - 100,
                type: 'plaintiff', title: cd.plaintiff.label,
                lines: cd.plaintiff.arguments.slice(0, 2), isMajority: false,
            });
            this.balloons.push({
                x: ox + 180, y: oy + 140,
                type: 'defendant', title: cd.defendant.label,
                lines: cd.defendant.arguments.slice(0, 2), isMajority: true,
            });
            this.balloons.push({
                x: ox + 100, y: oy + 220,
                type: 'defendant', title: 'Kernargument',
                lines: cd.defendant.arguments.slice(2, 4), isMajority: true,
            });
        }
    }

    // ======================== PLAYBACK ========================
    play() {
        if (this.state.isPlaying) return;

        if (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 0) {
            this.state.stage = 1;
            this.state.currentTime = 0;
            this.winnerSide = null;
            this.showGroundTruth = false;
            this.balloons = [];
            this.xGraphEnd = null;
            this.yGraphEnd = null;

            if (this.currentCaseType === 'roeVsDobbs') {
                this.currentCase = CASE_DATA.roeVWade;
                this.currentPhases = this.stage1Phases;
                this.xGraph = { strength: 3, angle: 25, color: CONFIG.COLORS.BLUE, label: 'X' };
                this.yGraph = { strength: 3, angle: -20, color: CONFIG.COLORS.PINK, label: 'Y' };
            } else if (this.currentCaseType === 'creditorSubrogation') {
                this.currentCase = CASE_DATA.creditorSubrogation.stage1;
                this.currentPhases = this.stage1Phases;
                this.xGraph = { strength: 3, angle: 25, color: CONFIG.COLORS.BLUE, label: 'X' };
                this.yGraph = { strength: 3, angle: -20, color: CONFIG.COLORS.PINK, label: 'Y' };
            } else if (this.currentCaseType === 'riscVFragmentation') {
                this.currentCase = CASE_DATA.riscVFragmentation.stage1;
                this.currentPhases = this.stage1Phases;
                this.xGraph = { strength: 3, angle: 24, color: CONFIG.COLORS.BLUE, label: 'X' };
                this.yGraph = { strength: 4, angle: -22, color: CONFIG.COLORS.PINK, label: 'Y' };
            } else if (this.currentCaseType === 'habermasLuhmann') {
                this.currentCase = CASE_DATA.habermasLuhmann.stage1;
                this.currentPhases = this.stage1Phases;
                this.xGraph = { strength: 3, angle: 25, color: CONFIG.COLORS.BLUE, label: 'X' };
                this.yGraph = { strength: 3, angle: -20, color: CONFIG.COLORS.PINK, label: 'Y' };
            }
            
            this.setStageUI(1);
        }

        this.state.isPlaying = true;
        this.state.lastTimestamp = performance.now();
        this.updateButtons(true);
        this.animate();
    }

    pause() {
        this.state.isPlaying = false;
        this.updateButtons(false);
        if (this.state.animFrameId) {
            cancelAnimationFrame(this.state.animFrameId);
            this.state.animFrameId = null;
        }
    }

    reset() {
        this.pause();
        this.state.stage = 'preview';
        this.state.currentTime = 0;
        this.xGraphEnd = null;
        this.yGraphEnd = null;
        
        if (this.currentCaseType === 'roeVsDobbs') {
            this.currentCase = CASE_DATA.dobbsVJackson;
            this.currentPhases = STAGE2_PHASES;
            this.stage1Phases = STAGE1_PHASES;
            this.stage2Phases = STAGE2_PHASES;
            this.winnerSide = 'x';
            this.showGroundTruth = true;
            this.xGraph = { strength: 10, angle: -55, color: CONFIG.COLORS.PINK, label: 'X' };
            this.yGraph = { strength: 4, angle: 22, color: CONFIG.COLORS.BLUE, label: 'Y' };
        } else if (this.currentCaseType === 'creditorSubrogation') {
            this.currentCase = CASE_DATA.creditorSubrogation.stage2;
            this.currentPhases = CREDITOR_STAGE2_PHASES;
            this.stage1Phases = CREDITOR_STAGE1_PHASES;
            this.stage2Phases = CREDITOR_STAGE2_PHASES;
            this.winnerSide = 'y';
            this.showGroundTruth = true;
            this.xGraph = { strength: 7, angle: 52, color: CONFIG.COLORS.BLUE, label: 'X' };
            this.yGraph = { strength: 12, angle: -18, color: CONFIG.COLORS.PINK, label: 'Y' };
            this.state.currentTime = CONFIG.STAGE2_DURATION; // Ensure preview shows final completed state
        } else if (this.currentCaseType === 'riscVFragmentation') {
            this.currentCase = CASE_DATA.riscVFragmentation.stage2;
            this.currentPhases = RISCV_STAGE2_PHASES;
            this.stage1Phases = RISCV_STAGE1_PHASES;
            this.stage2Phases = RISCV_STAGE2_PHASES;
            this.winnerSide = 'y';
            this.showGroundTruth = true;
            this.xGraph = { strength: 9, angle: -56, color: CONFIG.COLORS.PINK, label: 'X' };
            this.yGraph = { strength: 10, angle: 24, color: CONFIG.COLORS.BLUE, label: 'Y' };
        } else if (this.currentCaseType === 'habermasLuhmann') {
            this.currentCase = CASE_DATA.habermasLuhmann.stage2;
            this.currentPhases = HABERMAS_STAGE2_PHASES;
            this.stage1Phases = HABERMAS_STAGE1_PHASES;
            this.stage2Phases = HABERMAS_STAGE2_PHASES;
            this.winnerSide = 'y';
            this.showGroundTruth = true;
            this.xGraph = { strength: 3, angle: -18, color: CONFIG.COLORS.PINK, label: 'X' };
            this.yGraph = { strength: 7, angle: 52, color: CONFIG.COLORS.BLUE, label: 'Y' };
        }
        
        this.setStageUI('preview');
        this.updateButtons(false);
        const playBtn = document.getElementById('playBtn');
        if (playBtn) playBtn.disabled = false;
        this.updateBalloonsForPreview();
        this.draw();
    }

    switchCase(caseType) {
        this.pause();
        this.currentCaseType = caseType;
        this.reset();
        
        const roeInfo = document.getElementById('roeInfo');
        const dobbsInfo = document.getElementById('dobbsInfo');
        const creditorStage1Info = document.getElementById('creditorStage1Info');
        const creditorStage2Info = document.getElementById('creditorStage2Info');
        const habermasStage1Info = document.getElementById('habermasStage1Info');
        const habermasStage2Info = document.getElementById('habermasStage2Info');
        const riscvStage1Info = document.getElementById('riscvStage1Info');
        const riscvStage2Info = document.getElementById('riscvStage2Info');
        const referencesList = document.getElementById('referencesList');
        const howToEN = document.getElementById('howToEN');
        const howToKR = document.getElementById('howToKR');
        const howToDE = document.getElementById('howToDE');
        
        [roeInfo, dobbsInfo, creditorStage1Info, creditorStage2Info, habermasStage1Info, habermasStage2Info, riscvStage1Info, riscvStage2Info, howToEN, howToKR, howToDE].forEach(el => {
            if (el) el.style.display = 'none';
        });
        
        if (caseType === 'roeVsDobbs') {
            if (roeInfo) roeInfo.style.display = 'block';
            if (dobbsInfo) dobbsInfo.style.display = 'block';
            if (howToEN) howToEN.style.display = 'block';
            if (referencesList) {
                referencesList.innerHTML = `
                    <li><a href="https://www.oyez.org/cases/1971/70-18" target="_blank">Roe v. Wade — Oyez.org</a></li>
                    <li><a href="https://www.oyez.org/cases/2021/19-1392" target="_blank">Dobbs v. Jackson — Oyez.org</a></li>`;
            }
        } else if (caseType === 'creditorSubrogation') {
            if (creditorStage1Info) creditorStage1Info.style.display = 'block';
            if (creditorStage2Info) creditorStage2Info.style.display = 'block';
            if (howToKR) howToKR.style.display = 'block';
            if (referencesList) {
                referencesList.innerHTML = `
                    <li><a href="https://www.scourt.go.kr/" target="_blank">대법원 판례 — 2017다228618</a></li>
                    <li>채권자대위권(surrogation)의 피보전권리 존부 판단 기준</li>`;
            }
        } else if (caseType === 'riscVFragmentation') {
            if (riscvStage1Info) riscvStage1Info.style.display = 'block';
            if (riscvStage2Info) riscvStage2Info.style.display = 'block';
            if (howToKR) howToKR.style.display = 'block';
            if (referencesList) {
                referencesList.innerHTML = `
                    <li><a href="https://riscv.org/specifications/" target="_blank" rel="noopener">RISC-V Specifications</a></li>
                    <li>시각화 설계 기준: LawG_RISC-V_Implementation_Plan.md</li>`;
            }
        } else if (caseType === 'habermasLuhmann') {
            if (habermasStage1Info) habermasStage1Info.style.display = 'block';
            if (habermasStage2Info) habermasStage2Info.style.display = 'block';
            if (howToDE) howToDE.style.display = 'block';
            if (referencesList) {
                referencesList.innerHTML = `
                    <li><a href="https://www.lernhelfer.de/schuelerlexikon/politikwirtschaft/artikel/die-habermas-luhmann-kontroverse-theorie-der-gesellschaft" target="_blank">Die Habermas-Luhmann-Kontroverse — Lernhelfer.de</a></li>
                    <li>Theorie der Gesellschaft oder Sozialtechnologie? (1971)</li>`;
            }
        }
        
        console.log(`✅ Switched to case: ${caseType}`);
    }

    updateButtons(playing) {
        const playBtn = document.getElementById('playBtn');
        const pauseBtn = document.getElementById('pauseBtn');
        if (playBtn) playBtn.disabled = playing;
        if (pauseBtn) pauseBtn.disabled = !playing;
    }

    setStageUI(stage) {
        const titleEl = document.getElementById('caseTitle');
        const subEl = document.getElementById('caseSubtitle');
        const infoEl = document.getElementById('caseInfo');
        const dot1 = document.getElementById('stage1Dot');
        const dot2 = document.getElementById('stage2Dot');
        const stageText1 = document.getElementById('stageText1');
        const stageText2 = document.getElementById('stageText2');

        if (this.currentCaseType === 'roeVsDobbs') {
            if (stage === 1) {
                if (titleEl) titleEl.textContent = '⚖️ Roe v. Wade (1973)';
                if (subEl) subEl.textContent = 'Legal Battle Timeline Visualization';
                if (infoEl) infoEl.textContent = 'Supreme Court Decision: 7-2 Majority Opinion';
                if (dot1) dot1.classList.add('active');
                if (dot2) dot2.classList.remove('active');
            } else {
                if (titleEl) titleEl.textContent = '⚖️ Dobbs v. Jackson (2022)';
                if (subEl) subEl.textContent = 'Overruling Roe v. Wade';
                if (infoEl) infoEl.textContent = 'Supreme Court Decision: 6-3 — Roe Overruled';
                if (dot1) dot1.classList.remove('active');
                if (dot2) dot2.classList.add('active');
            }
            if (stageText1) stageText1.textContent = 'Stage 1: Roe v. Wade';
            if (stageText2) stageText2.textContent = 'Stage 2: Dobbs v. Jackson';
        } else if (this.currentCaseType === 'creditorSubrogation') {
            if (stage === 1) {
                if (titleEl) titleEl.textContent = '채권자대위권(surrogation) - 조정(기판력 : Res Judicata)성립 단계';
                if (subEl) subEl.textContent = '원고 vs 甲 등 - 재판상 조정(기판력 : Res Judicata)';
                if (infoEl) infoEl.textContent = '조정(기판력 : Res Judicata) 성립: 원고(채권자) 승';
                if (dot1) dot1.classList.add('active');
                if (dot2) dot2.classList.remove('active');
            } else {
                if (titleEl) titleEl.textContent = '채권자대위권(surrogation) (2017다228618)';
                if (subEl) subEl.textContent = '피보전권리의 존부 판단';
                if (infoEl) infoEl.textContent = '대법원 판결: 파기자판(각하) — 피고들 승';
                if (dot1) dot1.classList.remove('active');
                if (dot2) dot2.classList.add('active');
            }
            if (stageText1) stageText1.textContent = 'Stage 1: 조정(기판력 : Res Judicata)성립';
            if (stageText2) stageText2.textContent = 'Stage 2: 대위소송';
        } else if (this.currentCaseType === 'riscVFragmentation') {
            if (stage === 1) {
                if (titleEl) titleEl.textContent = '🧩 RISC-V ISA Fragmentation';
                if (subEl) subEl.textContent = '표준 Base ISA vs 비표준 Custom Extensions';
                if (infoEl) infoEl.textContent = 'Stage 1: 툴체인·시뮬레이터 호환성 충돌';
                if (dot1) dot1.classList.add('active');
                if (dot2) dot2.classList.remove('active');
            } else {
                if (titleEl) titleEl.textContent = '🧩 RISC-V Modular ISA + Automated Verification';
                if (subEl) subEl.textContent = '표준 모듈화 + riscv-config.toml + Vendor Plug-in ABI';
                if (infoEl) infoEl.textContent = 'Stage 2: 호환성 100% 검증 완료';
                if (dot1) dot1.classList.remove('active');
                if (dot2) dot2.classList.add('active');
            }
            if (stageText1) stageText1.textContent = 'Stage 1: ISA Fragmentation';
            if (stageText2) stageText2.textContent = 'Stage 2: Modular ISA + Verification';
        } else if (this.currentCaseType === 'habermasLuhmann') {
            if (stage === 1) {
                if (titleEl) titleEl.textContent = '📚 Habermas — These: Normative Theorie (~1971)';
                if (subEl) subEl.textContent = 'Kommunikative Rationalität & Lebenswelt';
                if (infoEl) infoEl.textContent = 'Akademische Debatte: Habermas\' These dominiert';
                if (dot1) dot1.classList.add('active');
                if (dot2) dot2.classList.remove('active');
            } else {
                if (titleEl) titleEl.textContent = '📚 Luhmann — Antithese: Systemtheorie';
                if (subEl) subEl.textContent = 'Autopoiesis & funktionale Differenzierung';
                if (infoEl) infoEl.textContent = 'Akademische Debatte: Luhmanns Antithese setzt sich durch';
                if (dot1) dot1.classList.remove('active');
                if (dot2) dot2.classList.add('active');
            }
            if (stageText1) stageText1.textContent = 'These: Habermas';
            if (stageText2) stageText2.textContent = 'Antithese: Luhmann';
        }
    }

    // ======================== ANIMATION LOOP ========================
    animate(timestamp) {
        if (!this.state.isPlaying) return;
        if (!timestamp) timestamp = performance.now();

        const dt = timestamp - this.state.lastTimestamp;
        this.state.lastTimestamp = timestamp;
        this.state.currentTime += dt;

        if (this.state.stage === 1) {
            if (this.currentCaseType === 'roeVsDobbs') { this.currentCase = CASE_DATA.roeVWade; }
            else if (this.currentCaseType === 'creditorSubrogation') { this.currentCase = CASE_DATA.creditorSubrogation.stage1; }
            else if (this.currentCaseType === 'riscVFragmentation') { this.currentCase = CASE_DATA.riscVFragmentation.stage1; }
            else if (this.currentCaseType === 'habermasLuhmann') { this.currentCase = CASE_DATA.habermasLuhmann.stage1; }
            this.currentPhases = this.stage1Phases;
            this.xGraph.color = CONFIG.COLORS.BLUE;
            this.yGraph.color = CONFIG.COLORS.PINK;

            if (this.state.currentTime >= CONFIG.STAGE1_DURATION) {
                this.state.currentTime = CONFIG.STAGE1_DURATION;
                this.winnerSide = 'x';
                this.showGroundTruth = true;
                this.interpolatePhases(this.stage1Phases, CONFIG.STAGE1_DURATION);
                this.state.stage = 2;
                this.state.currentTime = 0;
            } else {
                this.interpolatePhases(this.stage1Phases, this.state.currentTime);
                const prog = this.state.currentTime / CONFIG.STAGE1_DURATION;
                this.winnerSide = prog > 0.85 ? 'x' : null;
                this.showGroundTruth = prog > 0.9;
            }
        } else if (this.state.stage === 2) {
            const t = Ease.clamp01(this.state.currentTime / CONFIG.TRANSITION_DURATION);
            const et = Ease.inOutCubic(t);
            const s1Final = this.stage1Phases[this.stage1Phases.length - 1];
            const s2Start = this.stage2Phases[0];
            if (this.currentCaseType === 'creditorSubrogation') {
                this.xGraph.color = CONFIG.COLORS.BLUE;
                this.yGraph.color = CONFIG.COLORS.PINK;
            } else {
                this.xGraph.color = this.lerpColor(CONFIG.COLORS.BLUE, CONFIG.COLORS.PINK, et);
                this.yGraph.color = this.lerpColor(CONFIG.COLORS.PINK, CONFIG.COLORS.BLUE, et);
            }
            this.xGraph.strength = Ease.lerp(s1Final.xStr, s2Start.xStr, et);
            this.xGraph.angle = Ease.lerp(s1Final.xAng, s2Start.xAng, et);
            this.yGraph.strength = Ease.lerp(s1Final.yStr, s2Start.yStr, et);
            this.yGraph.angle = Ease.lerp(s1Final.yAng, s2Start.yAng, et);
            this.winnerSide = et < 0.5 ? 'x' : null;
            this.showGroundTruth = et < 0.3;

            if (this.state.currentTime >= CONFIG.TRANSITION_DURATION) {
                this.state.stage = 3;
                this.state.currentTime = 0;
                this.winnerSide = null;
                this.showGroundTruth = false;
                this.balloons = [];
                this.xGraph.color = CONFIG.COLORS.PINK;
                this.yGraph.color = CONFIG.COLORS.BLUE;
                if (this.currentCaseType === 'roeVsDobbs') { this.currentCase = CASE_DATA.dobbsVJackson; }
                else if (this.currentCaseType === 'creditorSubrogation') { this.currentCase = CASE_DATA.creditorSubrogation.stage2; }
                else if (this.currentCaseType === 'riscVFragmentation') { this.currentCase = CASE_DATA.riscVFragmentation.stage2; }
                else if (this.currentCaseType === 'habermasLuhmann') { this.currentCase = CASE_DATA.habermasLuhmann.stage2; }
                this.currentPhases = this.stage2Phases;
                this.xGraph.strength = this.stage2Phases[0].xStr;
                this.xGraph.angle = this.stage2Phases[0].xAng;
                this.yGraph.strength = this.stage2Phases[0].yStr;
                this.yGraph.angle = this.stage2Phases[0].yAng;
                this.setStageUI(3);
            }
        } else if (this.state.stage === 3) {
            if (this.currentCaseType === 'roeVsDobbs') { this.currentCase = CASE_DATA.dobbsVJackson; }
            else if (this.currentCaseType === 'creditorSubrogation') { this.currentCase = CASE_DATA.creditorSubrogation.stage2; }
            else if (this.currentCaseType === 'riscVFragmentation') { this.currentCase = CASE_DATA.riscVFragmentation.stage2; }
            else if (this.currentCaseType === 'habermasLuhmann') { this.currentCase = CASE_DATA.habermasLuhmann.stage2; }
            this.currentPhases = this.stage2Phases;
            if (this.currentCaseType === 'creditorSubrogation') {
                this.xGraph.color = CONFIG.COLORS.BLUE;
                this.yGraph.color = CONFIG.COLORS.PINK;
            } else {
                this.xGraph.color = CONFIG.COLORS.PINK;
                this.yGraph.color = CONFIG.COLORS.BLUE;
            }

            if (this.state.currentTime >= CONFIG.STAGE2_DURATION) {
                this.state.currentTime = CONFIG.STAGE2_DURATION;
                this.interpolatePhases(this.stage2Phases, CONFIG.STAGE2_DURATION);
                if (this.currentCaseType === 'roeVsDobbs') { this.winnerSide = 'x'; }
                else { this.winnerSide = 'y'; }
                this.showGroundTruth = true;
                this.state.stage = 'done';
                this.pause();
                const playBtn = document.getElementById('playBtn');
                if (playBtn) playBtn.disabled = true;
            } else {
                this.interpolatePhases(this.stage2Phases, this.state.currentTime);
                const prog = this.state.currentTime / CONFIG.STAGE2_DURATION;
                if (this.currentCaseType === 'roeVsDobbs') { this.winnerSide = prog > 0.85 ? 'x' : null; }
                else { this.winnerSide = prog > 0.85 ? 'y' : null; }
                this.showGroundTruth = prog > 0.9;
            }
        }

        this.updateBalloons();
        this.draw();

        if (this.state.isPlaying) {
            this.state.animFrameId = requestAnimationFrame((t) => this.animate(t));
        }
    }

    interpolatePhases(phases, time) {
        let cur = phases[0], nxt = phases[1] || phases[0];
        for (let i = 0; i < phases.length - 1; i++) {
            if (time >= phases[i].time && time < phases[i + 1].time) { cur = phases[i]; nxt = phases[i + 1]; break; }
        }
        if (time >= phases[phases.length - 1].time) { cur = nxt = phases[phases.length - 1]; }
        const dur = nxt.time - cur.time;
        const t = dur > 0 ? Ease.clamp01((time - cur.time) / dur) : 1;
        const e = Ease.inOutCubic(t);
        this.xGraph.strength = Ease.lerp(cur.xStr, nxt.xStr, e);
        this.xGraph.angle = Ease.lerp(cur.xAng, nxt.xAng, e);
        this.yGraph.strength = Ease.lerp(cur.yStr, nxt.yStr, e);
        this.yGraph.angle = Ease.lerp(cur.yAng, nxt.yAng, e);
    }

    // ======================== DRAWING ========================
    draw() {
        const ctx = this.ctx;
        ctx.clearRect(0, 0, this.dim.w, this.dim.h);
        this.drawGrid();
        this.drawAxes();
        this.drawCrossingGraphs();
        // Gray Z (채무자) — 채권자대위권 Stage 2 전용
        if (this.currentCaseType === 'creditorSubrogation') {
            const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
            if (isStage2) this.drawGrayDebtor();
        } else if (this.currentCaseType === 'riscVFragmentation') {
            const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
            if (isStage2) this.drawGrayVendorPlugin();
        }
        this.drawArc();
        this.drawBalloons();
        this.drawLegend();
        this.drawProgressBar();
        this.drawPhaseDescription();
        if (this.showGroundTruth) this.drawGroundTruth();
        // 소각하 표시 — 채권자대위권 Stage 2 최종
        if (this.currentCaseType === 'creditorSubrogation' && this.showGroundTruth && this.winnerSide === 'y') {
            this.drawDismissalBadge();
        }
        if (this.currentCaseType === 'riscVFragmentation' && this.showGroundTruth && this.winnerSide === 'y') {
            this.drawRiscVCompatibilityBadge();
        }
        if (this.state.stage === 'preview') this.drawPreviewBadge();
    }

    drawPreviewBadge() {
        const ctx = this.ctx;
        let text = '▶ Press Play to animate';
        if (this.currentCaseType === 'roeVsDobbs') { text = '▶ Press Play to animate: Stage 1 (Roe) → Stage 2 (Dobbs)'; }
        else if (this.currentCaseType === 'creditorSubrogation') { text = '▶ Play 버튼을 눌러 애니메이션 시작: 1단계(조정성립) → 2단계(대위소송)'; }
        else if (this.currentCaseType === 'riscVFragmentation') { text = '▶ Play: Fragmentation → Modular ISA → Automated Verification'; }
        else if (this.currentCaseType === 'habermasLuhmann') { text = '▶ Play drücken: These (Habermas) → Antithese (Luhmann)'; }
        const bw = (this.currentCaseType === 'creditorSubrogation') ? 480 : (this.currentCaseType === 'riscVFragmentation') ? 500 : (this.currentCaseType === 'habermasLuhmann') ? 420 : 380;
        const bh = 32;
        const bx = (this.dim.w - bw) / 2, by = this.dim.h - 55;
        ctx.fillStyle = 'rgba(37, 99, 235, 0.9)';
        this.roundRect(ctx, bx, by, bw, bh, 16); ctx.fill();
        ctx.fillStyle = '#fff';
        ctx.font = '600 13px Inter, Arial';
        ctx.textAlign = 'center';
        ctx.fillText(text, this.dim.w / 2, by + 21);
    }

    drawGrid() {
        const ctx = this.ctx;
        ctx.strokeStyle = CONFIG.COLORS.GRID_LINE;
        ctx.lineWidth = 0.5;
        for (let x = 0; x < this.dim.w; x += CONFIG.GRID.SPACING) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.dim.h); ctx.stroke(); }
        for (let y = 0; y < this.dim.h; y += CONFIG.GRID.SPACING) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.dim.w, y); ctx.stroke(); }
    }

    drawAxes() {
        const ctx = this.ctx;
        const ox = this.dim.originX, oy = this.dim.originY;
        ctx.strokeStyle = CONFIG.COLORS.GRID_AXIS; ctx.lineWidth = 1.2; ctx.setLineDash([6, 4]);
        ctx.beginPath(); ctx.moveTo(ox, 25); ctx.lineTo(ox, this.dim.h - 25); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(25, oy); ctx.lineTo(this.dim.w - 25, oy); ctx.stroke();
        ctx.setLineDash([]);
        this.drawAxisArrow(ctx, ox, 25, 'up');
        this.drawAxisArrow(ctx, this.dim.w - 25, oy, 'right');

        const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
        if (isStage2) {
            ctx.fillStyle = this.xGraph.color; ctx.font = 'bold 13px Inter, Arial'; ctx.textAlign = 'left';
            ctx.fillText(this.currentCaseType === 'creditorSubrogation' ? 'X (원고 대위)' : this.currentCaseType === 'habermasLuhmann' ? 'X (Habermas)' : 'X (Π = Plaintiff)', ox + 10, 20);
        } else {
            ctx.fillStyle = this.yGraph.color; ctx.font = 'bold 13px Inter, Arial'; ctx.textAlign = 'left';
            ctx.fillText(this.currentCaseType === 'creditorSubrogation' ? 'Y (채무자)' : this.currentCaseType === 'habermasLuhmann' ? 'Y (Luhmann)' : 'Y (Δ = Defendant)', ox + 10, 20);
        }

        ctx.save(); ctx.fillStyle = '#777'; ctx.font = 'italic 11px Inter, Arial';
        ctx.translate(ox - 20, this.dim.h * 0.28); ctx.rotate(-Math.PI / 2); ctx.textAlign = 'center';
        ctx.fillText(this.currentCaseType === 'creditorSubrogation' ? '귀무가설 (H₀)' : this.currentCaseType === 'habermasLuhmann' ? 'These (H₀)' : 'Null Hypothesis (H₀)', 0, 0);
        ctx.restore();

        if (isStage2) {
            ctx.fillStyle = this.yGraph.color; ctx.font = 'bold 13px Inter, Arial'; ctx.textAlign = 'right';
            ctx.fillText(this.currentCaseType === 'creditorSubrogation' ? 'Y (제3채무자)' : this.currentCaseType === 'habermasLuhmann' ? 'Y (Luhmann)' : 'Y (Δ = Defendant)', this.dim.w - 30, oy - 10);
        } else {
            ctx.fillStyle = this.xGraph.color; ctx.font = 'bold 13px Inter, Arial'; ctx.textAlign = 'right';
            ctx.fillText(this.currentCaseType === 'creditorSubrogation' ? 'X (원고/채권자)' : this.currentCaseType === 'habermasLuhmann' ? 'X (Habermas)' : 'X (Π = Plaintiff)', this.dim.w - 30, oy - 10);
        }

        ctx.fillStyle = '#777'; ctx.font = 'italic 11px Inter, Arial'; ctx.textAlign = 'right';
        ctx.fillText(this.currentCaseType === 'creditorSubrogation' ? '대립가설 (H₁)' : this.currentCaseType === 'habermasLuhmann' ? 'Antithese (H₁)' : 'Alternative Hypothesis (H₁)', this.dim.w - 30, oy + 18);

        ctx.fillStyle = '#aaa'; ctx.font = '10px Inter, Arial'; ctx.textAlign = 'right';
        ctx.fillText('ratio', ox - 6, oy - 10);

        ctx.fillStyle = CONFIG.COLORS.BATTLE_POINT; ctx.beginPath();
        ctx.arc(ox, oy, CONFIG.BATTLE_POINT.RADIUS, 0, Math.PI * 2); ctx.fill();
        const pulse = CONFIG.BATTLE_POINT.RADIUS + Math.sin(Date.now() / CONFIG.BATTLE_POINT.PULSE_SPEED) * CONFIG.BATTLE_POINT.PULSE_AMPLITUDE;
        ctx.strokeStyle = 'rgba(239,68,68,0.35)'; ctx.lineWidth = 2; ctx.beginPath();
        ctx.arc(ox, oy, pulse, 0, Math.PI * 2); ctx.stroke();
    }

    drawAxisArrow(ctx, x, y, dir) {
        ctx.fillStyle = CONFIG.COLORS.GRID_AXIS; ctx.beginPath(); const s = 7;
        if (dir === 'up') { ctx.moveTo(x, y); ctx.lineTo(x - s, y + s * 1.5); ctx.lineTo(x + s, y + s * 1.5); }
        else { ctx.moveTo(x, y); ctx.lineTo(x - s * 1.5, y - s); ctx.lineTo(x - s * 1.5, y + s); }
        ctx.closePath(); ctx.fill();
    }

    drawCrossingGraphs() {
        const ctx = this.ctx;
        const ox = this.dim.originX, oy = this.dim.originY;
        const xAngRad = (this.xGraph.angle * Math.PI) / 180;
        const yAngRad = (this.yGraph.angle * Math.PI) / 180;
        const xJust = this.getJustices('x');
        const yJust = this.getJustices('y');
        const xLen = this.xGraph.strength * CONFIG.GRAPH.SCALE_FACTOR * (xJust / 4.5);
        const yLen = this.yGraph.strength * CONFIG.GRAPH.SCALE_FACTOR * (yJust / 4.5);

        const xSx = ox - Math.cos(xAngRad) * xLen * 0.45;
        const xSy = oy - Math.sin(xAngRad) * xLen * 0.45;
        const xEx = ox + Math.cos(xAngRad) * xLen;
        const xEy = oy + Math.sin(xAngRad) * xLen;
        const ySx = ox - Math.cos(yAngRad) * yLen * 0.4;
        const ySy = oy - Math.sin(yAngRad) * yLen * 0.4;
        const yEx = ox + Math.cos(yAngRad) * yLen;
        const yEy = oy + Math.sin(yAngRad) * yLen;

        this.xGraphEnd = { x: xEx, y: xEy, sx: xSx, sy: xSy };
        this.yGraphEnd = { x: yEx, y: yEy, sx: ySx, sy: ySy };

        ctx.strokeStyle = this.xGraph.color; ctx.lineWidth = CONFIG.GRAPH.LINE_WIDTH; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(xSx, xSy); ctx.lineTo(xEx, xEy); ctx.stroke();
        this.drawArrowHead(ctx, xEx, xEy, xAngRad, this.xGraph.color);

        const isStage2 = (this.state.stage === 3 || this.state.stage === 2 || this.state.stage === 'preview' || this.state.stage === 'done');
        let yColor = this.yGraph.color;
        if (this.currentCaseType === 'creditorSubrogation' && isStage2) {
            const currentYStr = this.yGraph.strength || 0.1;
            const grayStop1 = Math.min(1.0, 3.6 / currentYStr);
            const pinkStop = Math.min(1.0, 8.4 / currentYStr);
            
            const yGrad = ctx.createLinearGradient(ox, oy, yEx, yEy);
            yGrad.addColorStop(0, '#9CA3AF');
            if (grayStop1 < 1.0) {
                yGrad.addColorStop(grayStop1, '#9CA3AF');
                yGrad.addColorStop(grayStop1, CONFIG.COLORS.PINK);
            }
            if (pinkStop < 1.0) {
                yGrad.addColorStop(pinkStop, CONFIG.COLORS.PINK);
                yGrad.addColorStop(pinkStop, '#9CA3AF');
                yGrad.addColorStop(1.0, '#9CA3AF');
            } else if (grayStop1 < 1.0) {
                yGrad.addColorStop(1.0, CONFIG.COLORS.PINK);
            } else {
                yGrad.addColorStop(1.0, '#9CA3AF');
            }
            ctx.strokeStyle = yGrad;
            yColor = pinkStop < 1.0 ? '#9CA3AF' : (grayStop1 < 1.0 ? CONFIG.COLORS.PINK : '#9CA3AF');
        } else {
            ctx.strokeStyle = this.yGraph.color;
        }
        ctx.lineWidth = CONFIG.GRAPH.LINE_WIDTH;
        ctx.beginPath(); ctx.moveTo(ySx, ySy); ctx.lineTo(yEx, yEy); ctx.stroke();
        this.drawArrowHead(ctx, yEx, yEy, yAngRad, yColor);

        ctx.font = 'bold 14px Inter, Arial'; ctx.textAlign = 'left';
        const xLx = xEx + Math.cos(xAngRad) * 16, xLy = xEy + Math.sin(xAngRad) * 16;
        ctx.fillStyle = this.xGraph.color;
        ctx.fillText('X (Π)', xLx, xLy);
        ctx.font = '10px Inter, Arial';
        ctx.fillText(`${xJust} ${this.currentCaseType === 'creditorSubrogation' ? '강도' : 'Justices'} | str: ${this.xGraph.strength.toFixed(1)}`, xLx, xLy + 14);

        const yLx = yEx + Math.cos(yAngRad) * 16, yLy = yEy + Math.sin(yAngRad) * 16;
        ctx.fillStyle = this.yGraph.color; ctx.font = 'bold 14px Inter, Arial';
        ctx.fillText('Y (Δ)', yLx, yLy);
        ctx.font = '10px Inter, Arial';
        ctx.fillText(`${yJust} ${this.currentCaseType === 'creditorSubrogation' ? '강도' : 'Justices'} | str: ${this.yGraph.strength.toFixed(1)}`, yLx, yLy + 14);

        ctx.globalAlpha = 0.4; ctx.font = '9px Inter, Arial'; ctx.textAlign = 'right';
        ctx.fillStyle = this.xGraph.color; ctx.fillText('X₀', xSx - 4, xSy - 2);
        ctx.fillStyle = this.yGraph.color; ctx.fillText('Y₀', ySx - 4, ySy - 2);
        ctx.globalAlpha = 1;
    }

    getJustices(side) {
        const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
        if (this.currentCaseType === 'riscVFragmentation') {
            const sd = isStage2 ? CASE_DATA.riscVFragmentation.stage2 : CASE_DATA.riscVFragmentation.stage1;
            return side === 'x' ? sd.plaintiff.strength : sd.defendant.strength;
        } else if (this.currentCaseType === 'creditorSubrogation') {
            const sd = isStage2 ? CASE_DATA.creditorSubrogation.stage2 : CASE_DATA.creditorSubrogation.stage1;
            return side === 'x' ? sd.plaintiff.strength : sd.defendant.strength;
        } else if (this.currentCaseType === 'habermasLuhmann') {
            const sd = isStage2 ? CASE_DATA.habermasLuhmann.stage2 : CASE_DATA.habermasLuhmann.stage1;
            return side === 'x' ? sd.plaintiff.strength : sd.defendant.strength;
        }
        if (!isStage2) return side === 'x' ? CASE_DATA.roeVWade.majority.justices : CASE_DATA.roeVWade.dissent.justices;
        return side === 'x' ? CASE_DATA.dobbsVJackson.majority.justices : CASE_DATA.dobbsVJackson.dissent.justices;
    }

    drawArrowHead(ctx, x, y, angle, color) {
        const s = CONFIG.GRAPH.ARROW_SIZE, a = CONFIG.GRAPH.ARROW_ANGLE;
        ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(x, y);
        ctx.lineTo(x - s * Math.cos(angle - a), y - s * Math.sin(angle - a));
        ctx.lineTo(x - s * Math.cos(angle + a), y - s * Math.sin(angle + a));
        ctx.closePath(); ctx.fill();
    }

    drawArc() {
        if (!this.winnerSide || !this.xGraphEnd || !this.yGraphEnd) return;
        const ctx = this.ctx;
        const ox = this.dim.originX, oy = this.dim.originY;
        const xAngRad = (this.xGraph.angle * Math.PI) / 180;
        const yAngRad = (this.yGraph.angle * Math.PI) / 180;
        const arcRadius = 60;

        let startAng, endAng;

        // 채권자대위권 Stage 2: arc를 X(Pink)와 Y(Blue) 그래프 중간 위치에 배치
        if (this.currentCaseType === 'creditorSubrogation' && this.winnerSide === 'y' &&
            (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done')) {
            // X(Pink)에서 시작 → Y(Blue) 방향으로 화살표, arc는 두 그래프 사이 영역
            startAng = xAngRad;
            endAng = yAngRad;
        } else {
            startAng = this.winnerSide === 'x' ? yAngRad : xAngRad;
            endAng = this.winnerSide === 'x' ? xAngRad : yAngRad;
        }

        let diff = endAng - startAng;
        while (diff > Math.PI) diff -= 2 * Math.PI;
        while (diff < -Math.PI) diff += 2 * Math.PI;
        const ccw = diff < 0;

        ctx.strokeStyle = CONFIG.COLORS.ARC_BLACK; ctx.lineWidth = CONFIG.ARC.LINE_WIDTH;
        ctx.beginPath(); ctx.arc(ox, oy, arcRadius, startAng, endAng, ccw); ctx.stroke();

        const arrowX = ox + Math.cos(endAng) * arcRadius;
        const arrowY = oy + Math.sin(endAng) * arcRadius;
        const tangent = endAng + (ccw ? -Math.PI / 2 : Math.PI / 2);
        ctx.fillStyle = CONFIG.COLORS.ARC_BLACK;
        const as = CONFIG.ARC.ARROW_SIZE, aa = Math.PI / 5;
        ctx.beginPath(); ctx.moveTo(arrowX, arrowY);
        ctx.lineTo(arrowX - as * Math.cos(tangent - aa), arrowY - as * Math.sin(tangent - aa));
        ctx.lineTo(arrowX - as * Math.cos(tangent + aa), arrowY - as * Math.sin(tangent + aa));
        ctx.closePath(); ctx.fill();

        if (this.currentCaseType !== 'habermasLuhmann') {
            const midAng = startAng + diff / 2;
            const lr = arcRadius + 22;
            ctx.fillStyle = CONFIG.COLORS.ARC_BLACK; ctx.font = 'bold 12px Inter, Arial'; ctx.textAlign = 'center';
            ctx.fillText('WIN', ox + Math.cos(midAng) * lr, oy + Math.sin(midAng) * lr);
        }
    }

    // ======================== GRAY Z = Vendor Plug-in (RISC-V Stage 2) ========================
    drawGrayVendorPlugin() {
        const ctx = this.ctx;
        const ox = this.dim.originX, oy = this.dim.originY;
        const GRAY = '#6B7280';
        const zAngRad = 8 * Math.PI / 180;
        const zLen = 5.5 * CONFIG.GRAPH.SCALE_FACTOR;
        const zSx = ox - Math.cos(zAngRad) * zLen * 0.22;
        const zSy = oy - Math.sin(zAngRad) * zLen * 0.22;
        const zEx = ox + Math.cos(zAngRad) * zLen;
        const zEy = oy + Math.sin(zAngRad) * zLen;
        ctx.save();
        ctx.strokeStyle = GRAY; ctx.lineWidth = 2.5; ctx.setLineDash([9, 5]); ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(zSx, zSy); ctx.lineTo(zEx, zEy); ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = GRAY; ctx.font = 'bold 12px Inter, Arial'; ctx.textAlign = 'left';
        ctx.fillText('Z (Vendor Plug-in)', zEx + 12, zEy + 2);
        ctx.font = '10px Inter, Arial';
        ctx.fillText('RVX_vendor_id · isolated ABI', zEx + 12, zEy + 17);
        const boxW = 220, boxH = 46, boxX = Math.min(zEx - 20, this.dim.w - boxW - 18), boxY = zEy + 30;
        ctx.fillStyle = 'rgba(107,114,128,0.10)'; this.roundRect(ctx, boxX, boxY, boxW, boxH, 7); ctx.fill();
        ctx.strokeStyle = GRAY; ctx.lineWidth = 1; this.roundRect(ctx, boxX, boxY, boxW, boxH, 7); ctx.stroke();
        ctx.fillStyle = '#4B5563'; ctx.font = '600 10px Inter, Arial'; ctx.textAlign = 'center';
        ctx.fillText('벤더 특화 명령어 격리', boxX + boxW/2, boxY + 17);
        ctx.font = '9px Inter, Arial'; ctx.fillStyle = '#6B7280';
        ctx.fillText('Base ISA 영향 없음 · 플러그인 ABI 경계', boxX + boxW/2, boxY + 33);
        ctx.restore();
    }

    // ======================== GRAY Z = 채무자/甲 (Stage 2) ========================
    drawGrayDebtor() {
        const ctx = this.ctx;
        const ox = this.dim.originX, oy = this.dim.originY;
        const GRAY = '#9CA3AF';

        // Z 그래프 라인 — 채무자(甲)의 패시브한 위치를 Gray로 표현
        // X와 Y 사이 중간 각도, 길이는 중간 정도
        const xAngRad = (this.xGraph.angle * Math.PI) / 180;
        const yAngRad = (this.yGraph.angle * Math.PI) / 180;
        const zAngRad = (xAngRad + yAngRad) / 2; // X와 Y 사이 중간 각도
        const zLen = 4 * CONFIG.GRAPH.SCALE_FACTOR; // 중간 길이

        const zSx = ox - Math.cos(zAngRad) * zLen * 0.3;
        const zSy = oy - Math.sin(zAngRad) * zLen * 0.3;
        const zEx = ox + Math.cos(zAngRad) * zLen;
        const zEy = oy + Math.sin(zAngRad) * zLen;

        // Gray 점선 라인
        ctx.save();
        ctx.strokeStyle = GRAY;
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 5]);
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(zSx, zSy);
        ctx.lineTo(zEx, zEy);
        ctx.stroke();
        ctx.setLineDash([]);

        // Z 라벨 — ② 채무자/甲
        const zLx = zEx + Math.cos(zAngRad) * 14;
        const zLy = zEy + Math.sin(zAngRad) * 14;
        ctx.fillStyle = GRAY;
        ctx.font = 'bold 12px Inter, Arial';
        ctx.textAlign = 'left';
        ctx.fillText('Z (② 채무자/甲)', zLx, zLy);
        ctx.font = '10px Inter, Arial';
        ctx.fillText('패시브(피대위자)', zLx, zLy + 14);

        // 배경 박스
        const boxW = 160, boxH = 40;
        const boxX = zEx - boxW / 2 + 30, boxY = zEy + 24;
        ctx.fillStyle = 'rgba(156, 163, 175, 0.12)';
        this.roundRect(ctx, boxX, boxY, boxW, boxH, 6);
        ctx.fill();
        ctx.strokeStyle = GRAY;
        ctx.lineWidth = 1;
        this.roundRect(ctx, boxX, boxY, boxW, boxH, 6);
        ctx.stroke();

        ctx.fillStyle = '#6B7280';
        ctx.font = '600 10px Inter, Arial';
        ctx.textAlign = 'center';
        ctx.fillText('② 甲(채무자) = 피대위자', boxX + boxW / 2, boxY + 16);
        ctx.font = '9px Inter, Arial';
        ctx.fillStyle = '#9CA3AF';
        ctx.fillText('Stage1 → Stage2 패시브 전환', boxX + boxW / 2, boxY + 30);

        ctx.restore();
    }

    // ======================== 소각하 배지 (Stage 2 최종 결과) ========================
    drawDismissalBadge() {
        const ctx = this.ctx;
        const ox = this.dim.originX, oy = this.dim.originY;

        // 소각하 배지 — 캔버스 우측 상단
        const bw = 180, bh = 52;
        const bx = this.dim.w - bw - 20, by = 20;

        // 빨간색 배경
        ctx.fillStyle = 'rgba(220, 38, 38, 0.9)';
        this.roundRect(ctx, bx, by, bw, bh, 10);
        ctx.fill();

        // 테두리
        ctx.strokeStyle = 'rgba(185, 28, 28, 1)';
        ctx.lineWidth = 2;
        this.roundRect(ctx, bx, by, bw, bh, 10);
        ctx.stroke();

        // 텍스트
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 14px Inter, Arial';
        ctx.textAlign = 'center';
        ctx.fillText('소 각하', bx + bw / 2, by + 20);
        ctx.font = '11px Inter, Arial';
        ctx.fillStyle = 'rgba(255,255,255,0.85)';
        ctx.fillText('파기자판 — 피보전권리 부존재', bx + bw / 2, by + 38);

        // (pink X 표시 삭제됨 — 사용자 요청)
    }

    drawRiscVCompatibilityBadge() {
        const ctx = this.ctx;
        const bw = 250, bh = 58, bx = this.dim.w - bw - 20, by = 18;
        ctx.fillStyle = 'rgba(22,163,74,0.94)'; this.roundRect(ctx, bx, by, bw, bh, 11); ctx.fill();
        ctx.strokeStyle = '#166534'; ctx.lineWidth = 2; this.roundRect(ctx, bx, by, bw, bh, 11); ctx.stroke();
        ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.font = 'bold 15px Inter, Arial';
        ctx.fillText('⚖ COMPATIBILITY 100%', bx + bw/2, by + 23);
        ctx.font = '11px Inter, Arial'; ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.fillText('자동 검증 완료 · Vendor Plug-in 격리', bx + bw/2, by + 42);
    }

    drawGroundTruth() {
        if (!this.xGraphEnd || !this.yGraphEnd) return;
        const ctx = this.ctx;
        const end = this.winnerSide === 'x' ? this.xGraphEnd : this.yGraphEnd;
        const gx = end.x, gy = end.y;
        const groundText = this.currentCaseType === 'creditorSubrogation' ? '✓ 법적 근거' : this.currentCaseType === 'habermasLuhmann' ? '✓ Theoretische Basis' : this.currentCaseType === 'riscVFragmentation' ? '✓ COMPATIBLE' : '✓ Ground Truth';
        const bw = this.currentCaseType === 'creditorSubrogation' ? 100 : this.currentCaseType === 'habermasLuhmann' ? 140 : this.currentCaseType === 'riscVFragmentation' ? 125 : 135;
        const bh = 24, bx = gx - bw / 2, by = gy - 48;
        ctx.fillStyle = CONFIG.COLORS.GROUND_TRUTH; this.roundRect(ctx, bx, by, bw, bh, 12); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.font = 'bold 11px Inter, Arial'; ctx.textAlign = 'center';
        ctx.fillText(groundText, gx, by + 16);
        ctx.strokeStyle = CONFIG.COLORS.GROUND_TRUTH; ctx.lineWidth = 1.5; ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(gx, by + bh); ctx.lineTo(gx, gy - 12); ctx.stroke(); ctx.setLineDash([]);
    }

    updateBalloons() {
        this.balloons = [];
        if (this.state.stage === 'preview') { this.updateBalloonsForPreview(); return; }
        if (this.state.stage === 0 || this.state.stage === 2) return;
        const duration = this.state.stage === 1 ? CONFIG.STAGE1_DURATION : CONFIG.STAGE2_DURATION;
        const progress = Ease.clamp01(this.state.currentTime / duration);
        const cd = this.currentCase;
        const ox = this.dim.originX, oy = this.dim.originY;
        const isStage2 = (this.state.stage === 3 || this.state.stage === 'done');
        if (this.currentCaseType === 'riscVFragmentation') {
            if (isStage2) {
                if (progress > 0.12) this.balloons.push({ x: ox + 180, y: oy + 130, type: 'defendant', title: cd.defendant.label, lines: cd.defendant.arguments.slice(0, 2), isMajority: true });
                if (progress > 0.48) this.balloons.push({ x: ox + 90, y: oy + 215, type: 'vendor', title: cd.vendorPlugin.label, lines: cd.vendorPlugin.arguments.slice(0, 2), isMajority: true, isVendor: true });
                if (progress > 0.55) this.balloons.push({ x: ox - 90, y: oy - 100, type: 'plaintiff', title: cd.plaintiff.label, lines: cd.plaintiff.arguments.slice(0, 2), isMajority: false });
                if (progress > 0.72) this.balloons.push({ x: ox + 120, y: oy + 205, type: 'vendor', title: '호환성 검증', lines: cd.defendant.arguments.slice(2, 4), isMajority: true });
            } else {
                if (progress > 0.12) this.balloons.push({ x: ox + 190, y: oy - 115, type: 'defendant', title: cd.defendant.label, lines: cd.defendant.arguments.slice(0, 2), isMajority: false });
                if (progress > 0.5) this.balloons.push({ x: ox + 250, y: oy - 20, type: 'defendant', title: '파편화 핵심', lines: cd.defendant.arguments.slice(2, 4), isMajority: false });
                if (progress > 0.18) this.balloons.push({ x: ox - 20, y: oy + 135, type: 'plaintiff', title: cd.plaintiff.label, lines: cd.plaintiff.arguments.slice(0, 2), isMajority: true });
                if (progress > 0.65) this.balloons.push({ x: ox + 80, y: oy + 205, type: 'plaintiff', title: '호환성 비용', lines: cd.plaintiff.arguments.slice(2, 4), isMajority: true });
            }
            return;
        }
        let majorityField, dissentField;
        if (this.currentCaseType === 'roeVsDobbs') { majorityField = 'majority'; dissentField = 'dissent'; }
        else { majorityField = isStage2 ? 'defendant' : 'plaintiff'; dissentField = isStage2 ? 'plaintiff' : 'defendant'; }

        const isYWinnerCase = (this.currentCaseType !== 'roeVsDobbs');
        if (isStage2) {
            if (progress > 0.12 && cd[majorityField]) {
                this.balloons.push({ x: isYWinnerCase ? ox + 180 : ox - 80, y: isYWinnerCase ? oy + 140 : oy - 140, type: majorityField, title: cd[majorityField].label, lines: cd[majorityField].arguments.slice(0, 2), isMajority: true });
            }
            if (progress > 0.5 && cd[majorityField]) {
                const kt = this.currentCaseType === 'creditorSubrogation' ? '법리 판단' : this.currentCaseType === 'habermasLuhmann' ? 'Kernargument' : 'Key Argument';
                this.balloons.push({ x: isYWinnerCase ? ox + 100 : ox - 160, y: isYWinnerCase ? oy + 220 : oy - 40, type: majorityField, title: kt, lines: cd[majorityField].arguments.slice(2, 4), isMajority: true });
            }
            if (progress > 0.18 && cd[dissentField]) {
                this.balloons.push({ x: isYWinnerCase ? ox - 80 : ox + 200, y: isYWinnerCase ? oy - 100 : oy + 120, type: dissentField, title: cd[dissentField].label, lines: cd[dissentField].arguments.slice(0, 2), isMajority: false });
            }
            if (progress > 0.65 && cd[dissentField] && cd[dissentField].arguments.length > 2) {
                this.balloons.push({ x: ox + 120, y: oy + 200, type: dissentField, title: this.currentCaseType === 'habermasLuhmann' ? 'Gegenargument' : 'Rebuttal', lines: cd[dissentField].arguments.slice(2, 3), isMajority: false });
            }
        } else {
            if (progress > 0.12 && cd[majorityField]) { this.balloons.push({ x: ox + 190, y: oy - 120, type: majorityField, title: cd[majorityField].label, lines: cd[majorityField].arguments.slice(0, 2), isMajority: true }); }
            if (progress > 0.5 && cd[majorityField]) { this.balloons.push({ x: ox + 260, y: oy - 30, type: majorityField, title: 'Key Argument', lines: cd[majorityField].arguments.slice(2, 4), isMajority: true }); }
            if (progress > 0.18 && cd[dissentField]) { this.balloons.push({ x: ox - 20, y: oy + 140, type: dissentField, title: cd[dissentField].label, lines: cd[dissentField].arguments.slice(0, 2), isMajority: false }); }
            if (progress > 0.65 && cd[dissentField] && cd[dissentField].arguments.length > 2) { this.balloons.push({ x: ox + 80, y: oy + 210, type: dissentField, title: 'Rebuttal', lines: cd[dissentField].arguments.slice(2, 3), isMajority: false }); }
        }
    }

    drawBalloons() {
        const ctx = this.ctx;
        this.balloons.forEach(b => {
            const isMaj = b.isMajority;
            const w = isMaj ? CONFIG.BALLOON.MAJOR_WIDTH : CONFIG.BALLOON.MINOR_WIDTH;
            const lineH = 15, pad = 10, titleH = 20;
            const h = titleH + b.lines.length * lineH + pad * 2;
            const bx = b.x - w / 2, by = b.y - h;
            const ts = CONFIG.BALLOON.TAIL_SIZE;
            ctx.fillStyle = 'rgba(0,0,0,0.08)'; this.roundRect(ctx, bx + 2, by + 2, w, h, CONFIG.BALLOON.RADIUS); ctx.fill();
            ctx.fillStyle = CONFIG.COLORS.TOOLTIP_BG; ctx.strokeStyle = CONFIG.COLORS.TOOLTIP_BORDER; ctx.lineWidth = 1;
            this.roundRect(ctx, bx, by, w, h, CONFIG.BALLOON.RADIUS); ctx.fill(); ctx.stroke();
            ctx.fillStyle = CONFIG.COLORS.TOOLTIP_BG; ctx.strokeStyle = CONFIG.COLORS.TOOLTIP_BORDER;
            ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x - ts, by + h); ctx.lineTo(b.x + ts, by + h); ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = CONFIG.COLORS.TOOLTIP_BG; ctx.fillRect(b.x - ts + 1, by + h - 1, ts * 2 - 2, 2);
            const barColor = isMaj ? this.xGraph.color : this.yGraph.color;
            ctx.fillStyle = barColor; ctx.fillRect(bx + 3, by + 4, 3, titleH - 2);
            ctx.fillStyle = '#222'; ctx.font = `bold ${isMaj ? 12 : 11}px Inter, Arial`; ctx.textAlign = 'left';
            ctx.fillText(b.title, bx + 11, by + 16);
            ctx.strokeStyle = '#FDD835'; ctx.lineWidth = 0.5; ctx.beginPath();
            ctx.moveTo(bx + 5, by + titleH + 2); ctx.lineTo(bx + w - 5, by + titleH + 2); ctx.stroke();
            ctx.fillStyle = '#555'; ctx.font = `${isMaj ? 11 : 10}px Inter, Arial`;
            b.lines.forEach((line, i) => { let txt = line; while (ctx.measureText(txt).width > w - 16 && txt.length > 5) { txt = txt.slice(0, -4) + '…'; } ctx.fillText(txt, bx + 9, by + titleH + pad + i * lineH + 6); });
            b.bounds = { x: bx, y: by, w, h: h + ts };
        });
    }

    drawLegend() {
        const ctx = this.ctx;
        const lx = 14, ly = 14, lw = 280, lh = 108;
        ctx.fillStyle = 'rgba(255,255,255,0.9)'; this.roundRect(ctx, lx, ly, lw, lh, 8); ctx.fill();
        ctx.strokeStyle = '#ddd'; ctx.lineWidth = 1; this.roundRect(ctx, lx, ly, lw, lh, 8); ctx.stroke();
        ctx.fillStyle = '#222'; ctx.font = 'bold 13px Inter, Arial'; ctx.textAlign = 'left';
        const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
        let stageLabel, xLabelText, yLabelText, majorityField, dissentField;

        if (this.currentCaseType === 'roeVsDobbs') {
            stageLabel = isStage2 ? 'Stage 2: Dobbs v. Jackson' : 'Stage 1: Roe v. Wade';
            majorityField = 'majority'; dissentField = 'dissent';
            const showXWin = this.winnerSide === 'x' && (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 3);
            xLabelText = showXWin ? `X (Plaintiff) — ${this.currentCase[majorityField].label} ✓WIN` : `X (Plaintiff) — ${this.currentCase[majorityField].label}`;
            yLabelText = `Y (Defendant) — ${this.currentCase[dissentField].label}`;
        } else if (this.currentCaseType === 'creditorSubrogation') {
            stageLabel = isStage2 ? '2단계: 대위소송' : '1단계: 조정성립';
            majorityField = isStage2 ? 'defendant' : 'plaintiff'; dissentField = isStage2 ? 'plaintiff' : 'defendant';
            if (isStage2) {
                const showYWin = this.winnerSide === 'y' && (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 3);
                xLabelText = `X (원고 대위) — ${this.currentCase[dissentField].label}`;
                yLabelText = showYWin ? `Y (제3채무자) — ${this.currentCase[majorityField].label} ✓승` : `Y (제3채무자) — ${this.currentCase[majorityField].label}`;
            } else {
                const showXWin = this.winnerSide === 'x' && (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 3);
                xLabelText = showXWin ? `X (원고/채권자) — ${this.currentCase[majorityField].label} ✓승` : `X (원고/채권자) — ${this.currentCase[majorityField].label}`;
                yLabelText = `Y (채무자) — ${this.currentCase[dissentField].label}`;
            }
        } else if (this.currentCaseType === 'riscVFragmentation') {
            stageLabel = isStage2 ? 'Stage 2: Modular ISA + Verification' : 'Stage 1: ISA Fragmentation';
            majorityField = isStage2 ? 'defendant' : 'plaintiff'; dissentField = isStage2 ? 'plaintiff' : 'defendant';
            if (isStage2) {
                const showYWin = this.winnerSide === 'y' && (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 3);
                xLabelText = `X (Modular ISA) — ${this.currentCase[dissentField].label}`;
                yLabelText = showYWin ? `Y (Auto Verification) — ${this.currentCase[majorityField].label} ✓` : `Y (Auto Verification) — ${this.currentCase[majorityField].label}`;
            } else {
                xLabelText = `X (Standard Base ISA) — ${this.currentCase[majorityField].label}`;
                yLabelText = `Y (Custom Extensions) — ${this.currentCase[dissentField].label}`;
            }
        } else {
            stageLabel = isStage2 ? 'Antithese: Luhmann (Systemtheorie)' : 'These: Habermas (Krit. Theorie)';
            majorityField = isStage2 ? 'defendant' : 'plaintiff'; dissentField = isStage2 ? 'plaintiff' : 'defendant';
            if (isStage2) {
                const showYWin = this.winnerSide === 'y' && (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 3);
                xLabelText = `X (Habermas) — ${this.currentCase[dissentField].label}`;
                yLabelText = showYWin ? `Y (Luhmann) — ${this.currentCase[majorityField].label} ✓SIEG` : `Y (Luhmann) — ${this.currentCase[majorityField].label}`;
            } else {
                const showXWin = this.winnerSide === 'x' && (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 3);
                xLabelText = showXWin ? `X (Habermas) — ${this.currentCase[majorityField].label} ✓SIEG` : `X (Habermas) — ${this.currentCase[majorityField].label}`;
                yLabelText = `Y (Luhmann) — ${this.currentCase[dissentField].label}`;
            }
        }
        ctx.fillText(stageLabel, lx + 10, ly + 20);
        ctx.font = '10px Inter, Arial'; ctx.fillStyle = '#888';
        ctx.fillText(this.currentCase.title, lx + 10, ly + 34);
        ctx.strokeStyle = this.xGraph.color; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(lx + 10, ly + 52); ctx.lineTo(lx + 32, ly + 52); ctx.stroke();
        ctx.fillStyle = '#333'; ctx.font = '11px Inter, Arial'; ctx.fillText(xLabelText, lx + 38, ly + 56);
        ctx.strokeStyle = this.yGraph.color; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(lx + 10, ly + 72); ctx.lineTo(lx + 32, ly + 72); ctx.stroke();
        ctx.fillStyle = '#333'; ctx.font = '11px Inter, Arial'; ctx.fillText(yLabelText, lx + 38, ly + 76);
        ctx.fillStyle = '#aaa'; ctx.font = 'italic 9px Inter, Arial';
        const srcText = this.currentCaseType === 'creditorSubrogation' ? 'Source: 대법원 판례 | LawG v1.33' : this.currentCaseType === 'riscVFragmentation' ? 'Source: RISC-V Specifications | LawG RISC-V' : this.currentCaseType === 'habermasLuhmann' ? 'Quelle: Lernhelfer.de | LawG v1.33' : 'Source: Oyez.org | LawG v1.33';
        ctx.fillText(srcText, lx + 10, ly + 98);
    }

    drawProgressBar() {
        const ctx = this.ctx;
        const barW = 260, barH = 6;
        const barX = this.dim.w - barW - 18, barY = this.dim.h - 28;
        const total = CONFIG.STAGE1_DURATION + CONFIG.TRANSITION_DURATION + CONFIG.STAGE2_DURATION;
        let elapsed = 0;
        if (this.state.stage === 'preview' || this.state.stage === 'done') { elapsed = total; }
        else if (this.state.stage === 1) { elapsed = this.state.currentTime; }
        else if (this.state.stage === 2) { elapsed = CONFIG.STAGE1_DURATION + this.state.currentTime; }
        else if (this.state.stage === 3) { elapsed = CONFIG.STAGE1_DURATION + CONFIG.TRANSITION_DURATION + this.state.currentTime; }
        const prog = Math.min(1, elapsed / total);
        ctx.fillStyle = 'rgba(200,200,200,0.5)'; this.roundRect(ctx, barX, barY, barW, barH, 3); ctx.fill();
        if (prog > 0) {
            const s1r = CONFIG.STAGE1_DURATION / total, tr = CONFIG.TRANSITION_DURATION / total;
            const grad = ctx.createLinearGradient(barX, 0, barX + barW, 0);
            grad.addColorStop(0, CONFIG.COLORS.BLUE); grad.addColorStop(s1r, CONFIG.COLORS.BLUE);
            grad.addColorStop(s1r + tr / 2, '#8B5CF6'); grad.addColorStop(s1r + tr, CONFIG.COLORS.PINK); grad.addColorStop(1, CONFIG.COLORS.PINK);
            ctx.fillStyle = grad; this.roundRect(ctx, barX, barY, barW * prog, barH, 3); ctx.fill();
        }
        ctx.strokeStyle = '#ccc'; ctx.lineWidth = 0.5; this.roundRect(ctx, barX, barY, barW, barH, 3); ctx.stroke();
        ctx.fillStyle = '#777'; ctx.font = '10px Inter, Arial'; ctx.textAlign = 'right';
        ctx.fillText(`${Math.floor(elapsed / 1000)}s / ${Math.floor(total / 1000)}s`, barX + barW, barY - 4);
        ctx.font = '8px Inter, Arial'; ctx.textAlign = 'center'; ctx.fillStyle = '#aaa';
        const s1w = barW * (CONFIG.STAGE1_DURATION / total), tw = barW * (CONFIG.TRANSITION_DURATION / total);
        let s1Label, s2Label;
        if (this.currentCaseType === 'creditorSubrogation') { s1Label = '조정성립'; s2Label = '대위소송'; }
        else if (this.currentCaseType === 'riscVFragmentation') { s1Label = '파편화'; s2Label = '모듈화·검증'; }
        else if (this.currentCaseType === 'habermasLuhmann') { s1Label = 'Habermas'; s2Label = 'Luhmann'; }
        else { s1Label = 'Roe'; s2Label = 'Dobbs'; }
        ctx.fillText(s1Label, barX + s1w / 2, barY + barH + 12);
        ctx.fillText(s2Label, barX + s1w + tw + (barW - s1w - tw) / 2, barY + barH + 12);
    }

    drawPhaseDescription() {
        if (this.state.stage === 'preview' || this.state.stage === 'done' || this.state.stage === 0 || this.state.stage === 2) return;
        const ctx = this.ctx;
        const phases = this.currentPhases, time = this.state.currentTime;
        let cur = phases[0];
        for (let i = phases.length - 1; i >= 0; i--) { if (time >= phases[i].time) { cur = phases[i]; break; } }
        const bw = Math.min((this.currentCaseType === 'creditorSubrogation' || this.currentCaseType === 'habermasLuhmann') ? 500 : 400, this.dim.w - 40);
        const bh = 46, bx = (this.dim.w - bw) / 2, by = this.dim.h - 80;
        ctx.fillStyle = 'rgba(15,23,42,0.85)'; this.roundRect(ctx, bx, by, bw, bh, 10); ctx.fill();
        ctx.fillStyle = '#fff'; ctx.font = '600 12px Inter, Arial'; ctx.textAlign = 'center';
        ctx.fillText(cur.desc, this.dim.w / 2, by + 20);
        const idx = phases.indexOf(cur) + 1;
        ctx.font = '10px Inter, Arial'; ctx.fillStyle = 'rgba(255,255,255,0.6)';
        const phaseText = (this.currentCaseType === 'creditorSubrogation' || this.currentCaseType === 'riscVFragmentation') ? `${idx}단계 / ${phases.length}단계` : this.currentCaseType === 'habermasLuhmann' ? `Phase ${idx} von ${phases.length}` : `Phase ${idx} of ${phases.length}`;
        ctx.fillText(phaseText, this.dim.w / 2, by + 36);
    }

    roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath(); ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h); ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r); ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
    }

    lerpColor(c1, c2, t) {
        const h = s => parseInt(s, 16);
        const r1 = h(c1.slice(1, 3)), g1 = h(c1.slice(3, 5)), b1 = h(c1.slice(5, 7));
        const r2 = h(c2.slice(1, 3)), g2 = h(c2.slice(3, 5)), b2 = h(c2.slice(5, 7));
        const r = Math.round(Ease.lerp(r1, r2, t)), g = Math.round(Ease.lerp(g1, g2, t)), b = Math.round(Ease.lerp(b1, b2, t));
        return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    }

    // ======================== INTERACTION ========================
    onMouseMove(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left, my = e.clientY - rect.top;
        let hovered = null;
        for (const b of this.balloons) { if (b.bounds && mx >= b.bounds.x && mx <= b.bounds.x + b.bounds.w && my >= b.bounds.y && my <= b.bounds.y + b.bounds.h) { hovered = b; break; } }
        const tip = document.getElementById('tooltip');
        if (tip && hovered) {
            let side;
            if (this.currentCaseType === 'roeVsDobbs') { side = hovered.isMajority ? this.currentCase.majority : this.currentCase.dissent; }
            else if (this.currentCaseType === 'riscVFragmentation') {
                if (hovered.isVendor) side = this.currentCase.vendorPlugin;
                else {
                    const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
                    side = isStage2 ? (hovered.isMajority ? this.currentCase.defendant : this.currentCase.plaintiff) : (hovered.isMajority ? this.currentCase.plaintiff : this.currentCase.defendant);
                }
            } else {
                const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
                side = isStage2 ? (hovered.isMajority ? this.currentCase.defendant : this.currentCase.plaintiff) : (hovered.isMajority ? this.currentCase.plaintiff : this.currentCase.defendant);
            }
            const groundLabel = this.currentCaseType === 'habermasLuhmann' ? 'Theoretische Basis' : this.currentCaseType === 'creditorSubrogation' ? '법적근거' : this.currentCaseType === 'riscVFragmentation' ? '기술 근거' : 'Ground';
            const clickLabel = this.currentCaseType === 'habermasLuhmann' ? 'Klicken für Details' : this.currentCaseType === 'creditorSubrogation' ? '클릭하여 상세 보기' : this.currentCaseType === 'riscVFragmentation' ? '클릭하여 기술 명세 보기' : 'Click for details';
            tip.innerHTML = `<strong>${escapeHtml(hovered.title)}</strong><div class="tooltip-line"></div>${hovered.lines.map(l => `<div>• ${escapeHtml(l)}</div>`).join('')}<div class="tooltip-line"></div><div style="font-size:10px;color:#999;">${groundLabel}: ${escapeHtml(side ? side.ground : '')}</div><div style="font-size:10px;color:#bbb;margin-top:3px;">${clickLabel}</div>`;
            tip.style.display = 'block';
            tip.style.left = Math.min(mx + 12, this.dim.w - 280) + 'px';
            tip.style.top = (my + 12) + 'px';
            this.canvas.style.cursor = 'pointer';
        } else if (tip) { tip.style.display = 'none'; this.canvas.style.cursor = 'default'; }
    }

    onClick(e) {
        const rect = this.canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left, my = e.clientY - rect.top;
        for (const b of this.balloons) { if (b.bounds && mx >= b.bounds.x && mx <= b.bounds.x + b.bounds.w && my >= b.bounds.y && my <= b.bounds.y + b.bounds.h) { this.showModal(b); break; } }
    }

    showModal(balloon) {
        const modal = document.getElementById('detailModal');
        const tEl = document.getElementById('modalTitle');
        const cEl = document.getElementById('modalContent');
        if (!modal || !tEl || !cEl) return;
        const cd = this.currentCase;
        let side;
        if (this.currentCaseType === 'roeVsDobbs') { side = balloon.isMajority ? cd.majority : cd.dissent; }
        else {
            const isStage2 = (this.state.stage === 3 || this.state.stage === 'preview' || this.state.stage === 'done');
            side = isStage2 ? (balloon.isMajority ? cd.defendant : cd.plaintiff) : (balloon.isMajority ? cd.plaintiff : cd.defendant);
        }
        if (!side) return;
        tEl.textContent = `${balloon.title} — ${cd.title}`;
        const groundLabel = this.currentCaseType === 'habermasLuhmann' ? 'Theoretische Basis' : this.currentCaseType === 'creditorSubrogation' ? '법적근거' : this.currentCaseType === 'riscVFragmentation' ? '기술 근거' : 'Ground';
        let html = `<p><strong>${escapeHtml(side.label)}</strong></p><p style="font-size:0.9em;color:#666;">${groundLabel}: ${escapeHtml(side.ground)}</p><ul>`;
        side.arguments.forEach(a => { html += `<li>${escapeHtml(a)}</li>`; });
        const linkLabel = this.currentCaseType === 'habermasLuhmann' ? 'Artikel auf Lernhelfer.de →' : this.currentCaseType === 'creditorSubrogation' ? '대법원 판례 보기 →' : this.currentCaseType === 'riscVFragmentation' ? 'RISC-V Specifications →' : 'View on Oyez.org →';
        html += `</ul><p style="margin-top:14px;font-size:0.85em;"><a href="${escapeHtml(cd.url)}" target="_blank" rel="noopener">${linkLabel}</a></p>`;
        cEl.innerHTML = html;
        modal.style.display = 'flex';
    }

    closeModal() {
        const modal = document.getElementById('detailModal');
        if (modal) modal.style.display = 'none';
    }
}

// ============================================================
// INIT
// ============================================================
function initApp() {
    window.lawgraph = new LawGraphVisualization();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

// export default removed to support file:/// direct open
